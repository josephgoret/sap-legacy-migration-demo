# Equivalence Testing Strategy

## Overview

Equivalence testing verifies that the migrated Java/Python services produce the **same business results** as the original ABAP programs. Since we cannot run the ABAP code directly (no SAP runtime available), we use a fixture-based approach.

## Approach

### 1. Test Fixture Pairs
For each migrated service, we maintain pairs of:
- **Input fixtures**: Sample data representing what would flow into the ABAP program
- **Output fixtures**: Expected results that both the ABAP and migrated versions should produce

### 2. ABAP → Java/Python Method Mapping
Each test includes comments documenting which ABAP construct maps to which Java/Python method. This creates a traceable lineage from source to target.

### 3. Business Logic Verification
Tests focus on **business rules**, not technical implementation:
- Do the same inputs produce the same outputs?
- Are edge cases handled the same way?
- Do validation rules match?

## Service-by-Service Mapping

### Inventory Service (z_inventory_report.abap → inventory-service)

| ABAP Construct | Java Equivalent | Test Coverage |
|---|---|---|
| SELECT ... FROM mara/marc/mard/mbew | MaterialMapper.findStocks() | InventoryQueryServiceTest |
| FORM calculate_stock_values | InventoryQueryService.calculateStockValue() | shouldCalculateStockValue* |
| IF labst <= 0 → CRITICAL | determineStockStatus() | shouldReturnCriticalStatus* |
| IF labst < minbe → LOW | determineStockStatus() | shouldReturnLowStatus* |
| REUSE_ALV_GRID_DISPLAY | GET /api/inventory/report | InventoryReportControllerTest |

### Purchase Order API (z_purchase_order_rfc.abap → purchase-order-api)

| ABAP Construct | Java Equivalent | Test Coverage |
|---|---|---|
| IMPORTING iv_vendor | CreateOrderRequest.vendorId | PurchaseOrderServiceTest |
| RAISE vendor_not_found | ResponseStatusException(404) | shouldRejectWhenVendorNotFound |
| RAISE material_not_found | ResponseStatusException(404) | shouldRejectWhenMaterialNotFound |
| RAISE plant_invalid | ResponseStatusException(400) | shouldRejectWhenPlantInvalid |
| INSERT ekko/ekpo | repository.insertOrder/Item() | shouldCreatePurchaseOrderSuccessfully |
| COMMIT WORK AND WAIT | @Transactional | Transaction rollback on error |

### Customer Sync Service (z_customer_idoc.abap → customer-sync-service)

| ABAP Construct | Java Equivalent | Test Coverage |
|---|---|---|
| E1KNA1M segment parsing | CustomerSyncRequest JSON | CustomerSyncControllerTest |
| SELECT SINGLE FROM kna1 | repository.findByCustomerNumber() | shouldCreateNewCustomer |
| INSERT kna1 | repository.insert() | shouldCreateNewCustomer |
| UPDATE kna1 | repository.update() | shouldUpdateExistingCustomer |
| IDoc status 51 | HTTP 200/201 + "SUCCESS" | shouldReturnCreatedForNewCustomer |
| IDoc status 53 | HTTP 400 | shouldReturn400ForMissingCustomerNumber |
| Idempotent reprocessing | Same input → UPDATE | shouldBeIdempotent |

### Pricing ETL (z_pricing_extract.abap → pricing-etl)

| ABAP Construct | Python Equivalent | Test Coverage |
|---|---|---|
| SELECT FROM konh/konp | extract_conditions() SQL query | test_extracts_base_prices |
| WHERE datab <= key_date AND datbi >= key_date | Date filtering in SQL | test_date_effective_filtering |
| OPEN DATASET / TRANSFER | write_output() with pandas to_csv | test_writes_tab_delimited_file |
| FORM display_summary | logging summary in main() | (logged output) |

### Delivery Note Generator (z_delivery_note_form.abap → delivery-note-generator)

| ABAP Construct | Java Equivalent | Test Coverage |
|---|---|---|
| PERFORM read_delivery_header | DeliveryNoteService.getDeliveryNoteData() | shouldMapAllHeaderFields |
| PERFORM read_delivery_items | repository.findItemsByDeliveryNumber() | shouldCalculateTotalWeight |
| OPEN_FORM / WRITE_FORM | DeliveryNotePdfGenerator.generatePdf() | shouldReturnPdfForValidDelivery |
| Page break (MOD 25) | yPos < MARGIN + 100 check | (PDF generation logic) |
| CLOSE_FORM | document.save() | (PDF generation logic) |

## Test Fixtures

Each service has a `test-fixtures/` directory containing:
- `input.json` — Sample input data (request body or query parameters)
- `expected-output.json` — Expected response matching what the ABAP would produce

These fixtures serve as the **contract** between the old and new systems.

## Running Equivalence Tests

```bash
# Java services (includes equivalence assertions in unit tests)
cd migrated/inventory-service && ./gradlew test
cd migrated/purchase-order-api && ./gradlew test
cd migrated/customer-sync-service && ./gradlew test
cd migrated/delivery-note-generator && ./gradlew test

# Python ETL
cd migrated/pricing-etl && pytest tests/
```
