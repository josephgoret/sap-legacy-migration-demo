# Playbook: SAPscript Form → Java PDF Generator Migration

## Context

SAPscript is SAP's legacy form technology for printing documents (delivery notes, invoices,
purchase orders, etc.). SAPscript programs mix business logic (data retrieval) with rendering
logic (WRITE_FORM calls). Migration requires separating these concerns: business logic moves
to a service layer, and rendering moves to a PDF generation library (Apache PDFBox).

## When to Use

- The source is an ABAP print program that calls SAPscript functions
- It uses `OPEN_FORM`, `WRITE_FORM`, and `CLOSE_FORM` function calls
- It reads delivery, invoice, or order data from SAP tables
- It formats addresses, line items, totals, and footers

## Source Pattern

### Typical ABAP Structure

```abap
REPORT z_form_print.

* Read business data (→ Service layer)
SELECT ... FROM likp/lips/kna1 ...

* Open SAPscript form
CALL FUNCTION 'OPEN_FORM'
  EXPORTING form = 'Z_FORM_NAME'.

* Write content blocks (→ PDF content)
CALL FUNCTION 'WRITE_FORM'
  EXPORTING element = 'HEADER'.

LOOP AT items.
  CALL FUNCTION 'WRITE_FORM'
    EXPORTING element = 'ITEM_LINE'.
ENDLOOP.

CALL FUNCTION 'WRITE_FORM'
  EXPORTING element = 'TOTALS'.

* Close form
CALL FUNCTION 'CLOSE_FORM'.
```

### Key Constructs

| ABAP Construct | Java/PDF Equivalent |
|----------------|-------------------|
| `OPEN_FORM` | Create PDDocument, PDPage |
| `WRITE_FORM` element | PDFBox content stream operations |
| Form window (HEADER, MAIN, FOOTER) | PDF page regions |
| SAPscript text elements | PDF text drawing operations |
| Page break in WRITE_FORM | New PDPage |
| `CLOSE_FORM` | document.save() |

## Target Pattern

### Spring Boot + PDFBox Structure

```
src/main/java/com/bobs/{service}/
├── api/
│   └── {Name}Controller.java           ← POST /api/{entity}/{id}/pdf
├── application/
│   ├── {Name}Service.java              ← Business logic (data retrieval)
│   └── data/
│       ├── {Name}Data.java             ← Combined data for PDF
│       └── {Name}ItemData.java         ← Line item data
├── core/
│   ├── {Header}.java                   ← Header entity
│   ├── {Item}.java                     ← Item entity
│   └── {Entity}Repository.java         ← Repository interface
└── infrastructure/
    ├── mybatis/
    │   └── {Entity}Mapper.java
    ├── pdf/
    │   └── {Name}PdfGenerator.java     ← PDF rendering (replaces SAPscript)
    └── repository/
        └── MyBatis{Entity}Repository.java
```

## Step-by-Step Instructions

### Step 1: Separate Business Logic from Rendering

1. **Identify data retrieval** — all SELECT statements before/during form output
2. **Identify rendering logic** — WRITE_FORM calls and their elements
3. Business logic → `{Name}Service.java`
4. Rendering logic → `{Name}PdfGenerator.java`

### Step 2: Create Data DTOs

1. Create a DTO that holds all data needed for the PDF:
   ```java
   public class DeliveryNoteData {
       private DeliveryHeaderData header;
       private AddressData shipToAddress;
       private List<DeliveryItemData> items;
       private BigDecimal totalWeight;
       private int totalPackages;
   }
   ```
2. Map ABAP structure fields to DTO properties

### Step 3: Create PDF Generator

1. Use Apache PDFBox to create the PDF document
2. Map SAPscript form elements to PDF content blocks:
   ```java
   public byte[] generatePdf(DeliveryNoteData data) {
       PDDocument document = new PDDocument();
       PDPage page = new PDPage(PDRectangle.A4);
       document.addPage(page);

       PDPageContentStream content = new PDPageContentStream(document, page);

       // HEADER element → company logo, document title
       writeHeader(content, data.getHeader());

       // SHIP_TO_ADDRESS element → address block
       writeAddress(content, data.getShipToAddress());

       // ITEM_LINE elements → table rows
       writeItemTable(content, data.getItems());

       // TOTALS element → summary
       writeTotals(content, data);

       // FOOTER element → signature line
       writeFooter(content);

       content.close();
       // Return PDF bytes
   }
   ```
3. Handle page breaks: check remaining Y position before each item line

### Step 4: Create Service Layer

1. Implement data retrieval matching the ABAP SELECT statements
2. Combine data from multiple tables into the DTO
3. Calculate totals (total weight, item count, etc.)

### Step 5: Create REST Controller

1. Use `@PostMapping("/api/{entity}/{id}/pdf")` or `@GetMapping`
2. Set response content type to `application/pdf`
3. Return the PDF bytes in the response body:
   ```java
   @GetMapping("/{id}/pdf")
   public ResponseEntity<byte[]> generatePdf(@PathVariable String id) {
       DeliveryNoteData data = service.getDeliveryNoteData(id);
       byte[] pdf = pdfGenerator.generatePdf(data);
       return ResponseEntity.ok()
           .contentType(MediaType.APPLICATION_PDF)
           .header("Content-Disposition", "attachment; filename=delivery-" + id + ".pdf")
           .body(pdf);
   }
   ```

### Step 6: Create Flyway Migration

1. Create tables for delivery header and items
2. Create table for addresses
3. Include sample data for testing

## Testing Requirements

1. **Service test**: Verify data retrieval and calculation logic
2. **PDF generation test**: Verify PDF is generated without errors:
   - PDF is non-empty
   - PDF contains expected text (delivery number, item descriptions)
   - PDF has correct number of pages for large item lists
3. **Controller test**: Verify endpoint returns `application/pdf` content type
4. **Page break test**: Verify multi-page documents render correctly
5. Use PDFBox text extraction in tests to verify content

## Known Limitations

- **Layout fidelity**: SAPscript forms have pixel-precise layouts defined in SE71.
  PDF generation will approximate the layout but won't be pixel-identical. Visual
  review by a human is recommended for the first migration of each form.
- **Barcodes/logos**: SAPscript can embed barcodes and logos. PDFBox supports these
  but they need explicit implementation. Flag forms with barcodes for extra review.
- **Multi-language**: SAPscript uses text elements with language variants. The Java
  service should use Spring's MessageSource for i18n if multi-language is needed.
- **Print control**: SAPscript integrates with SAP's print spooler (SP01). The REST
  API returns PDF bytes — actual printing is handled by the consuming application.
- **SmartForms**: If the source uses SmartForms (successor to SAPscript), the pattern
  is similar but SmartForms have a more structured XML definition. Adjust parsing
  accordingly.
