# Playbook: RFC Function Module → REST API Migration

## Context

RFC (Remote Function Call) function modules are SAP's primary mechanism for external system
integration. They define a strict interface contract with IMPORTING (input), EXPORTING (output),
TABLES (bidirectional lists), and EXCEPTIONS (error conditions). This maps naturally to REST API
request/response patterns.

## When to Use

- The source is an ABAP function module (FUNCTION ... ENDFUNCTION)
- It is marked as RFC-enabled (Remote-Enabled Module)
- It has IMPORTING, EXPORTING, TABLES, and/or EXCEPTIONS in its interface
- It performs data validation and database operations (INSERT, UPDATE, MODIFY)

## Source Pattern

### Typical ABAP Structure

```abap
FUNCTION z_custom_rfc.
*"  IMPORTING
*"     VALUE(IV_KEY_FIELD) TYPE datatype
*"     VALUE(IV_PARAM)     TYPE datatype
*"  EXPORTING
*"     VALUE(EV_RESULT)    TYPE datatype
*"     VALUE(EV_MESSAGE)   TYPE BAPIRET2-MESSAGE
*"  TABLES
*"     IT_ITEMS            STRUCTURE zstructure
*"  EXCEPTIONS
*"     NOT_FOUND
*"     VALIDATION_ERROR
*"     CREATION_FAILED

  " Validation logic
  SELECT SINGLE ... WHERE ...
  IF sy-subrc <> 0.
    RAISE not_found.
  ENDIF.

  " Business logic
  LOOP AT it_items.
    " Process each item
  ENDLOOP.

  " Database operations
  INSERT/UPDATE table FROM structure.
  COMMIT WORK AND WAIT.

ENDFUNCTION.
```

### Key Constructs

| ABAP Construct | REST Equivalent |
|----------------|----------------|
| `IMPORTING` params | Request body fields or path params |
| `EXPORTING` params | Response body fields |
| `TABLES` params | Request/response list fields |
| `EXCEPTIONS` | HTTP status codes + error body |
| `RAISE exception` | Throw exception → error response |
| `COMMIT WORK` | Transaction commit (implicit in Spring) |
| `ROLLBACK WORK` | Transaction rollback (`@Transactional`) |

## Target Pattern

### Spring Boot 4-Layer Structure

```
src/main/java/com/bobs/{service}/
├── api/
│   └── {Name}Controller.java           ← POST endpoint, request/response DTOs
├── application/
│   ├── {Name}Service.java              ← Validation + business logic
│   └── data/
│       ├── Create{Name}Request.java    ← IMPORTING + TABLES params
│       └── Create{Name}Response.java   ← EXPORTING params
├── core/
│   ├── {Entity}.java                   ← Domain entity
│   └── {Entity}Repository.java         ← Repository interface
└── infrastructure/
    ├── mybatis/
    │   └── {Entity}Mapper.java         ← MyBatis mapper
    └── repository/
        └── MyBatis{Entity}Repository.java
```

## Step-by-Step Instructions

### Step 1: Map the RFC Interface

1. **IMPORTING** parameters → Request DTO fields
   - `IV_VENDOR TYPE LFA1-LIFNR` → `private String vendorId;`
   - Key fields may become path parameters: `/api/orders/{vendorId}`
   - Supporting fields become request body fields
2. **EXPORTING** parameters → Response DTO fields
   - `EV_PO_NUMBER` → `private String poNumber;`
   - `EV_MESSAGE` → `private String message;`
3. **TABLES** parameters → List fields in request/response DTOs
   - `IT_ITEMS STRUCTURE ZBOBS_PO_ITEM` → `private List<OrderItemRequest> items;`
4. **EXCEPTIONS** → HTTP status codes and error handling
   - `VENDOR_NOT_FOUND` → `404 Not Found`
   - `VALIDATION_ERROR` → `400 Bad Request`
   - `CREATION_FAILED` → `500 Internal Server Error`

### Step 2: Create Request/Response DTOs

1. Map each IMPORTING parameter and TABLES structure field to a request DTO
2. Map each EXPORTING parameter to a response DTO
3. Add Jakarta validation annotations matching ABAP validation:
   - `IF field IS INITIAL` → `@NotBlank` or `@NotNull`
   - `IF field <= 0` → `@Positive`
   - Existence checks → Custom validator or service-layer validation

### Step 3: Create the Flyway Migration

1. Map SAP tables (EKKO, EKPO, etc.) to relational tables
2. Preserve the parent-child relationship (header → items)
3. Add foreign key constraints where SAP had implicit relationships

### Step 4: Create Domain Entities and Repository

1. Create entity classes for each SAP table involved
2. Create repository interfaces with save/find methods
3. Implement with MyBatis

### Step 5: Create Service Layer

1. Translate validation logic: each ABAP `IF + RAISE` becomes a validation check
   that throws a specific exception
2. Translate business logic: LOOP processing, calculations
3. Translate database operations: INSERT → repository.save()
4. Wrap in `@Transactional` to match ABAP COMMIT/ROLLBACK semantics

### Step 6: Create REST Controller

1. Use `@PostMapping` for create operations (matching RFC write semantics)
2. Accept `@RequestBody` with the request DTO
3. Return `ResponseEntity` with appropriate status codes
4. Use `@ExceptionHandler` to map service exceptions to HTTP responses

### Step 7: Create Exception Classes

1. Map each ABAP EXCEPTION to a Java exception class
2. Create a `@ControllerAdvice` exception handler that maps:
   - `VendorNotFoundException` → `404`
   - `ValidationException` → `400`
   - `CreationFailedException` → `500`

## Testing Requirements

1. **Happy path test**: Valid input → successful creation → correct response
2. **Validation tests**: One test per ABAP validation check (vendor not found, material
   not found, invalid plant, zero quantity, no items)
3. **Error mapping tests**: Verify each exception maps to the correct HTTP status
4. **Transaction tests**: Verify rollback on partial failure (e.g., header created but
   item insert fails → everything rolled back)
5. Add comments in tests: `// Equivalent to ABAP: RAISE vendor_not_found`

## Known Limitations

- **Number ranges**: ABAP uses `NUMBER_GET_NEXT` for sequential IDs. Java can use
  auto-increment or UUID. Document the ID generation strategy change.
- **COMMIT WORK AND WAIT**: ABAP's synchronous commit. Spring's `@Transactional`
  provides equivalent behavior, but distributed transaction scenarios need review.
- **SAP locks**: ABAP `ENQUEUE/DEQUEUE` object locks have no direct equivalent.
  Use database-level optimistic locking (`@Version`) or pessimistic locking as needed.
- **RFC error handling**: ABAP RFC returns a flat exception. REST APIs should return
  structured error bodies with codes and messages for each validation failure.
