# Playbook: IDoc Processor → Event-Driven REST API Migration

## Context

IDocs (Intermediate Documents) are SAP's standard mechanism for asynchronous data exchange.
IDoc processors parse structured message segments, validate data, and create or update master
data or transactional records. This maps naturally to event-driven REST APIs with idempotent
upsert semantics.

## When to Use

- The source is an ABAP function module that processes IDocs
- It references IDoc types (DEBMAS, MATMAS, ORDERS, DESADV, etc.)
- It parses IDoc segments (E1KNA1M, E1MARAM, etc.) from EDIDD structures
- It updates IDoc status records (status 51 for success, 53 for error)

## Source Pattern

### Typical ABAP Structure

```abap
FUNCTION z_process_idoc.
*"  IMPORTING
*"     VALUE(IV_IDOC_NUMBER) TYPE EDIDC-DOCNUM
*"  TABLES
*"     IT_IDOC_DATA   STRUCTURE EDIDD
*"     IT_IDOC_STATUS STRUCTURE EDIDS

  " Parse segments
  LOOP AT it_idoc_data WHERE segnam = 'E1KNA1M'.
    ls_segment = it_idoc_data-sdata.
    " Map segment fields to internal structure
  ENDLOOP.

  " Duplicate check
  SELECT SINGLE 'X' FROM master_table WHERE key = lv_key.
  IF sy-subrc = 0.
    " UPDATE existing record
  ELSE.
    " INSERT new record
  ENDIF.

  " Set IDoc status
  ls_status-status = '51'.  " Success
  APPEND ls_status TO it_idoc_status.

ENDFUNCTION.
```

### Key Constructs

| ABAP Construct | REST Equivalent |
|----------------|----------------|
| IDoc segment (E1KNA1M) | JSON object in request body |
| `SDATA` field parsing | JSON deserialization |
| IDoc status 51 (success) | HTTP 200/201 |
| IDoc status 53 (error) | HTTP 400/409/500 |
| Duplicate check + INSERT/UPDATE | Idempotent upsert (PUT or POST) |
| EDIDC-DOCNUM (IDoc number) | Request ID / idempotency key |

## Target Pattern

### Spring Boot 4-Layer Structure

```
src/main/java/com/bobs/{service}/
├── api/
│   └── {Name}SyncController.java       ← POST /api/{entity}/sync
├── application/
│   ├── {Name}SyncService.java           ← Parse, validate, upsert logic
│   └── data/
│       ├── {Name}SyncRequest.java       ← Maps to IDoc segments
│       └── {Name}SyncResponse.java      ← Maps to IDoc status
├── core/
│   ├── {Entity}.java                    ← Master data entity
│   └── {Entity}Repository.java          ← Repository interface
└── infrastructure/
    ├── mybatis/
    │   └── {Entity}Mapper.java
    └── repository/
        └── MyBatis{Entity}Repository.java
```

## Step-by-Step Instructions

### Step 1: Map IDoc Segments to JSON Schema

1. Each IDoc segment type becomes a JSON object
2. Parent segments → top-level request fields
3. Child segments → nested objects or arrays
4. Example mapping:
   ```
   E1KNA1M (general data) → top-level fields in SyncRequest
   E1KNB1M (company code) → nested CompanyCodeData object
   ```

### Step 2: Map IDoc Status Codes to HTTP Responses

| IDoc Status | Meaning | HTTP Equivalent |
|-------------|---------|----------------|
| 51 | Application document posted | 200 OK (update) or 201 Created (new) |
| 53 | Application document NOT posted | 400 Bad Request or 409 Conflict |
| 64 | IDoc ready for transfer | 202 Accepted (async processing) |

### Step 3: Design Idempotent Upsert

1. The IDoc processor's duplicate-check-then-insert-or-update pattern maps to:
   ```java
   Optional<Entity> existing = repository.findByKey(key);
   if (existing.isPresent()) {
       // UPDATE path
       return updateEntity(existing.get(), request);
   } else {
       // CREATE path
       return createEntity(request);
   }
   ```
2. Return `201 Created` for new records, `200 OK` for updates
3. Include operation type in response: `{ "operation": "CREATED" | "UPDATED" }`

### Step 4: Create Request DTO

1. Map IDoc segment fields to request DTO properties
2. Add validation annotations matching ABAP validation
3. Include an optional `requestId` field for idempotency (maps to EDIDC-DOCNUM)

### Step 5: Create Response DTO

1. Map to IDoc status semantics:
   ```java
   public class SyncResponse {
       private String entityId;       // Created/updated record key
       private String operation;      // "CREATED" or "UPDATED"
       private String status;         // "SUCCESS" or "ERROR"
       private String message;        // Human-readable status text
   }
   ```

### Step 6: Create Service Layer

1. Implement the upsert logic matching the ABAP duplicate-check pattern
2. Map IDoc field assignments to entity field assignments
3. Preserve metadata fields (created date, created by, changed date, changed by)
4. Handle both CREATE and UPDATE paths with appropriate responses

### Step 7: Create REST Controller

1. Use `@PostMapping("/api/{entity}/sync")` — POST for event-driven sync
2. Accept `@RequestBody` with the sync request DTO
3. Return `ResponseEntity` with 200 or 201 based on operation
4. The endpoint must be **idempotent**: calling with the same data twice should
   not create duplicates (matching IDoc reprocessing behavior)

## Testing Requirements

1. **Create test**: New entity → 201 Created with correct fields
2. **Update test**: Existing entity → 200 OK with updated fields
3. **Idempotency test**: Same request twice → second call returns 200 (update, not duplicate)
4. **Validation test**: Missing required fields → 400 Bad Request
5. **Equivalence test**: Same input data produces same entity state as ABAP IDoc processor
6. Add comments: `// IDoc status 51 equivalent: entity created successfully`

## Known Limitations

- **IDoc segment nesting**: Complex IDocs can have deeply nested segment hierarchies.
  Flatten to reasonable JSON depth and document any structural simplifications.
- **IDoc reprocessing**: SAP can reprocess IDocs (status 66 → reprocess). The REST API
  handles this via idempotency, but explicit reprocess tracking may need human review.
- **Partner profiles**: IDoc routing is configured in WE20/WE21. The REST API replaces
  this with standard API gateway routing. Document the routing change.
- **Serialization**: IDoc SDATA is a flat 1000-char string. JSON provides typed fields.
  Verify that field length truncation in ABAP is handled correctly in JSON validation.
