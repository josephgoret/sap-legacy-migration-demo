# Playbook: ABAP Data Extraction → Python ETL Migration

## Context

ABAP data extraction programs read from SAP tables, apply transformations, and write output
to flat files on the SAP application server. These are migrated to Python ETL scripts that
read from a data warehouse (or replicated SAP tables) and produce equivalent output using
pandas and SQLAlchemy.

## When to Use

- The source is an ABAP report that reads SAP tables and writes flat files
- It uses `OPEN DATASET ... FOR OUTPUT` to write to the application server
- It performs joins across SAP tables with filtering logic
- The output is tabular data (CSV, TSV, fixed-width)
- Date-effective filtering is common (valid-from/valid-to logic)

## Source Pattern

### Typical ABAP Structure

```abap
REPORT z_data_extract.

* Selection screen for extraction parameters
PARAMETERS: p_keydt TYPE sy-datum,
            p_file  TYPE rlgrap-filename.
SELECT-OPTIONS: s_filter FOR field.

* Database reads with joins
SELECT ... INTO TABLE gt_data
  FROM table1 AS a
  INNER JOIN table2 AS b ON ...
  WHERE a~datab <= p_keydt
    AND a~datbi >= p_keydt.

* Data processing
LOOP AT gt_data INTO gs_data.
  " Transformations, calculations
ENDLOOP.

* File output
OPEN DATASET p_file FOR OUTPUT IN TEXT MODE.
LOOP AT gt_data INTO gs_data.
  CONCATENATE fields INTO lv_line SEPARATED BY tab.
  TRANSFER lv_line TO p_file.
ENDLOOP.
CLOSE DATASET p_file.
```

### Key Constructs

| ABAP Construct | Python Equivalent |
|----------------|------------------|
| `SELECT ... INTO TABLE` | `pd.read_sql(query, connection)` |
| `SELECT-OPTIONS` | Config file filters |
| `LOOP AT ... INTO` | `df.iterrows()` or vectorized pandas |
| `OPEN DATASET ... FOR OUTPUT` | `df.to_csv(path)` |
| `CONCATENATE ... SEPARATED BY` | Built into `to_csv(sep='\t')` |
| `sy-datum` (current date) | `datetime.date.today()` |
| Date range filtering | SQL `WHERE` + pandas filtering |

## Target Pattern

### Python Project Structure

```
pricing-etl/
├── extract_pricing.py         ← Main ETL script
├── requirements.txt           ← pandas, sqlalchemy, pyyaml
├── config.yaml                ← Connection and filter configuration
└── tests/
    └── test_extract_pricing.py ← pytest tests
```

## Step-by-Step Instructions

### Step 1: Map ABAP SELECT to SQL Query

1. Translate the ABAP SELECT statement to a standard SQL query
2. Map SAP table names to equivalent data warehouse tables
3. Preserve JOIN conditions and WHERE clause logic
4. Map ABAP date filtering to SQL date comparisons:
   ```sql
   WHERE h.valid_from <= :key_date AND h.valid_to >= :key_date
   ```

### Step 2: Create Configuration File

1. Map ABAP selection screen parameters to YAML config:
   ```yaml
   database:
     connection_string: "sqlite:///pricing.db"
   filters:
     condition_types: ["PR00", "K004"]
     key_date: "2024-01-15"
   output:
     path: "output/pricing_extract.csv"
     delimiter: "\t"
   ```
2. Map `SELECT-OPTIONS` ranges to filter lists in config
3. Make file paths and database connections configurable

### Step 3: Create Main ETL Script

1. Structure the script with clear extract/transform/load functions:
   ```python
   def extract_conditions(engine, config):
       """Maps to ABAP FORM fetch_pricing_data"""
       query = "SELECT ..."
       return pd.read_sql(query, engine, params=...)

   def transform_data(df):
       """Maps to ABAP processing LOOPs"""
       # Apply any transformations
       return df

   def write_output(df, config):
       """Maps to ABAP OPEN DATASET / TRANSFER / CLOSE DATASET"""
       df.to_csv(config['output']['path'], sep='\t', index=False)
   ```
2. Add proper logging (replaces ABAP WRITE statements for summary)
3. Add error handling with try/except blocks
4. Make the script callable from command line with argparse

### Step 4: Map Data Types

| ABAP Type | pandas/Python Type |
|-----------|-------------------|
| `CHAR(n)` | `str` |
| `NUMC(n)` | `str` (preserve leading zeros) |
| `DEC(p,s)` | `float` or `Decimal` |
| `DATS` | `datetime.date` |
| `QUAN` | `float` |
| `CURR` | `Decimal` |

### Step 5: Handle Date-Effective Logic

1. ABAP uses `DATAB` (valid-from) and `DATBI` (valid-to) fields
2. The key date parameter determines which records are "active"
3. Translate to: `WHERE valid_from <= key_date AND valid_to >= key_date`
4. Handle the SAP convention: `DATBI = '99991231'` means "no end date"

### Step 6: Create Requirements File

```
pandas>=1.5.0
sqlalchemy>=1.4.0
pyyaml>=6.0
pytest>=7.0.0
```

## Testing Requirements

1. **Extraction test**: Verify SQL query returns expected columns and row count
2. **Date filtering test**: Verify date-effective logic correctly includes/excludes records
3. **Transformation test**: Verify any calculated fields match ABAP logic
4. **Output format test**: Verify output file format (delimiter, header, encoding)
5. **Empty data test**: Verify graceful handling when no data matches filters
6. Use SQLite as test database with fixtures matching SAP table structure

## Known Limitations

- **SAP table names**: The Python script uses equivalent table names in the data warehouse.
  A mapping document should be provided showing SAP table → DW table correspondence.
- **ABAP string handling**: ABAP strings are fixed-length and right-padded with spaces.
  Python strings are variable-length. Verify field widths if downstream systems expect
  fixed-width output.
- **Character encoding**: SAP uses its own code pages. The Python script defaults to UTF-8.
  Verify encoding requirements with the data team.
- **Large datasets**: ABAP processes data in application server memory. Python should use
  chunked reading (`chunksize` parameter) for very large extractions.
