# Playbook: ALV Report → REST API Migration

## Context

This playbook applies when migrating ABAP ALV (ABAP List Viewer) reports to Spring Boot REST API
endpoints. ALV reports are the most common custom development in SAP — a typical mid-market customer
has 50–200 custom reports. Each report follows a predictable pattern: selection screen → database
reads → data processing → ALV grid display.

## When to Use

- The source is an ABAP report program (REPORT statement)
- It uses `REUSE_ALV_GRID_DISPLAY` or `REUSE_ALV_LIST_DISPLAY` or CL_GUI_ALV_GRID
- It has a SELECTION-SCREEN with parameters and SELECT-OPTIONS
- It reads from SAP tables and outputs a tabular result

## Source Pattern

### Typical ABAP Structure

```abap
REPORT z_custom_report.

* Type definitions for output structure
TYPES: BEGIN OF ty_s_output,
         field1 TYPE table-field1,
         field2 TYPE table-field2,
       END OF ty_s_output.

* Selection screen (→ REST query parameters)
SELECTION-SCREEN BEGIN OF BLOCK b01.
  SELECT-OPTIONS: s_field1 FOR gs_output-field1.
  PARAMETERS:     p_param1 TYPE datatype.
SELECTION-SCREEN END OF BLOCK b01.

* Data retrieval (→ MyBatis query)
SELECT ... INTO TABLE gt_output FROM ... WHERE ...

* Processing (→ Service layer logic)
LOOP AT gt_output ASSIGNING <fs>.
  " calculations, transformations
ENDLOOP.

* ALV display (→ JSON response)
CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY' ...
```

### Key ABAP Constructs to Recognize

| ABAP Construct | Meaning |
|----------------|---------|
| `SELECT-OPTIONS` | Range parameter (low/high/sign/option) |
| `PARAMETERS` | Single value parameter |
| `SELECT ... INTO TABLE` | Database query populating internal table |
| `FIELD-SYMBOLS` | Pointer to table row (like iterator reference) |
| `REUSE_ALV_GRID_DISPLAY` | Grid output function |
| `slis_fieldcat_alv` | Column definitions for the grid |

## Target Pattern

### Spring Boot 4-Layer Structure

```
src/main/java/com/bobs/{service}/
├── api/
│   └── {Name}ReportController.java      ← Selection screen params become @RequestParam
├── application/
│   ├── {Name}QueryService.java          ← ABAP processing logic
│   └── data/
│       └── {Name}ReportData.java        ← ALV output structure becomes response DTO
├── core/
│   ├── {Entity}.java                    ← SAP table rows become domain entities
│   └── {Entity}Repository.java          ← Repository interface
└── infrastructure/
    ├── mybatis/
    │   └── {Entity}Mapper.java          ← MyBatis mapper interface
    └── repository/
        └── MyBatis{Entity}Repository.java ← Repository implementation

src/main/resources/
├── mapper/{Entity}Mapper.xml            ← ABAP SELECT becomes MyBatis SQL
└── db/migration/V1__create_tables.sql   ← SAP table structure as Flyway migration
```

## Step-by-Step Instructions

### Step 1: Analyze the ABAP Source

1. Identify the **selection screen parameters** — these become REST query parameters
2. Identify the **SAP tables** being read (e.g., MARA, MARC, MARD) — these become database tables
3. Identify the **SELECT statement(s)** — these become MyBatis SQL queries
4. Identify the **processing logic** (LOOPs, calculations) — this becomes service layer code
5. Identify the **ALV field catalog** — these become JSON response fields

### Step 2: Create the Flyway Migration

1. For each SAP table referenced, create an equivalent table in the migration SQL
2. Map SAP data types to SQL types:
   - `CHAR(n)` → `VARCHAR(n)`
   - `NUMC(n)` → `VARCHAR(n)` (SAP numeric strings)
   - `DEC(p,s)` → `DECIMAL(p,s)`
   - `DATS` → `DATE`
   - `QUAN` → `DECIMAL(13,3)`
   - `CURR` → `DECIMAL(15,2)`
3. Add primary keys matching SAP table keys

### Step 3: Create Domain Entities

1. Create a Java class for each logical entity (may combine multiple SAP tables)
2. Map ABAP field names to Java camelCase:
   - `MATNR` → `materialNumber`
   - `WERKS` → `plant`
   - `MAKTX` → `description`
3. Use appropriate Java types:
   - ABAP `TYPE p DECIMALS 2` → `BigDecimal`
   - ABAP `TYPE i` → `int` or `Integer`
   - ABAP `TYPE c LENGTH n` → `String`
   - ABAP `TYPE d` or `sy-datum` → `LocalDate`

### Step 4: Create MyBatis Mapper

1. Translate the ABAP SELECT statement to SQL in the mapper XML
2. Map ABAP JOIN syntax to SQL JOINs
3. Map `SELECT-OPTIONS` ranges to `WHERE` clauses with optional conditions:
   ```xml
   <if test="plant != null">AND m.plant = #{plant}</if>
   ```
4. Map ABAP `INTO CORRESPONDING FIELDS OF TABLE` to MyBatis `resultMap`

### Step 5: Create Repository Interface and Implementation

1. Define a repository interface in `core/` with query methods
2. Implement it in `infrastructure/repository/` using the MyBatis mapper

### Step 6: Create Service Layer

1. Translate ABAP processing logic (LOOPs, calculations) to Java
2. Map ABAP `FIELD-SYMBOLS` assignments to stream operations or for-each loops
3. Preserve calculation logic exactly (stock values, statuses, etc.)

### Step 7: Create REST Controller

1. Map selection screen parameters to `@RequestParam` annotations
2. `SELECT-OPTIONS` with ranges → optional query params (simpler for REST)
3. Return the service result as JSON (Spring auto-serializes)
4. Use `@GetMapping` for reports (read-only operations)

### Step 8: Create Response DTO

1. Map ALV field catalog fields to DTO properties
2. Use the same camelCase naming as entities
3. Add any computed fields (stock value, status, etc.)

## Testing Requirements

1. **Controller Test**: Verify REST endpoint returns correct HTTP status and JSON structure
2. **Service Test**: Verify business logic calculations match ABAP behavior:
   - Stock value calculation: `quantity * (price / priceUnit)`
   - Status determination: same thresholds as ABAP
3. **Equivalence Fixtures**: Create test data that exercises the same paths as the ABAP program
4. Use `@SpringBootTest` with SQLite for integration tests

## Known Limitations

- **SELECT-OPTIONS ranges**: ABAP ranges have SIGN (I/E) and OPTION (EQ/BT/CP/etc.) semantics.
  REST APIs typically use simpler filtering. Document any range logic that was simplified.
- **ALV interactive features**: ALV supports drill-down, sorting, filtering at runtime. REST APIs
  return static data. Pagination should be added if the dataset is large.
- **Authorization**: ABAP authority checks (`AUTHORITY-CHECK`) have no direct REST equivalent.
  Flag these for human review to implement proper API security.
- **SY-fields**: ABAP system variables (SY-DATUM, SY-UNAME, SY-LANGU) need explicit handling
  in the Java service (current date, authenticated user, locale).
