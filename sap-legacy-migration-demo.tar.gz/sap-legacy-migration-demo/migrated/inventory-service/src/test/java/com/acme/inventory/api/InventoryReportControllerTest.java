package com.bobs.inventory.api;

import com.bobs.inventory.application.InventoryQueryService;
import com.bobs.inventory.application.data.InventoryReportData;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * REST endpoint tests for InventoryReportController.
 *
 * Verifies that the REST API returns the same data structure
 * that the ABAP ALV grid would display.
 */
@WebMvcTest(InventoryReportController.class)
class InventoryReportControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private InventoryQueryService queryService;

    @Test
    void shouldReturnInventoryReport() throws Exception {
        // Equivalent to ABAP: running report with s_werks = '1000'
        InventoryReportData item = new InventoryReportData();
        item.setMaterialNumber("FURN-001");
        item.setDescription("Oak Dining Table 6-Seater");
        item.setMaterialType("FURN");
        item.setPlant("1000");
        item.setStorageLocation("0001");
        item.setUnrestrictedStock(new BigDecimal("25.000"));
        item.setReorderPoint(new BigDecimal("10.000"));
        item.setStockValue(new BigDecimal("14999.75"));
        item.setStatus("OK");

        when(queryService.getInventoryReport(any(), any(), any(), any()))
                .thenReturn(Arrays.asList(item));

        mockMvc.perform(get("/api/inventory/report")
                        .param("plant", "1000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].materialNumber", is("FURN-001")))
                .andExpect(jsonPath("$[0].description", is("Oak Dining Table 6-Seater")))
                .andExpect(jsonPath("$[0].status", is("OK")));
    }

    @Test
    void shouldReturnNoContentWhenEmpty() throws Exception {
        // Equivalent to ABAP: MESSAGE 'No inventory data found' TYPE 'S' DISPLAY LIKE 'W'
        when(queryService.getInventoryReport(any(), any(), any(), any()))
                .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/inventory/report"))
                .andExpect(status().isNoContent());
    }

    @Test
    void shouldAcceptAllFilterParameters() throws Exception {
        // Equivalent to ABAP: filling all selection screen fields
        when(queryService.getInventoryReport(any(), any(), any(), any()))
                .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/inventory/report")
                        .param("plant", "1000")
                        .param("materialType", "FURN")
                        .param("dateFrom", "2024-01-01")
                        .param("dateTo", "2024-12-31"))
                .andExpect(status().isNoContent());
    }
}
