package com.bobs.inventory.application;

import com.bobs.inventory.application.data.InventoryReportData;
import com.bobs.inventory.core.MaterialRepository;
import com.bobs.inventory.core.PlantStock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Business logic tests for InventoryQueryService.
 *
 * These tests verify that the Java service produces the same results
 * as the ABAP FORM calculate_stock_values in z_inventory_report.abap.
 */
class InventoryQueryServiceTest {

    private InventoryQueryService service;
    private MaterialRepository repository;

    @BeforeEach
    void setUp() {
        repository = mock(MaterialRepository.class);
        service = new InventoryQueryService(repository);
    }

    @Test
    void shouldCalculateStockValue() {
        // ABAP: <fs_inv>-stock_val = <fs_inv>-labst * ( <fs_inv>-stprs / <fs_inv>-peinh )
        // 25 units * (599.99 / 1) = 14999.75
        BigDecimal result = service.calculateStockValue(
                new BigDecimal("25"), new BigDecimal("599.99"), 1);
        assertEquals(new BigDecimal("14999.75"), result);
    }

    @Test
    void shouldCalculateStockValueWithPriceUnit() {
        // 100 units * (50.00 / 10) = 500.00
        BigDecimal result = service.calculateStockValue(
                new BigDecimal("100"), new BigDecimal("50.00"), 10);
        assertEquals(new BigDecimal("500.00"), result);
    }

    @Test
    void shouldReturnZeroForZeroPriceUnit() {
        // ABAP: IF <fs_inv>-peinh > 0 — skip calculation if price unit is zero
        BigDecimal result = service.calculateStockValue(
                new BigDecimal("25"), new BigDecimal("599.99"), 0);
        assertEquals(BigDecimal.ZERO, result);
    }

    @Test
    void shouldReturnCriticalStatusForZeroStock() {
        // ABAP: IF <fs_inv>-labst <= 0 → CRITICAL
        assertEquals("CRITICAL",
                service.determineStockStatus(BigDecimal.ZERO, new BigDecimal("10")));
    }

    @Test
    void shouldReturnCriticalStatusForStockBelowHalfReorderPoint() {
        // ABAP: IF <fs_inv>-labst < ( <fs_inv>-minbe / 2 ) → CRITICAL
        // stock=3, reorderPoint=10, half=5 → 3 < 5 → CRITICAL
        assertEquals("CRITICAL",
                service.determineStockStatus(new BigDecimal("3"), new BigDecimal("10")));
    }

    @Test
    void shouldReturnLowStatusForStockBelowReorderPoint() {
        // ABAP: ELSEIF <fs_inv>-labst < <fs_inv>-minbe → LOW
        // stock=7, reorderPoint=10, half=5 → 7 >= 5 but 7 < 10 → LOW
        assertEquals("LOW",
                service.determineStockStatus(new BigDecimal("7"), new BigDecimal("10")));
    }

    @Test
    void shouldReturnOkStatusForStockAboveReorderPoint() {
        // ABAP: ELSE → OK
        // stock=25, reorderPoint=10 → 25 >= 10 → OK
        assertEquals("OK",
                service.determineStockStatus(new BigDecimal("25"), new BigDecimal("10")));
    }

    @Test
    void shouldReturnOkWhenNoReorderPointSet() {
        // ABAP: IF <fs_inv>-minbe > 0 — only check if reorder point is set
        assertEquals("OK",
                service.determineStockStatus(new BigDecimal("5"), BigDecimal.ZERO));
    }

    @Test
    void shouldBuildCompleteReport() {
        PlantStock stock = new PlantStock();
        stock.setMaterialNumber("FURN-001");
        stock.setDescription("Oak Dining Table 6-Seater");
        stock.setMaterialType("FURN");
        stock.setPlant("1000");
        stock.setStorageLocation("0001");
        stock.setUnrestrictedStock(new BigDecimal("25.000"));
        stock.setReorderPoint(new BigDecimal("10.000"));
        stock.setMaximumStock(new BigDecimal("50.000"));
        stock.setPriceUnit(1);
        stock.setStandardPrice(new BigDecimal("599.99"));

        when(repository.findStocks(any(), any(), any(), any()))
                .thenReturn(Arrays.asList(stock));

        List<InventoryReportData> report = service.getInventoryReport("1000", null, null, null);

        assertEquals(1, report.size());
        InventoryReportData data = report.get(0);
        assertEquals("FURN-001", data.getMaterialNumber());
        assertEquals(new BigDecimal("14999.75"), data.getStockValue());
        assertEquals("OK", data.getStatus());
    }
}
