package com.bobs.inventory.core;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Domain entity representing a material from the material master.
 *
 * Migrated from: SAP table MARA (Material Master - General Data)
 * Combined with MAKT (Material Descriptions) for the description field.
 */
public class Material {

    private String materialNumber;  // MARA-MATNR
    private String description;     // MAKT-MAKTX
    private String materialType;    // MARA-MTART (e.g., FURN, ACCS)
    private String materialGroup;   // MARA-MATKL
    private String baseUnit;        // MARA-MEINS
    private LocalDate createdDate;  // MARA-ERSDA

    public String getMaterialNumber() { return materialNumber; }
    public void setMaterialNumber(String materialNumber) { this.materialNumber = materialNumber; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getMaterialType() { return materialType; }
    public void setMaterialType(String materialType) { this.materialType = materialType; }

    public String getMaterialGroup() { return materialGroup; }
    public void setMaterialGroup(String materialGroup) { this.materialGroup = materialGroup; }

    public String getBaseUnit() { return baseUnit; }
    public void setBaseUnit(String baseUnit) { this.baseUnit = baseUnit; }

    public LocalDate getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDate createdDate) { this.createdDate = createdDate; }
}
