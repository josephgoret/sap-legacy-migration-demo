package com.bobs.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Acme Corporation — Inventory Report Service
 *
 * Migrated from: source-abap/z_inventory_report.abap
 * Pattern: ALV Report → REST API
 *
 * This service replaces the ABAP Z_INVENTORY_REPORT program,
 * exposing inventory data as a REST API instead of an ALV grid.
 */
@SpringBootApplication
public class InventoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(InventoryApplication.class, args);
    }
}
