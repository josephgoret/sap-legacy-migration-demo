package com.bobs.inventory.core;

import java.math.BigDecimal;

/**
 * Domain entity representing stock at a plant/storage location.
 *
 * Migrated from: JOIN of SAP tables MARA + MAKT + MARC + MARD + MBEW
 * This is the combined result of the ABAP SELECT in z_inventory_report.abap
 */
public class PlantStock {

    private String materialNumber;    // MARA-MATNR
    private String description;       // MAKT-MAKTX
    private String materialType;      // MARA-MTART
    private String plant;             // MARC-WERKS
    private String storageLocation;   // MARD-LGORT
    private BigDecimal unrestrictedStock; // MARD-LABST
    private BigDecimal reorderPoint;  // MARC-MINBE
    private BigDecimal maximumStock;  // MARC-MABST
    private int priceUnit;            // MARC-PEINH
    private BigDecimal standardPrice; // MBEW-STPRS

    public String getMaterialNumber() { return materialNumber; }
    public void setMaterialNumber(String materialNumber) { this.materialNumber = materialNumber; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getMaterialType() { return materialType; }
    public void setMaterialType(String materialType) { this.materialType = materialType; }

    public String getPlant() { return plant; }
    public void setPlant(String plant) { this.plant = plant; }

    public String getStorageLocation() { return storageLocation; }
    public void setStorageLocation(String storageLocation) { this.storageLocation = storageLocation; }

    public BigDecimal getUnrestrictedStock() { return unrestrictedStock; }
    public void setUnrestrictedStock(BigDecimal unrestrictedStock) { this.unrestrictedStock = unrestrictedStock; }

    public BigDecimal getReorderPoint() { return reorderPoint; }
    public void setReorderPoint(BigDecimal reorderPoint) { this.reorderPoint = reorderPoint; }

    public BigDecimal getMaximumStock() { return maximumStock; }
    public void setMaximumStock(BigDecimal maximumStock) { this.maximumStock = maximumStock; }

    public int getPriceUnit() { return priceUnit; }
    public void setPriceUnit(int priceUnit) { this.priceUnit = priceUnit; }

    public BigDecimal getStandardPrice() { return standardPrice; }
    public void setStandardPrice(BigDecimal standardPrice) { this.standardPrice = standardPrice; }
}
