package com.bobs.inventory.infrastructure.mybatis;

import com.bobs.inventory.core.PlantStock;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;

/**
 * MyBatis mapper interface for material/stock queries.
 *
 * SQL defined in: src/main/resources/mapper/MaterialMapper.xml
 * Migrated from: ABAP SELECT in z_inventory_report.abap
 */
@Mapper
public interface MaterialMapper {

    List<PlantStock> findStocks(
            @Param("plant") String plant,
            @Param("materialType") String materialType,
            @Param("dateFrom") LocalDate dateFrom,
            @Param("dateTo") LocalDate dateTo);
}
