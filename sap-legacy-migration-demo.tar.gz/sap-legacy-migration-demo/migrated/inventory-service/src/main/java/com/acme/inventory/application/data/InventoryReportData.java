package com.bobs.inventory.application.data;

import java.math.BigDecimal;

/**
 * DTO for inventory report response.
 *
 * Migrated from: ty_s_inventory structure in z_inventory_report.abap
 * Maps ALV field catalog fields to JSON response properties.
 *
 * ABAP field → JSON field:
 *   MATNR     → materialNumber
 *   MAKTX     → description
 *   MTART     → materialType
 *   WERKS     → plant
 *   LGORT     → storageLocation
 *   LABST     → unrestrictedStock
 *   MINBE     → reorderPoint
 *   MABST     → maximumStock
 *   STPRS     → standardPrice
 *   STOCK_VAL → stockValue (calculated)
 *   STATUS    → status (calculated: OK/LOW/CRITICAL)
 */
public class InventoryReportData {

    private String materialNumber;
    private String description;
    private String materialType;
    private String plant;
    private String storageLocation;
    private BigDecimal unrestrictedStock;
    private BigDecimal reorderPoint;
    private BigDecimal maximumStock;
    private BigDecimal standardPrice;
    private BigDecimal stockValue;
    private String status;

    public String getMaterialNumber() { return materialNumber; }
    public void setMaterialNumber(String materialNumber) { this.materialNumber = materialNumber; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getMaterialType() { return materialType; }
    public void setMaterialType(String materialType) { this.materialType = materialType; }

    public String getPlant() { return plant; }
    public void setPlant(String plant) { this.plant = plant; }

    public String getStorageLocation() { return storageLocation; }
    public void setStorageLocation(String storageLocation) { this.storageLocation = storageLocation; }

    public BigDecimal getUnrestrictedStock() { return unrestrictedStock; }
    public void setUnrestrictedStock(BigDecimal unrestrictedStock) { this.unrestrictedStock = unrestrictedStock; }

    public BigDecimal getReorderPoint() { return reorderPoint; }
    public void setReorderPoint(BigDecimal reorderPoint) { this.reorderPoint = reorderPoint; }

    public BigDecimal getMaximumStock() { return maximumStock; }
    public void setMaximumStock(BigDecimal maximumStock) { this.maximumStock = maximumStock; }

    public BigDecimal getStandardPrice() { return standardPrice; }
    public void setStandardPrice(BigDecimal standardPrice) { this.standardPrice = standardPrice; }

    public BigDecimal getStockValue() { return stockValue; }
    public void setStockValue(BigDecimal stockValue) { this.stockValue = stockValue; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
