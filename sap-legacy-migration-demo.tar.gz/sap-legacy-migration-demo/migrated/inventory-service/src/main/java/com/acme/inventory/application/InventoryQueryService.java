package com.bobs.inventory.application;

import com.bobs.inventory.application.data.InventoryReportData;
import com.bobs.inventory.core.Material;
import com.bobs.inventory.core.PlantStock;
import com.bobs.inventory.core.MaterialRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Service layer for inventory report queries.
 *
 * Migrated from: FORM calculate_stock_values in z_inventory_report.abap
 * Contains the business logic that was embedded in the ABAP report's
 * processing section (between SELECT and ALV display).
 */
@Service
public class InventoryQueryService {

    private final MaterialRepository materialRepository;

    public InventoryQueryService(MaterialRepository materialRepository) {
        this.materialRepository = materialRepository;
    }

    /**
     * Retrieves and enriches inventory data for the report.
     *
     * ABAP equivalent: START-OF-SELECTION + FORM calculate_stock_values
     */
    public List<InventoryReportData> getInventoryReport(
            String plant, String materialType, LocalDate dateFrom, LocalDate dateTo) {

        List<PlantStock> stocks = materialRepository.findStocks(plant, materialType, dateFrom, dateTo);

        List<InventoryReportData> report = new ArrayList<>();
        for (PlantStock stock : stocks) {
            InventoryReportData data = new InventoryReportData();
            data.setMaterialNumber(stock.getMaterialNumber());
            data.setDescription(stock.getDescription());
            data.setMaterialType(stock.getMaterialType());
            data.setPlant(stock.getPlant());
            data.setStorageLocation(stock.getStorageLocation());
            data.setUnrestrictedStock(stock.getUnrestrictedStock());
            data.setReorderPoint(stock.getReorderPoint());
            data.setMaximumStock(stock.getMaximumStock());
            data.setStandardPrice(stock.getStandardPrice());

            // Calculate stock value: quantity * (standard price / price unit)
            // ABAP: <fs_inv>-stock_val = <fs_inv>-labst * ( <fs_inv>-stprs / <fs_inv>-peinh )
            data.setStockValue(calculateStockValue(
                    stock.getUnrestrictedStock(),
                    stock.getStandardPrice(),
                    stock.getPriceUnit()));

            // Determine stock status based on reorder point
            // ABAP: IF <fs_inv>-labst <= 0 → CRITICAL, etc.
            data.setStatus(determineStockStatus(
                    stock.getUnrestrictedStock(),
                    stock.getReorderPoint()));

            report.add(data);
        }

        return report;
    }

    /**
     * Calculates stock value.
     *
     * ABAP equivalent:
     *   IF <fs_inv>-peinh > 0.
     *     <fs_inv>-stock_val = <fs_inv>-labst * ( <fs_inv>-stprs / <fs_inv>-peinh ).
     *   ENDIF.
     */
    BigDecimal calculateStockValue(BigDecimal quantity, BigDecimal standardPrice, int priceUnit) {
        if (priceUnit <= 0 || standardPrice == null || quantity == null) {
            return BigDecimal.ZERO;
        }
        return quantity.multiply(standardPrice)
                .divide(BigDecimal.valueOf(priceUnit), 2, RoundingMode.HALF_UP);
    }

    /**
     * Determines stock status based on reorder point thresholds.
     *
     * ABAP equivalent:
     *   IF <fs_inv>-labst <= 0 → CRITICAL
     *   ELSEIF <fs_inv>-labst < <fs_inv>-minbe / 2 → CRITICAL
     *   ELSEIF <fs_inv>-labst < <fs_inv>-minbe → LOW
     *   ELSE → OK
     */
    String determineStockStatus(BigDecimal stock, BigDecimal reorderPoint) {
        if (stock == null || stock.compareTo(BigDecimal.ZERO) <= 0) {
            return "CRITICAL";
        }

        if (reorderPoint != null && reorderPoint.compareTo(BigDecimal.ZERO) > 0) {
            if (stock.compareTo(reorderPoint) < 0) {
                BigDecimal halfReorder = reorderPoint.divide(BigDecimal.valueOf(2), 2, RoundingMode.HALF_UP);
                if (stock.compareTo(halfReorder) < 0) {
                    return "CRITICAL";
                }
                return "LOW";
            }
        }

        return "OK";
    }
}
