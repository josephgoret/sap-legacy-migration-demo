package com.bobs.inventory.api;

import com.bobs.inventory.application.InventoryQueryService;
import com.bobs.inventory.application.data.InventoryReportData;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

/**
 * REST controller for inventory reports.
 *
 * Migrated from: ABAP selection screen in z_inventory_report.abap
 * - s_werks (plant)       → @RequestParam plant
 * - s_mtart (material type) → @RequestParam materialType
 * - p_dtfrom / p_dtto     → @RequestParam dateFrom / dateTo
 *
 * ABAP equivalent: REUSE_ALV_GRID_DISPLAY → JSON response
 */
@RestController
@RequestMapping("/api/inventory")
public class InventoryReportController {

    private final InventoryQueryService queryService;

    public InventoryReportController(InventoryQueryService queryService) {
        this.queryService = queryService;
    }

    /**
     * GET /api/inventory/report
     *
     * Replaces the ALV grid display from z_inventory_report.abap.
     * Query parameters map to the ABAP selection screen parameters.
     */
    @GetMapping("/report")
    public ResponseEntity<List<InventoryReportData>> getInventoryReport(
            @RequestParam(required = false) String plant,
            @RequestParam(required = false) String materialType,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFrom,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateTo) {

        List<InventoryReportData> report = queryService.getInventoryReport(
                plant, materialType, dateFrom, dateTo);

        if (report.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(report);
    }
}
