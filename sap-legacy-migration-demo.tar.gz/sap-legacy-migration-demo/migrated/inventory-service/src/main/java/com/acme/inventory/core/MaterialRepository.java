package com.bobs.inventory.core;

import java.time.LocalDate;
import java.util.List;

/**
 * Repository interface for material/stock queries.
 *
 * Migrated from: ABAP SELECT statement in z_inventory_report.abap
 * Implementation provided by MyBatisMaterialRepository in infrastructure layer.
 */
public interface MaterialRepository {

    /**
     * Find stock data matching the given filters.
     *
     * ABAP equivalent: SELECT m~matnr t~maktx ... FROM mara AS m
     *   INNER JOIN makt/marc/mard/mbew ... WHERE ...
     */
    List<PlantStock> findStocks(String plant, String materialType,
                                LocalDate dateFrom, LocalDate dateTo);
}
