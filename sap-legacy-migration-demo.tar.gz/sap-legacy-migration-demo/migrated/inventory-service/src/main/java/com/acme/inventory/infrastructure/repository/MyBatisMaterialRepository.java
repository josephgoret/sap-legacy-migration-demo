package com.bobs.inventory.infrastructure.repository;

import com.bobs.inventory.core.MaterialRepository;
import com.bobs.inventory.core.PlantStock;
import com.bobs.inventory.infrastructure.mybatis.MaterialMapper;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * MyBatis implementation of MaterialRepository.
 *
 * Delegates to MaterialMapper which executes SQL defined in MaterialMapper.xml.
 * The SQL in the mapper XML is the direct translation of the ABAP SELECT statement.
 */
@Repository
public class MyBatisMaterialRepository implements MaterialRepository {

    private final MaterialMapper materialMapper;

    public MyBatisMaterialRepository(MaterialMapper materialMapper) {
        this.materialMapper = materialMapper;
    }

    @Override
    public List<PlantStock> findStocks(String plant, String materialType,
                                       LocalDate dateFrom, LocalDate dateTo) {
        return materialMapper.findStocks(plant, materialType, dateFrom, dateTo);
    }
}
