-- Flyway Migration V1: Create inventory tables
-- Migrated from: SAP tables MARA, MAKT, MARC, MARD, MBEW
--
-- These tables are simplified equivalents of the SAP material master tables
-- that z_inventory_report.abap reads from.

-- MATERIAL table (combines MARA + MAKT)
-- MARA: Material Master - General Data
-- MAKT: Material Descriptions
CREATE TABLE material (
    material_number VARCHAR(18) PRIMARY KEY,  -- MARA-MATNR
    description     VARCHAR(40),              -- MAKT-MAKTX
    material_type   VARCHAR(4),               -- MARA-MTART (FURN=Furniture, ACCS=Accessories)
    material_group  VARCHAR(9),               -- MARA-MATKL
    base_unit       VARCHAR(3),               -- MARA-MEINS (EA=Each, PC=Piece)
    created_date    DATE                      -- MARA-ERSDA
);

-- PLANT_STOCK table (combines MARC + MARD + MBEW)
-- MARC: Plant Data for Material
-- MARD: Storage Location Data for Material
-- MBEW: Material Valuation
CREATE TABLE plant_stock (
    material_number   VARCHAR(18) NOT NULL,   -- MARC-MATNR
    plant             VARCHAR(4)  NOT NULL,   -- MARC-WERKS
    storage_location  VARCHAR(4)  NOT NULL,   -- MARD-LGORT
    unrestricted_stock DECIMAL(13,3) DEFAULT 0, -- MARD-LABST
    reorder_point     DECIMAL(13,3) DEFAULT 0,  -- MARC-MINBE
    maximum_stock     DECIMAL(13,3) DEFAULT 0,  -- MARC-MABST
    price_unit        INTEGER DEFAULT 1,         -- MARC-PEINH
    standard_price    DECIMAL(15,2) DEFAULT 0,   -- MBEW-STPRS
    PRIMARY KEY (material_number, plant, storage_location),
    FOREIGN KEY (material_number) REFERENCES material(material_number)
);

-- Sample data: Acme Corporation inventory
INSERT INTO material (material_number, description, material_type, material_group, base_unit, created_date)
VALUES
    ('FURN-001', 'Oak Dining Table 6-Seater', 'FURN', 'TABLES', 'EA', '2024-01-15'),
    ('FURN-002', 'Leather Recliner Sofa', 'FURN', 'SOFAS', 'EA', '2024-02-01'),
    ('FURN-003', 'Queen Memory Foam Mattress', 'FURN', 'BEDS', 'EA', '2024-01-20'),
    ('FURN-004', 'Walnut Bookshelf 5-Tier', 'FURN', 'STORAGE', 'EA', '2024-03-10'),
    ('ACCS-001', 'Decorative Throw Pillow Set', 'ACCS', 'DECOR', 'SET', '2024-02-15'),
    ('ACCS-002', 'Table Runner - Linen', 'ACCS', 'DECOR', 'EA', '2024-03-01');

INSERT INTO plant_stock (material_number, plant, storage_location, unrestricted_stock, reorder_point, maximum_stock, price_unit, standard_price)
VALUES
    ('FURN-001', '1000', '0001', 25.000, 10.000, 50.000, 1, 599.99),
    ('FURN-001', '1000', '0002', 5.000, 10.000, 50.000, 1, 599.99),
    ('FURN-001', '2000', '0001', 0.000, 10.000, 50.000, 1, 599.99),
    ('FURN-002', '1000', '0001', 15.000, 8.000, 30.000, 1, 1299.99),
    ('FURN-003', '1000', '0001', 3.000, 12.000, 40.000, 1, 499.99),
    ('FURN-004', '2000', '0001', 40.000, 15.000, 60.000, 1, 249.99),
    ('ACCS-001', '1000', '0001', 100.000, 50.000, 200.000, 1, 39.99),
    ('ACCS-002', '1000', '0001', 8.000, 20.000, 100.000, 1, 24.99);
