package com.bobs.customer.application;

import com.bobs.customer.application.data.CustomerSyncRequest;
import com.bobs.customer.application.data.CustomerSyncResponse;
import com.bobs.customer.core.Customer;
import com.bobs.customer.core.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Business logic tests for CustomerSyncService.
 *
 * Tests verify idempotent upsert behavior matching the ABAP IDoc processor.
 */
class CustomerSyncServiceTest {

    private CustomerSyncService service;
    private CustomerRepository repository;

    @BeforeEach
    void setUp() {
        repository = mock(CustomerRepository.class);
        service = new CustomerSyncService(repository);
    }

    @Test
    void shouldCreateNewCustomer() {
        // ABAP: SELECT SINGLE returns sy-subrc <> 0 → INSERT kna1
        when(repository.findByCustomerNumber("C003")).thenReturn(Optional.empty());

        CustomerSyncRequest request = buildRequest("C003", "New Store");
        CustomerSyncResponse response = service.syncCustomer(request);

        assertEquals("CREATED", response.getOperation());
        assertEquals("SUCCESS", response.getStatus());
        verify(repository).insert(any(Customer.class));
        verify(repository, never()).update(any());
    }

    @Test
    void shouldUpdateExistingCustomer() {
        // ABAP: SELECT SINGLE returns sy-subrc = 0 → UPDATE kna1
        Customer existing = new Customer();
        existing.setCustomerNumber("C001");
        when(repository.findByCustomerNumber("C001")).thenReturn(Optional.of(existing));

        CustomerSyncRequest request = buildRequest("C001", "Updated Store");
        CustomerSyncResponse response = service.syncCustomer(request);

        assertEquals("UPDATED", response.getOperation());
        assertEquals("SUCCESS", response.getStatus());
        verify(repository).update(any(Customer.class));
        verify(repository, never()).insert(any());
    }

    @Test
    void shouldBeIdempotent() {
        // IDoc reprocessing: sending same data twice should not create duplicates
        Customer existing = new Customer();
        existing.setCustomerNumber("C001");
        when(repository.findByCustomerNumber("C001")).thenReturn(Optional.of(existing));

        CustomerSyncRequest request = buildRequest("C001", "Same Data");
        CustomerSyncResponse response1 = service.syncCustomer(request);
        CustomerSyncResponse response2 = service.syncCustomer(request);

        assertEquals("UPDATED", response1.getOperation());
        assertEquals("UPDATED", response2.getOperation());
    }

    @Test
    void shouldRejectMissingCustomerNumber() {
        // ABAP: IF lv_customer IS INITIAL → status 53
        CustomerSyncRequest request = new CustomerSyncRequest();
        request.setCustomerNumber("");

        assertThrows(ResponseStatusException.class,
                () -> service.syncCustomer(request));
    }

    private CustomerSyncRequest buildRequest(String customerNumber, String name) {
        CustomerSyncRequest request = new CustomerSyncRequest();
        request.setCustomerNumber(customerNumber);
        request.setName1(name);
        request.setCity("Manchester");
        request.setRegion("CT");
        request.setCountry("US");
        return request;
    }
}
