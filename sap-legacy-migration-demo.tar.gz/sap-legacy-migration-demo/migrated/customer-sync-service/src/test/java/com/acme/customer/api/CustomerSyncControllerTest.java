package com.bobs.customer.api;

import com.bobs.customer.application.CustomerSyncService;
import com.bobs.customer.application.data.CustomerSyncResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * REST endpoint tests for CustomerSyncController.
 *
 * Verifies create, update, and duplicate scenarios matching IDoc processing behavior.
 */
@WebMvcTest(CustomerSyncController.class)
class CustomerSyncControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CustomerSyncService syncService;

    @Test
    void shouldReturnCreatedForNewCustomer() throws Exception {
        // IDoc status 51 equivalent: new customer created
        CustomerSyncResponse response = new CustomerSyncResponse();
        response.setCustomerNumber("C003");
        response.setOperation("CREATED");
        response.setStatus("SUCCESS");
        response.setMessage("Customer C003 created successfully");

        when(syncService.syncCustomer(any())).thenReturn(response);

        String requestJson = "{"
                + "\"customerNumber\":\"C003\","
                + "\"name1\":\"New Furniture Store\","
                + "\"city\":\"Boston\","
                + "\"region\":\"MA\","
                + "\"country\":\"US\""
                + "}";

        mockMvc.perform(post("/api/customers/sync")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.customerNumber", is("C003")))
                .andExpect(jsonPath("$.operation", is("CREATED")))
                .andExpect(jsonPath("$.status", is("SUCCESS")));
    }

    @Test
    void shouldReturnOkForUpdatedCustomer() throws Exception {
        // IDoc status 51 equivalent: existing customer updated (idempotent)
        CustomerSyncResponse response = new CustomerSyncResponse();
        response.setCustomerNumber("C001");
        response.setOperation("UPDATED");
        response.setStatus("SUCCESS");
        response.setMessage("Customer C001 updated successfully");

        when(syncService.syncCustomer(any())).thenReturn(response);

        String requestJson = "{"
                + "\"customerNumber\":\"C001\","
                + "\"name1\":\"Riverside Home Staging (Updated)\","
                + "\"city\":\"Manchester\","
                + "\"region\":\"CT\","
                + "\"country\":\"US\""
                + "}";

        mockMvc.perform(post("/api/customers/sync")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.operation", is("UPDATED")));
    }

    @Test
    void shouldReturn400ForMissingCustomerNumber() throws Exception {
        // IDoc status 53 equivalent: missing required field
        String requestJson = "{\"name1\":\"Test\"}";

        mockMvc.perform(post("/api/customers/sync")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isBadRequest());
    }
}
