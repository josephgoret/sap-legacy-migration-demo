-- Flyway Migration V1: Create customer master tables
-- Migrated from: SAP tables KNA1 (General Data) + KNB1 (Company Code Data)

CREATE TABLE customer (
    customer_number VARCHAR(10) PRIMARY KEY,  -- KNA1-KUNNR
    name1           VARCHAR(40),              -- KNA1-NAME1
    name2           VARCHAR(40),              -- KNA1-NAME2
    street          VARCHAR(60),              -- KNA1-STRAS
    city            VARCHAR(40),              -- KNA1-ORT01
    region          VARCHAR(3),               -- KNA1-REGIO
    postal_code     VARCHAR(10),              -- KNA1-PSTLZ
    country         VARCHAR(3),               -- KNA1-LAND1
    phone           VARCHAR(30),              -- KNA1-TELF1
    fax             VARCHAR(30),              -- KNA1-TELFX
    email           VARCHAR(241),             -- KNA1-SMTP_ADDR
    account_group   VARCHAR(4),               -- KNA1-KTOKD
    language        VARCHAR(2),               -- KNA1-SPRAS
    created_date    DATE,                     -- KNA1-ERDAT
    changed_date    DATE,                     -- KNA1-AEDAT
    -- Company code data (from KNB1)
    company_code    VARCHAR(4),               -- KNB1-BUKRS
    payment_terms   VARCHAR(4),               -- KNB1-ZTERM
    credit_limit    DECIMAL(15,2),            -- KNB1-KLIMK
    recon_account   VARCHAR(10),              -- KNB1-AKONT
    payment_methods VARCHAR(10)               -- KNB1-ZWELS
);

-- Sample data: Acme Corporation customers
INSERT INTO customer (customer_number, name1, street, city, region, postal_code, country, phone, email, account_group, language, created_date, company_code, payment_terms, credit_limit)
VALUES
    ('C001', 'Riverside Home Staging', '123 Main St', 'Manchester', 'CT', '06040', 'US', '860-555-0101', 'staging@riverside.com', 'CUST', 'EN', '2024-01-01', '1000', 'NT30', 50000.00),
    ('C002', 'Metro Office Interiors', '456 Broadway', 'New York', 'NY', '10013', 'US', '212-555-0202', 'orders@metrooffice.com', 'CUST', 'EN', '2024-02-15', '1000', 'NT60', 100000.00);
