package com.bobs.customer.core;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Domain entity for customer master data.
 *
 * Migrated from: SAP tables KNA1 (General Data) + KNB1 (Company Code Data)
 */
public class Customer {

    private String customerNumber;  // KNA1-KUNNR
    private String name1;           // KNA1-NAME1
    private String name2;           // KNA1-NAME2
    private String street;          // KNA1-STRAS
    private String city;            // KNA1-ORT01
    private String region;          // KNA1-REGIO
    private String postalCode;      // KNA1-PSTLZ
    private String country;         // KNA1-LAND1
    private String phone;           // KNA1-TELF1
    private String fax;             // KNA1-TELFX
    private String email;           // KNA1-SMTP_ADDR
    private String accountGroup;    // KNA1-KTOKD
    private String language;        // KNA1-SPRAS
    private LocalDate createdDate;  // KNA1-ERDAT
    private LocalDate changedDate;  // KNA1-AEDAT

    // Company code data (from KNB1)
    private String companyCode;     // KNB1-BUKRS
    private String paymentTerms;    // KNB1-ZTERM
    private BigDecimal creditLimit; // KNB1-KLIMK
    private String reconAccount;    // KNB1-AKONT
    private String paymentMethods;  // KNB1-ZWELS

    public String getCustomerNumber() { return customerNumber; }
    public void setCustomerNumber(String customerNumber) { this.customerNumber = customerNumber; }

    public String getName1() { return name1; }
    public void setName1(String name1) { this.name1 = name1; }

    public String getName2() { return name2; }
    public void setName2(String name2) { this.name2 = name2; }

    public String getStreet() { return street; }
    public void setStreet(String street) { this.street = street; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public String getPostalCode() { return postalCode; }
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getFax() { return fax; }
    public void setFax(String fax) { this.fax = fax; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAccountGroup() { return accountGroup; }
    public void setAccountGroup(String accountGroup) { this.accountGroup = accountGroup; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public LocalDate getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDate createdDate) { this.createdDate = createdDate; }

    public LocalDate getChangedDate() { return changedDate; }
    public void setChangedDate(LocalDate changedDate) { this.changedDate = changedDate; }

    public String getCompanyCode() { return companyCode; }
    public void setCompanyCode(String companyCode) { this.companyCode = companyCode; }

    public String getPaymentTerms() { return paymentTerms; }
    public void setPaymentTerms(String paymentTerms) { this.paymentTerms = paymentTerms; }

    public BigDecimal getCreditLimit() { return creditLimit; }
    public void setCreditLimit(BigDecimal creditLimit) { this.creditLimit = creditLimit; }

    public String getReconAccount() { return reconAccount; }
    public void setReconAccount(String reconAccount) { this.reconAccount = reconAccount; }

    public String getPaymentMethods() { return paymentMethods; }
    public void setPaymentMethods(String paymentMethods) { this.paymentMethods = paymentMethods; }
}
