package com.bobs.customer.core;

import java.util.Optional;

/**
 * Repository interface for customer master data.
 *
 * Migrated from: ABAP SELECT/INSERT/UPDATE/MODIFY statements in z_customer_idoc.abap
 */
public interface CustomerRepository {

    Optional<Customer> findByCustomerNumber(String customerNumber);
    void insert(Customer customer);
    void update(Customer customer);
}
