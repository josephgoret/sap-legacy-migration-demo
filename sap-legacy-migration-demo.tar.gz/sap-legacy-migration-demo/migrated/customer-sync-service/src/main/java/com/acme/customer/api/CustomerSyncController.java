package com.bobs.customer.api;

import com.bobs.customer.application.CustomerSyncService;
import com.bobs.customer.application.data.CustomerSyncRequest;
import com.bobs.customer.application.data.CustomerSyncResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * REST controller for customer master data synchronization.
 *
 * Migrated from: FUNCTION z_bobs_process_customer_idoc
 * - IDoc segments → JSON request body
 * - IDoc status 51 → HTTP 200/201
 * - IDoc status 53 → HTTP 400
 *
 * This endpoint is idempotent: sending the same customer data twice
 * will update (not duplicate) the record, matching IDoc reprocessing behavior.
 */
@RestController
@RequestMapping("/api/customers")
public class CustomerSyncController {

    private final CustomerSyncService syncService;

    public CustomerSyncController(CustomerSyncService syncService) {
        this.syncService = syncService;
    }

    @PostMapping("/sync")
    public ResponseEntity<CustomerSyncResponse> syncCustomer(
            @Valid @RequestBody CustomerSyncRequest request) {
        CustomerSyncResponse response = syncService.syncCustomer(request);

        if ("CREATED".equals(response.getOperation())) {
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }
        return ResponseEntity.ok(response);
    }
}
