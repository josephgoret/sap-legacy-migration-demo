package com.bobs.customer.application.data;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

/**
 * Request DTO for customer sync endpoint.
 *
 * Migrated from: IDoc segments E1KNA1M (general data) and E1KNB1M (company code data)
 *
 * IDoc field → JSON field:
 *   KUNNR → customerNumber
 *   NAME1 → name1
 *   NAME2 → name2
 *   STRAS → street
 *   ORT01 → city
 *   REGIO → region
 *   PSTLZ → postalCode
 *   LAND1 → country
 *   TELF1 → phone
 *   TELFX → fax
 *   SMTP_ADDR → email
 *   KTOKD → accountGroup
 *   SPRAS → language
 */
public class CustomerSyncRequest {

    @NotBlank(message = "Customer number is required")
    private String customerNumber;
    private String name1;
    private String name2;
    private String street;
    private String city;
    private String region;
    private String postalCode;
    private String country;
    private String phone;
    private String fax;
    private String email;
    private String accountGroup;
    private String language;

    private CompanyCodeData companyCode;

    public String getCustomerNumber() { return customerNumber; }
    public void setCustomerNumber(String customerNumber) { this.customerNumber = customerNumber; }

    public String getName1() { return name1; }
    public void setName1(String name1) { this.name1 = name1; }

    public String getName2() { return name2; }
    public void setName2(String name2) { this.name2 = name2; }

    public String getStreet() { return street; }
    public void setStreet(String street) { this.street = street; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public String getPostalCode() { return postalCode; }
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getFax() { return fax; }
    public void setFax(String fax) { this.fax = fax; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAccountGroup() { return accountGroup; }
    public void setAccountGroup(String accountGroup) { this.accountGroup = accountGroup; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public CompanyCodeData getCompanyCode() { return companyCode; }
    public void setCompanyCode(CompanyCodeData companyCode) { this.companyCode = companyCode; }

    /**
     * Nested DTO for company code data.
     * Migrated from: IDoc segment E1KNB1M
     */
    public static class CompanyCodeData {
        private String companyCode;
        private String paymentTerms;
        private BigDecimal creditLimit;
        private String reconAccount;
        private String paymentMethods;

        public String getCompanyCode() { return companyCode; }
        public void setCompanyCode(String companyCode) { this.companyCode = companyCode; }

        public String getPaymentTerms() { return paymentTerms; }
        public void setPaymentTerms(String paymentTerms) { this.paymentTerms = paymentTerms; }

        public BigDecimal getCreditLimit() { return creditLimit; }
        public void setCreditLimit(BigDecimal creditLimit) { this.creditLimit = creditLimit; }

        public String getReconAccount() { return reconAccount; }
        public void setReconAccount(String reconAccount) { this.reconAccount = reconAccount; }

        public String getPaymentMethods() { return paymentMethods; }
        public void setPaymentMethods(String paymentMethods) { this.paymentMethods = paymentMethods; }
    }
}
