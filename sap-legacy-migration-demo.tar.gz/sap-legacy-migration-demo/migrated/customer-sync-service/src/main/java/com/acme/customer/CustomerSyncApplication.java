package com.bobs.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Acme Corporation — Customer Sync Service
 *
 * Migrated from: source-abap/z_customer_idoc.abap
 * Pattern: IDoc Processor → Event-Driven REST API
 */
@SpringBootApplication
public class CustomerSyncApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomerSyncApplication.class, args);
    }
}
