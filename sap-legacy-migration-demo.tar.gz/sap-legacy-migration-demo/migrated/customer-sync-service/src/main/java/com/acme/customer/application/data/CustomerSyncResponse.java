package com.bobs.customer.application.data;

/**
 * Response DTO for customer sync endpoint.
 *
 * Migrated from: IDoc status record (EDIDS)
 *
 * IDoc status → Response fields:
 *   Status 51 (success) → status="SUCCESS", operation="CREATED"/"UPDATED"
 *   Status 53 (error)   → HTTP 400 with error message
 */
public class CustomerSyncResponse {

    private String customerNumber;
    private String operation;   // "CREATED" or "UPDATED"
    private String status;      // "SUCCESS" or "ERROR"
    private String message;

    public String getCustomerNumber() { return customerNumber; }
    public void setCustomerNumber(String customerNumber) { this.customerNumber = customerNumber; }

    public String getOperation() { return operation; }
    public void setOperation(String operation) { this.operation = operation; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
