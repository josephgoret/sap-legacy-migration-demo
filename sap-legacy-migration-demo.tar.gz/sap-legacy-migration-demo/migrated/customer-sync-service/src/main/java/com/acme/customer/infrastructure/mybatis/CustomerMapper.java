package com.bobs.customer.infrastructure.mybatis;

import com.bobs.customer.core.Customer;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CustomerMapper {

    Customer findByCustomerNumber(@Param("customerNumber") String customerNumber);
    void insert(Customer customer);
    void update(Customer customer);
}
