package com.bobs.customer.infrastructure.repository;

import com.bobs.customer.core.Customer;
import com.bobs.customer.core.CustomerRepository;
import com.bobs.customer.infrastructure.mybatis.CustomerMapper;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class MyBatisCustomerRepository implements CustomerRepository {

    private final CustomerMapper mapper;

    public MyBatisCustomerRepository(CustomerMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public Optional<Customer> findByCustomerNumber(String customerNumber) {
        return Optional.ofNullable(mapper.findByCustomerNumber(customerNumber));
    }

    @Override
    public void insert(Customer customer) {
        mapper.insert(customer);
    }

    @Override
    public void update(Customer customer) {
        mapper.update(customer);
    }
}
