package com.bobs.customer.application;

import com.bobs.customer.application.data.CustomerSyncRequest;
import com.bobs.customer.application.data.CustomerSyncResponse;
import com.bobs.customer.core.Customer;
import com.bobs.customer.core.CustomerRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.Optional;

/**
 * Service layer for customer master data synchronization.
 *
 * Migrated from: FUNCTION z_bobs_process_customer_idoc body
 *
 * Implements the IDoc processor's duplicate-check-then-create-or-update pattern
 * as an idempotent upsert operation.
 */
@Service
public class CustomerSyncService {

    private final CustomerRepository repository;

    public CustomerSyncService(CustomerRepository repository) {
        this.repository = repository;
    }

    /**
     * Synchronizes customer data (idempotent upsert).
     *
     * ABAP equivalent: Steps 1-5 of z_bobs_process_customer_idoc
     * - Parse segments → JSON deserialization (handled by Spring)
     * - Duplicate check → repository.findByCustomerNumber()
     * - CREATE or UPDATE → repository.insert() or repository.update()
     * - IDoc status 51 → SUCCESS response
     * - IDoc status 53 → throw exception
     */
    @Transactional
    public CustomerSyncResponse syncCustomer(CustomerSyncRequest request) {
        // Validate customer number (ABAP: IF lv_customer IS INITIAL → status 53)
        if (request.getCustomerNumber() == null || request.getCustomerNumber().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Customer number missing in request");
        }

        // Step 3: Duplicate detection (ABAP: SELECT SINGLE 'X' FROM kna1 WHERE kunnr = lv_customer)
        Optional<Customer> existing = repository.findByCustomerNumber(request.getCustomerNumber());

        Customer customer = mapRequestToEntity(request);
        String operation;

        if (existing.isPresent()) {
            // UPDATE path (ABAP: UPDATE kna1 FROM ls_kna1)
            customer.setChangedDate(LocalDate.now());
            repository.update(customer);
            operation = "UPDATED";
        } else {
            // CREATE path (ABAP: INSERT kna1 FROM ls_kna1)
            customer.setCreatedDate(LocalDate.now());
            repository.insert(customer);
            operation = "CREATED";
        }

        // Return success (ABAP: ls_status-status = '51')
        CustomerSyncResponse response = new CustomerSyncResponse();
        response.setCustomerNumber(request.getCustomerNumber());
        response.setOperation(operation);
        response.setStatus("SUCCESS");
        response.setMessage("Customer " + request.getCustomerNumber() + " " +
                operation.toLowerCase() + " successfully");
        return response;
    }

    private Customer mapRequestToEntity(CustomerSyncRequest request) {
        Customer customer = new Customer();
        customer.setCustomerNumber(request.getCustomerNumber());
        customer.setName1(request.getName1());
        customer.setName2(request.getName2());
        customer.setStreet(request.getStreet());
        customer.setCity(request.getCity());
        customer.setRegion(request.getRegion());
        customer.setPostalCode(request.getPostalCode());
        customer.setCountry(request.getCountry());
        customer.setPhone(request.getPhone());
        customer.setFax(request.getFax());
        customer.setEmail(request.getEmail());
        customer.setAccountGroup(request.getAccountGroup());
        customer.setLanguage(request.getLanguage());

        if (request.getCompanyCode() != null) {
            customer.setCompanyCode(request.getCompanyCode().getCompanyCode());
            customer.setPaymentTerms(request.getCompanyCode().getPaymentTerms());
            customer.setCreditLimit(request.getCompanyCode().getCreditLimit());
            customer.setReconAccount(request.getCompanyCode().getReconAccount());
            customer.setPaymentMethods(request.getCompanyCode().getPaymentMethods());
        }

        return customer;
    }
}
