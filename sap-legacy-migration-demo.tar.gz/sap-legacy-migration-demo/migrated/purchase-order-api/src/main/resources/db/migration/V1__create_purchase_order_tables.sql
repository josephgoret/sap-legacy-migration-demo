-- Flyway Migration V1: Create purchase order tables
-- Migrated from: SAP tables EKKO, EKPO, LFA1, MARA, T001W

-- VENDOR table (from LFA1 - Vendor Master)
CREATE TABLE vendor (
    vendor_id   VARCHAR(10) PRIMARY KEY,
    name        VARCHAR(80),
    city        VARCHAR(40),
    country     VARCHAR(3)
);

-- MATERIAL table (from MARA - Material Master)
CREATE TABLE material (
    material_number VARCHAR(18) PRIMARY KEY,
    description     VARCHAR(40),
    material_type   VARCHAR(4),
    material_group  VARCHAR(9)
);

-- PLANT table (from T001W - Plants/Branches)
CREATE TABLE plant (
    plant_id    VARCHAR(4) PRIMARY KEY,
    name        VARCHAR(40),
    city        VARCHAR(40)
);

-- PURCHASE_ORDER table (from EKKO - Purchasing Document Header)
CREATE TABLE purchase_order (
    po_number       VARCHAR(10) PRIMARY KEY,
    vendor_id       VARCHAR(10) NOT NULL,
    purchasing_org  VARCHAR(4),
    purchasing_group VARCHAR(3),
    company_code    VARCHAR(4),
    document_type   VARCHAR(4) DEFAULT 'NB',
    created_date    DATE,
    FOREIGN KEY (vendor_id) REFERENCES vendor(vendor_id)
);

-- PURCHASE_ORDER_ITEM table (from EKPO - Purchasing Document Item)
CREATE TABLE purchase_order_item (
    po_number       VARCHAR(10) NOT NULL,
    item_number     VARCHAR(5)  NOT NULL,
    material_number VARCHAR(18),
    short_text      VARCHAR(40),
    quantity        DECIMAL(13,3),
    unit            VARCHAR(3),
    net_price       DECIMAL(15,2),
    plant           VARCHAR(4),
    storage_location VARCHAR(4),
    material_group  VARCHAR(9),
    PRIMARY KEY (po_number, item_number),
    FOREIGN KEY (po_number) REFERENCES purchase_order(po_number)
);

-- Sample reference data
INSERT INTO vendor (vendor_id, name, city, country)
VALUES
    ('V001', 'Furniture Supply Co.', 'Grand Rapids', 'US'),
    ('V002', 'Pacific Timber Ltd.', 'Portland', 'US'),
    ('V003', 'Comfort Fabrics Inc.', 'High Point', 'US');

INSERT INTO material (material_number, description, material_type, material_group)
VALUES
    ('FURN-001', 'Oak Dining Table 6-Seater', 'FURN', 'TABLES'),
    ('FURN-002', 'Leather Recliner Sofa', 'FURN', 'SOFAS'),
    ('FURN-003', 'Queen Memory Foam Mattress', 'FURN', 'BEDS'),
    ('FURN-004', 'Walnut Bookshelf 5-Tier', 'FURN', 'STORAGE'),
    ('ACCS-001', 'Decorative Throw Pillow Set', 'ACCS', 'DECOR');

INSERT INTO plant (plant_id, name, city)
VALUES
    ('1000', 'Main Warehouse - Manchester', 'Manchester'),
    ('2000', 'Distribution Center - Newark', 'Newark'),
    ('3000', 'Store - Farmingdale', 'Farmingdale');
