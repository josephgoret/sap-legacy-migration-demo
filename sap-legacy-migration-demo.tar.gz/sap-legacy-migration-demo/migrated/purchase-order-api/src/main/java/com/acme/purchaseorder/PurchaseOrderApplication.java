package com.bobs.purchaseorder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Acme Corporation — Purchase Order API
 *
 * Migrated from: source-abap/z_purchase_order_rfc.abap
 * Pattern: RFC Function Module → REST API
 */
@SpringBootApplication
public class PurchaseOrderApplication {

    public static void main(String[] args) {
        SpringApplication.run(PurchaseOrderApplication.class, args);
    }
}
