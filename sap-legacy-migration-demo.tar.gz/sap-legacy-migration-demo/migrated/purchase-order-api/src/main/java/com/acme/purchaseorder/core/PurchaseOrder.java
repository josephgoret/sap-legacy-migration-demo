package com.bobs.purchaseorder.core;

import java.time.LocalDate;

/**
 * Domain entity for purchase order header.
 *
 * Migrated from: SAP table EKKO (Purchasing Document Header)
 */
public class PurchaseOrder {

    private String poNumber;        // EKKO-EBELN
    private String vendorId;        // EKKO-LIFNR
    private String purchasingOrg;   // EKKO-EKORG
    private String purchasingGroup; // EKKO-EKGRP
    private String companyCode;     // EKKO-BUKRS
    private String documentType;    // EKKO-BSART
    private LocalDate createdDate;  // EKKO-AEDAT

    public String getPoNumber() { return poNumber; }
    public void setPoNumber(String poNumber) { this.poNumber = poNumber; }

    public String getVendorId() { return vendorId; }
    public void setVendorId(String vendorId) { this.vendorId = vendorId; }

    public String getPurchasingOrg() { return purchasingOrg; }
    public void setPurchasingOrg(String purchasingOrg) { this.purchasingOrg = purchasingOrg; }

    public String getPurchasingGroup() { return purchasingGroup; }
    public void setPurchasingGroup(String purchasingGroup) { this.purchasingGroup = purchasingGroup; }

    public String getCompanyCode() { return companyCode; }
    public void setCompanyCode(String companyCode) { this.companyCode = companyCode; }

    public String getDocumentType() { return documentType; }
    public void setDocumentType(String documentType) { this.documentType = documentType; }

    public LocalDate getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDate createdDate) { this.createdDate = createdDate; }
}
