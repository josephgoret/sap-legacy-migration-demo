package com.bobs.purchaseorder.core;

import java.math.BigDecimal;

/**
 * Domain entity for purchase order line item.
 *
 * Migrated from: SAP table EKPO (Purchasing Document Item)
 */
public class PurchaseOrderItem {

    private String poNumber;        // EKPO-EBELN
    private String itemNumber;      // EKPO-EBELP
    private String materialNumber;  // EKPO-MATNR
    private String shortText;       // EKPO-TXZ01
    private BigDecimal quantity;    // EKPO-MENGE
    private String unit;            // EKPO-MEINS
    private BigDecimal netPrice;    // EKPO-NETPR
    private String plant;           // EKPO-WERKS
    private String storageLocation; // EKPO-LGORT
    private String materialGroup;   // EKPO-MATKL

    public String getPoNumber() { return poNumber; }
    public void setPoNumber(String poNumber) { this.poNumber = poNumber; }

    public String getItemNumber() { return itemNumber; }
    public void setItemNumber(String itemNumber) { this.itemNumber = itemNumber; }

    public String getMaterialNumber() { return materialNumber; }
    public void setMaterialNumber(String materialNumber) { this.materialNumber = materialNumber; }

    public String getShortText() { return shortText; }
    public void setShortText(String shortText) { this.shortText = shortText; }

    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public BigDecimal getNetPrice() { return netPrice; }
    public void setNetPrice(BigDecimal netPrice) { this.netPrice = netPrice; }

    public String getPlant() { return plant; }
    public void setPlant(String plant) { this.plant = plant; }

    public String getStorageLocation() { return storageLocation; }
    public void setStorageLocation(String storageLocation) { this.storageLocation = storageLocation; }

    public String getMaterialGroup() { return materialGroup; }
    public void setMaterialGroup(String materialGroup) { this.materialGroup = materialGroup; }
}
