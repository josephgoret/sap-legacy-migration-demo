package com.bobs.purchaseorder.infrastructure.repository;

import com.bobs.purchaseorder.core.PurchaseOrder;
import com.bobs.purchaseorder.core.PurchaseOrderItem;
import com.bobs.purchaseorder.core.PurchaseOrderRepository;
import com.bobs.purchaseorder.infrastructure.mybatis.PurchaseOrderMapper;
import org.springframework.stereotype.Repository;

@Repository
public class MyBatisPurchaseOrderRepository implements PurchaseOrderRepository {

    private final PurchaseOrderMapper mapper;

    public MyBatisPurchaseOrderRepository(PurchaseOrderMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public boolean vendorExists(String vendorId) {
        return mapper.countVendorById(vendorId) > 0;
    }

    @Override
    public boolean materialExists(String materialNumber) {
        return mapper.countMaterialById(materialNumber) > 0;
    }

    @Override
    public boolean plantExists(String plant) {
        return mapper.countPlantById(plant) > 0;
    }

    @Override
    public void insertOrder(PurchaseOrder order) {
        mapper.insertOrder(order);
    }

    @Override
    public void insertOrderItem(PurchaseOrderItem item) {
        mapper.insertOrderItem(item);
    }
}
