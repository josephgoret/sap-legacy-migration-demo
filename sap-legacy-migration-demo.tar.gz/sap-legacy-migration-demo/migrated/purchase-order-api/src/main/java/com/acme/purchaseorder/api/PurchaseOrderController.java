package com.bobs.purchaseorder.api;

import com.bobs.purchaseorder.application.PurchaseOrderService;
import com.bobs.purchaseorder.application.data.CreateOrderRequest;
import com.bobs.purchaseorder.application.data.CreateOrderResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * REST controller for purchase order creation.
 *
 * Migrated from: FUNCTION z_bobs_create_purchase_order
 * - IMPORTING params → CreateOrderRequest body
 * - EXPORTING params → CreateOrderResponse body
 * - TABLES IT_ITEMS → List<OrderItemRequest> in request
 * - EXCEPTIONS → HTTP error codes
 */
@RestController
@RequestMapping("/api/purchase-orders")
public class PurchaseOrderController {

    private final PurchaseOrderService orderService;

    public PurchaseOrderController(PurchaseOrderService orderService) {
        this.orderService = orderService;
    }

    /**
     * POST /api/purchase-orders
     *
     * Replaces the RFC function module Z_BOBS_CREATE_PURCHASE_ORDER.
     * ABAP EXCEPTIONS map to HTTP error responses.
     */
    @PostMapping
    public ResponseEntity<CreateOrderResponse> createPurchaseOrder(
            @Valid @RequestBody CreateOrderRequest request) {
        CreateOrderResponse response = orderService.createPurchaseOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}
