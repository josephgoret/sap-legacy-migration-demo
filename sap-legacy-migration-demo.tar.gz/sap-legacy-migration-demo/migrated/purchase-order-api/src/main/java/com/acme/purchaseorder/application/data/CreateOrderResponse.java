package com.bobs.purchaseorder.application.data;

/**
 * Response DTO for purchase order creation.
 *
 * Migrated from: EXPORTING parameters of Z_BOBS_CREATE_PURCHASE_ORDER
 *
 * ABAP parameter → Java field:
 *   EV_PO_NUMBER → poNumber
 *   EV_MESSAGE   → message
 */
public class CreateOrderResponse {

    private String poNumber;
    private String message;

    public String getPoNumber() { return poNumber; }
    public void setPoNumber(String poNumber) { this.poNumber = poNumber; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
