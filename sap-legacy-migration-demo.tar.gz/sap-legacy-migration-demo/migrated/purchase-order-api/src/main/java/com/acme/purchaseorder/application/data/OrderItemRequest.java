package com.bobs.purchaseorder.application.data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;

/**
 * Request DTO for a purchase order line item.
 *
 * Migrated from: ZBOBS_PO_ITEM structure (TABLES parameter)
 *
 * ABAP field → Java field:
 *   EBELP → itemNumber
 *   MATNR → materialNumber
 *   TXZ01 → shortText
 *   MENGE → quantity
 *   MEINS → unit
 *   NETPR → netPrice
 *   WERKS → plant
 *   LGORT → storageLocation
 *   MATKL → materialGroup
 */
public class OrderItemRequest {

    @NotBlank
    private String itemNumber;

    @NotBlank
    private String materialNumber;

    private String shortText;

    @NotNull
    @Positive
    private BigDecimal quantity;

    private String unit;

    @NotNull
    @Positive
    private BigDecimal netPrice;

    @NotBlank
    private String plant;

    private String storageLocation;
    private String materialGroup;

    public String getItemNumber() { return itemNumber; }
    public void setItemNumber(String itemNumber) { this.itemNumber = itemNumber; }

    public String getMaterialNumber() { return materialNumber; }
    public void setMaterialNumber(String materialNumber) { this.materialNumber = materialNumber; }

    public String getShortText() { return shortText; }
    public void setShortText(String shortText) { this.shortText = shortText; }

    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public BigDecimal getNetPrice() { return netPrice; }
    public void setNetPrice(BigDecimal netPrice) { this.netPrice = netPrice; }

    public String getPlant() { return plant; }
    public void setPlant(String plant) { this.plant = plant; }

    public String getStorageLocation() { return storageLocation; }
    public void setStorageLocation(String storageLocation) { this.storageLocation = storageLocation; }

    public String getMaterialGroup() { return materialGroup; }
    public void setMaterialGroup(String materialGroup) { this.materialGroup = materialGroup; }
}
