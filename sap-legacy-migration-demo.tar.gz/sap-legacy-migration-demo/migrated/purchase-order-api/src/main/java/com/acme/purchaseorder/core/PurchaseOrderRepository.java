package com.bobs.purchaseorder.core;

/**
 * Repository interface for purchase order operations.
 *
 * Migrated from: ABAP INSERT/SELECT statements in z_purchase_order_rfc.abap
 */
public interface PurchaseOrderRepository {

    boolean vendorExists(String vendorId);
    boolean materialExists(String materialNumber);
    boolean plantExists(String plant);

    void insertOrder(PurchaseOrder order);
    void insertOrderItem(PurchaseOrderItem item);
}
