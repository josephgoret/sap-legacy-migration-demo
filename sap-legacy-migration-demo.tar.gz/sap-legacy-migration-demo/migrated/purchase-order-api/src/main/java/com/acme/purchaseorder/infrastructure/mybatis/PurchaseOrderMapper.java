package com.bobs.purchaseorder.infrastructure.mybatis;

import com.bobs.purchaseorder.core.PurchaseOrder;
import com.bobs.purchaseorder.core.PurchaseOrderItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PurchaseOrderMapper {

    int countVendorById(@Param("vendorId") String vendorId);
    int countMaterialById(@Param("materialNumber") String materialNumber);
    int countPlantById(@Param("plant") String plant);

    void insertOrder(PurchaseOrder order);
    void insertOrderItem(PurchaseOrderItem item);
}
