package com.bobs.purchaseorder.application;

import com.bobs.purchaseorder.application.data.CreateOrderRequest;
import com.bobs.purchaseorder.application.data.CreateOrderResponse;
import com.bobs.purchaseorder.application.data.OrderItemRequest;
import com.bobs.purchaseorder.core.PurchaseOrder;
import com.bobs.purchaseorder.core.PurchaseOrderItem;
import com.bobs.purchaseorder.core.PurchaseOrderRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Service layer for purchase order creation.
 *
 * Migrated from: FUNCTION z_bobs_create_purchase_order body
 * Contains validation and creation logic from the RFC function module.
 */
@Service
public class PurchaseOrderService {

    private final PurchaseOrderRepository repository;

    public PurchaseOrderService(PurchaseOrderRepository repository) {
        this.repository = repository;
    }

    /**
     * Creates a new purchase order with validation.
     *
     * ABAP equivalent: The entire function body of Z_BOBS_CREATE_PURCHASE_ORDER
     * - Step 1: Validate vendor   → RAISE vendor_not_found    → 404
     * - Step 2: Validate items    → RAISE material_not_found  → 404
     *                             → RAISE plant_invalid       → 400
     * - Step 3: Generate PO#      → NUMBER_GET_NEXT
     * - Step 4-5: Insert header+items → INSERT ekko/ekpo
     * - Step 6: Commit            → COMMIT WORK AND WAIT
     */
    @Transactional
    public CreateOrderResponse createPurchaseOrder(CreateOrderRequest request) {
        // Step 1: Validate vendor exists
        // ABAP: SELECT SINGLE 'X' INTO lv_vendor_exists FROM lfa1 WHERE lifnr = iv_vendor
        if (!repository.vendorExists(request.getVendorId())) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Vendor " + request.getVendorId() + " does not exist");
        }

        // Step 2: Validate items
        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "At least one line item is required");
        }

        for (OrderItemRequest item : request.getItems()) {
            // Check material exists
            // ABAP: SELECT SINGLE 'X' INTO lv_material_exists FROM mara WHERE matnr = it_items-matnr
            if (!repository.materialExists(item.getMaterialNumber())) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Material " + item.getMaterialNumber() + " does not exist");
            }
            // Check plant is valid
            // ABAP: SELECT SINGLE 'X' INTO lv_plant_valid FROM t001w WHERE werks = it_items-werks
            if (!repository.plantExists(item.getPlant())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Plant " + item.getPlant() + " is not valid");
            }
            // Validate quantity
            if (item.getQuantity() == null || item.getQuantity().signum() <= 0) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Item " + item.getItemNumber() + ": quantity must be positive");
            }
        }

        // Step 3: Generate PO number
        // ABAP: CALL FUNCTION 'NUMBER_GET_NEXT' ... object = 'EINKBELEG'
        String poNumber = generatePoNumber();

        // Step 4: Create PO header
        PurchaseOrder order = new PurchaseOrder();
        order.setPoNumber(poNumber);
        order.setVendorId(request.getVendorId());
        order.setPurchasingOrg(request.getPurchasingOrg());
        order.setPurchasingGroup(request.getPurchasingGroup());
        order.setCompanyCode(request.getCompanyCode());
        order.setDocumentType(request.getDocumentType() != null ? request.getDocumentType() : "NB");
        order.setCreatedDate(LocalDate.now());

        repository.insertOrder(order);

        // Step 5: Create PO items
        List<PurchaseOrderItem> items = new ArrayList<>();
        for (OrderItemRequest itemReq : request.getItems()) {
            PurchaseOrderItem item = new PurchaseOrderItem();
            item.setPoNumber(poNumber);
            item.setItemNumber(itemReq.getItemNumber());
            item.setMaterialNumber(itemReq.getMaterialNumber());
            item.setShortText(itemReq.getShortText());
            item.setQuantity(itemReq.getQuantity());
            item.setUnit(itemReq.getUnit());
            item.setNetPrice(itemReq.getNetPrice());
            item.setPlant(itemReq.getPlant());
            item.setStorageLocation(itemReq.getStorageLocation());
            item.setMaterialGroup(itemReq.getMaterialGroup());
            items.add(item);
        }

        for (PurchaseOrderItem item : items) {
            repository.insertOrderItem(item);
        }

        // Step 6: Return success (COMMIT handled by @Transactional)
        CreateOrderResponse response = new CreateOrderResponse();
        response.setPoNumber(poNumber);
        response.setMessage("Purchase order " + poNumber + " created successfully");
        return response;
    }

    private String generatePoNumber() {
        return "45" + String.format("%08d", Math.abs(UUID.randomUUID().hashCode() % 100000000));
    }
}
