package com.bobs.purchaseorder.application.data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * Request DTO for purchase order creation.
 *
 * Migrated from: IMPORTING + TABLES parameters of Z_BOBS_CREATE_PURCHASE_ORDER
 *
 * ABAP parameter → Java field:
 *   IV_VENDOR    → vendorId
 *   IV_PURCH_ORG → purchasingOrg
 *   IV_PURCH_GRP → purchasingGroup
 *   IV_COMP_CODE → companyCode
 *   IV_DOC_TYPE  → documentType
 *   IT_ITEMS     → items
 */
public class CreateOrderRequest {

    @NotBlank(message = "Vendor ID is required")
    private String vendorId;

    @NotBlank(message = "Purchasing organization is required")
    private String purchasingOrg;

    private String purchasingGroup;

    @NotBlank(message = "Company code is required")
    private String companyCode;

    private String documentType;

    @NotEmpty(message = "At least one line item is required")
    @Valid
    private List<OrderItemRequest> items;

    public String getVendorId() { return vendorId; }
    public void setVendorId(String vendorId) { this.vendorId = vendorId; }

    public String getPurchasingOrg() { return purchasingOrg; }
    public void setPurchasingOrg(String purchasingOrg) { this.purchasingOrg = purchasingOrg; }

    public String getPurchasingGroup() { return purchasingGroup; }
    public void setPurchasingGroup(String purchasingGroup) { this.purchasingGroup = purchasingGroup; }

    public String getCompanyCode() { return companyCode; }
    public void setCompanyCode(String companyCode) { this.companyCode = companyCode; }

    public String getDocumentType() { return documentType; }
    public void setDocumentType(String documentType) { this.documentType = documentType; }

    public List<OrderItemRequest> getItems() { return items; }
    public void setItems(List<OrderItemRequest> items) { this.items = items; }
}
