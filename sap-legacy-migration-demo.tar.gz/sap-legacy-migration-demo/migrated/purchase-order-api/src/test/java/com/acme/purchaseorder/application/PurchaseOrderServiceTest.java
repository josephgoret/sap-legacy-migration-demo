package com.bobs.purchaseorder.application;

import com.bobs.purchaseorder.application.data.CreateOrderRequest;
import com.bobs.purchaseorder.application.data.CreateOrderResponse;
import com.bobs.purchaseorder.application.data.OrderItemRequest;
import com.bobs.purchaseorder.core.PurchaseOrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Business logic tests for PurchaseOrderService.
 *
 * Each test maps to a validation path in the ABAP RFC function module.
 */
class PurchaseOrderServiceTest {

    private PurchaseOrderService service;
    private PurchaseOrderRepository repository;

    @BeforeEach
    void setUp() {
        repository = mock(PurchaseOrderRepository.class);
        service = new PurchaseOrderService(repository);
    }

    @Test
    void shouldCreatePurchaseOrderSuccessfully() {
        // Equivalent to ABAP: all validations pass, INSERT ekko + ekpo, COMMIT WORK
        when(repository.vendorExists("V001")).thenReturn(true);
        when(repository.materialExists("FURN-001")).thenReturn(true);
        when(repository.plantExists("1000")).thenReturn(true);

        CreateOrderRequest request = buildValidRequest();
        CreateOrderResponse response = service.createPurchaseOrder(request);

        assertNotNull(response.getPoNumber());
        assertTrue(response.getMessage().contains("created successfully"));
        verify(repository).insertOrder(any());
        verify(repository).insertOrderItem(any());
    }

    @Test
    void shouldRejectWhenVendorNotFound() {
        // Equivalent to ABAP: RAISE vendor_not_found
        when(repository.vendorExists("V999")).thenReturn(false);

        CreateOrderRequest request = buildValidRequest();
        request.setVendorId("V999");

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> service.createPurchaseOrder(request));
        assertEquals(404, ex.getRawStatusCode());
    }

    @Test
    void shouldRejectWhenMaterialNotFound() {
        // Equivalent to ABAP: RAISE material_not_found
        when(repository.vendorExists("V001")).thenReturn(true);
        when(repository.materialExists("INVALID")).thenReturn(false);

        CreateOrderRequest request = buildValidRequest();
        request.getItems().get(0).setMaterialNumber("INVALID");

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> service.createPurchaseOrder(request));
        assertEquals(404, ex.getRawStatusCode());
    }

    @Test
    void shouldRejectWhenPlantInvalid() {
        // Equivalent to ABAP: RAISE plant_invalid
        when(repository.vendorExists("V001")).thenReturn(true);
        when(repository.materialExists("FURN-001")).thenReturn(true);
        when(repository.plantExists("9999")).thenReturn(false);

        CreateOrderRequest request = buildValidRequest();
        request.getItems().get(0).setPlant("9999");

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> service.createPurchaseOrder(request));
        assertEquals(400, ex.getRawStatusCode());
    }

    @Test
    void shouldRejectEmptyItems() {
        // Equivalent to ABAP: IF lv_item_count = 0 → RAISE creation_failed
        when(repository.vendorExists("V001")).thenReturn(true);

        CreateOrderRequest request = buildValidRequest();
        request.setItems(Collections.emptyList());

        assertThrows(ResponseStatusException.class,
                () -> service.createPurchaseOrder(request));
    }

    private CreateOrderRequest buildValidRequest() {
        OrderItemRequest item = new OrderItemRequest();
        item.setItemNumber("10");
        item.setMaterialNumber("FURN-001");
        item.setShortText("Oak Dining Table 6-Seater");
        item.setQuantity(new BigDecimal("5"));
        item.setUnit("EA");
        item.setNetPrice(new BigDecimal("599.99"));
        item.setPlant("1000");
        item.setStorageLocation("0001");
        item.setMaterialGroup("TABLES");

        CreateOrderRequest request = new CreateOrderRequest();
        request.setVendorId("V001");
        request.setPurchasingOrg("1000");
        request.setCompanyCode("1000");
        request.setDocumentType("NB");
        request.setItems(Arrays.asList(item));
        return request;
    }
}
