package com.bobs.purchaseorder.api;

import com.bobs.purchaseorder.application.PurchaseOrderService;
import com.bobs.purchaseorder.application.data.CreateOrderResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * REST endpoint tests for PurchaseOrderController.
 *
 * Validates the same scenarios the ABAP RFC function module handled.
 */
@WebMvcTest(PurchaseOrderController.class)
class PurchaseOrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private PurchaseOrderService orderService;

    @Test
    void shouldCreatePurchaseOrderSuccessfully() throws Exception {
        // Equivalent to ABAP: successful RFC call returning EV_PO_NUMBER
        CreateOrderResponse response = new CreateOrderResponse();
        response.setPoNumber("4500000001");
        response.setMessage("Purchase order 4500000001 created successfully");

        when(orderService.createPurchaseOrder(any())).thenReturn(response);

        String requestJson = "{"
                + "\"vendorId\":\"V001\","
                + "\"purchasingOrg\":\"1000\","
                + "\"companyCode\":\"1000\","
                + "\"items\":[{"
                + "  \"itemNumber\":\"10\","
                + "  \"materialNumber\":\"FURN-001\","
                + "  \"shortText\":\"Oak Dining Table 6-Seater\","
                + "  \"quantity\":5,"
                + "  \"unit\":\"EA\","
                + "  \"netPrice\":599.99,"
                + "  \"plant\":\"1000\""
                + "}]}";

        mockMvc.perform(post("/api/purchase-orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.poNumber", is("4500000001")))
                .andExpect(jsonPath("$.message", is("Purchase order 4500000001 created successfully")));
    }

    @Test
    void shouldReturn404WhenVendorNotFound() throws Exception {
        // Equivalent to ABAP: RAISE vendor_not_found
        when(orderService.createPurchaseOrder(any()))
                .thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "Vendor V999 does not exist"));

        String requestJson = "{"
                + "\"vendorId\":\"V999\","
                + "\"purchasingOrg\":\"1000\","
                + "\"companyCode\":\"1000\","
                + "\"items\":[{"
                + "  \"itemNumber\":\"10\","
                + "  \"materialNumber\":\"FURN-001\","
                + "  \"shortText\":\"Test\","
                + "  \"quantity\":1,"
                + "  \"unit\":\"EA\","
                + "  \"netPrice\":100,"
                + "  \"plant\":\"1000\""
                + "}]}";

        mockMvc.perform(post("/api/purchase-orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldReturn400ForMissingRequiredFields() throws Exception {
        // Equivalent to ABAP: validation of mandatory IMPORTING parameters
        String requestJson = "{\"items\":[]}";

        mockMvc.perform(post("/api/purchase-orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isBadRequest());
    }
}
