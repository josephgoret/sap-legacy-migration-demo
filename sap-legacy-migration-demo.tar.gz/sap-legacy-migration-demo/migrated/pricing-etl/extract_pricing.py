#!/usr/bin/env python3
"""
Acme Corporation — Pricing Condition Data Extraction

Migrated from: source-abap/z_pricing_extract.abap
Pattern: ABAP Data Extraction → Python ETL

This script extracts pricing condition records from a data warehouse,
applying date-effective filtering and writing tab-delimited output.

ABAP function → Python function mapping:
  FORM fetch_pricing_data  → extract_conditions()
  FORM write_output_file   → write_output()
  FORM display_summary     → log summary at end of main()
"""

import argparse
import datetime
import logging
import os
import sys

import pandas as pd
import sqlalchemy
import yaml


logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


def load_config(config_path: str) -> dict:
    """Load ETL configuration from YAML file."""
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def init_database(engine: sqlalchemy.engine.Engine) -> None:
    """
    Initialize the SQLite database with schema and sample data
    if the tables don't exist yet. Used for development/testing only.

    Equivalent to: SAP tables KONH, KONP, MARA, MAKT, KNA1
    """
    with engine.connect() as conn:
        conn.execute(sqlalchemy.text("""
            CREATE TABLE IF NOT EXISTS condition_header (
                condition_number VARCHAR(10) PRIMARY KEY,
                condition_type   VARCHAR(4),
                material_number  VARCHAR(18),
                customer_number  VARCHAR(10),
                valid_from       DATE,
                valid_to         DATE,
                search_term      VARCHAR(40)
            )
        """))
        conn.execute(sqlalchemy.text("""
            CREATE TABLE IF NOT EXISTS condition_item (
                condition_number VARCHAR(10),
                rate             DECIMAL(15,2),
                currency         VARCHAR(5),
                pricing_unit     INTEGER,
                unit_of_measure  VARCHAR(3),
                PRIMARY KEY (condition_number)
            )
        """))
        conn.execute(sqlalchemy.text("""
            CREATE TABLE IF NOT EXISTS material (
                material_number VARCHAR(18) PRIMARY KEY,
                description     VARCHAR(40)
            )
        """))
        conn.execute(sqlalchemy.text("""
            CREATE TABLE IF NOT EXISTS customer (
                customer_number VARCHAR(10) PRIMARY KEY,
                name            VARCHAR(80)
            )
        """))

        # Check if data already exists
        result = conn.execute(sqlalchemy.text(
            "SELECT COUNT(*) as cnt FROM condition_header"
        ))
        count = result.fetchone()[0]
        if count == 0:
            _insert_sample_data(conn)


def _insert_sample_data(conn) -> None:
    """Insert sample pricing data for Acme Corporation."""
    conn.execute(sqlalchemy.text("""
        INSERT INTO material (material_number, description) VALUES
        ('FURN-001', 'Oak Dining Table 6-Seater'),
        ('FURN-002', 'Leather Recliner Sofa'),
        ('FURN-003', 'Queen Memory Foam Mattress'),
        ('FURN-004', 'Walnut Bookshelf 5-Tier'),
        ('ACCS-001', 'Decorative Throw Pillow Set')
    """))
    conn.execute(sqlalchemy.text("""
        INSERT INTO customer (customer_number, name) VALUES
        ('C001', 'Riverside Home Staging'),
        ('C002', 'Metro Office Interiors')
    """))
    conn.execute(sqlalchemy.text("""
        INSERT INTO condition_header (condition_number, condition_type, material_number,
                                      customer_number, valid_from, valid_to, search_term) VALUES
        ('0000000001', 'PR00', 'FURN-001', NULL, '2024-01-01', '9999-12-31', 'BASE PRICE'),
        ('0000000002', 'PR00', 'FURN-002', NULL, '2024-01-01', '9999-12-31', 'BASE PRICE'),
        ('0000000003', 'PR00', 'FURN-003', NULL, '2024-01-01', '9999-12-31', 'BASE PRICE'),
        ('0000000004', 'PR00', 'FURN-004', NULL, '2024-01-01', '9999-12-31', 'BASE PRICE'),
        ('0000000005', 'PR00', 'ACCS-001', NULL, '2024-01-01', '9999-12-31', 'BASE PRICE'),
        ('0000000006', 'K004', 'FURN-001', NULL, '2024-01-01', '2024-12-31', 'PROMO DISC'),
        ('0000000007', 'K005', 'FURN-002', 'C001', '2024-03-01', '2024-06-30', 'CUST DISC'),
        ('0000000008', 'PR00', 'FURN-001', NULL, '2023-01-01', '2023-12-31', 'OLD PRICE')
    """))
    conn.execute(sqlalchemy.text("""
        INSERT INTO condition_item (condition_number, rate, currency, pricing_unit, unit_of_measure) VALUES
        ('0000000001', 599.99, 'USD', 1, 'EA'),
        ('0000000002', 1299.99, 'USD', 1, 'EA'),
        ('0000000003', 499.99, 'USD', 1, 'EA'),
        ('0000000004', 249.99, 'USD', 1, 'EA'),
        ('0000000005', 39.99, 'USD', 1, 'SET'),
        ('0000000006', -50.00, 'USD', 1, 'EA'),
        ('0000000007', -129.99, 'USD', 1, 'EA'),
        ('0000000008', 549.99, 'USD', 1, 'EA')
    """))
    conn.commit()


def extract_conditions(engine: sqlalchemy.engine.Engine, config: dict) -> pd.DataFrame:
    """
    Extract pricing condition records with date-effective filtering.

    Migrated from: FORM fetch_pricing_data in z_pricing_extract.abap

    ABAP equivalent:
      SELECT h~knumh h~kschl h~matnr t~maktx h~kunnr c~name1
             p~kbetr p~konwa p~kpein p~kmein h~datab h~datbi
        FROM konh AS h
        INNER JOIN konp AS p ON p~knumh = h~knumh
        LEFT OUTER JOIN makt AS t ON t~matnr = h~matnr
        LEFT OUTER JOIN kna1 AS c ON c~kunnr = h~kunnr
        WHERE h~kschl IN s_kschl
          AND h~datab <= p_keydt
          AND h~datbi >= p_keydt
    """
    filters = config.get("filters", {})
    condition_types = filters.get("condition_types", ["PR00"])
    key_date = filters.get("key_date")

    if key_date is None:
        key_date = datetime.date.today().isoformat()

    # Build parameterized placeholders for condition types
    placeholders = ", ".join(f":ct{i}" for i in range(len(condition_types)))
    params = {f"ct{i}": ct for i, ct in enumerate(condition_types)}
    params["key_date"] = key_date

    query = f"""
        SELECT
            h.condition_number,
            h.condition_type,
            h.material_number,
            COALESCE(m.description, '') as material_description,
            h.customer_number,
            COALESCE(c.name, '') as customer_name,
            p.rate,
            p.currency,
            p.pricing_unit,
            p.unit_of_measure,
            h.valid_from,
            h.valid_to
        FROM condition_header h
        INNER JOIN condition_item p ON p.condition_number = h.condition_number
        LEFT JOIN material m ON m.material_number = h.material_number
        LEFT JOIN customer c ON c.customer_number = h.customer_number
        WHERE h.condition_type IN ({placeholders})
          AND h.valid_from <= :key_date
          AND h.valid_to >= :key_date
        ORDER BY h.condition_type, h.material_number, h.customer_number
    """

    logger.info(
        "Extracting conditions: types=%s, key_date=%s",
        condition_types, key_date,
    )

    df = pd.read_sql(sqlalchemy.text(query), engine, params=params)
    logger.info("Extracted %d records", len(df))
    return df


def write_output(df: pd.DataFrame, config: dict) -> str:
    """
    Write extracted data to output file.

    Migrated from: FORM write_output_file in z_pricing_extract.abap

    ABAP equivalent:
      OPEN DATASET gv_filename FOR OUTPUT IN TEXT MODE.
      LOOP AT gt_pricing INTO gs_pricing.
        CONCATENATE fields INTO lv_line SEPARATED BY tab.
        TRANSFER lv_line TO gv_filename.
      ENDLOOP.
      CLOSE DATASET gv_filename.
    """
    output_config = config.get("output", {})
    output_path = output_config.get("path", "output/pricing_extract.csv")
    delimiter = output_config.get("delimiter", "\t")

    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)

    df.to_csv(output_path, sep=delimiter, index=False)
    logger.info("Output written to: %s", output_path)
    return output_path


def main():
    parser = argparse.ArgumentParser(
        description="Acme Corporation — Pricing Data Extraction"
    )
    parser.add_argument(
        "--config", default="config.yaml",
        help="Path to configuration file (default: config.yaml)"
    )
    parser.add_argument(
        "--key-date", default=None,
        help="Key date for date-effective filtering (YYYY-MM-DD)"
    )
    args = parser.parse_args()

    # Load configuration
    config = load_config(args.config)

    # Override key date from command line if provided
    if args.key_date:
        config.setdefault("filters", {})["key_date"] = args.key_date

    # Connect to database
    db_config = config.get("database", {})
    connection_string = db_config.get("connection_string", "sqlite:///pricing.db")
    engine = sqlalchemy.create_engine(connection_string)

    # Initialize database with schema and sample data (dev/test only)
    init_database(engine)

    # Extract data
    df = extract_conditions(engine, config)

    if df.empty:
        logger.warning("No pricing data found for selection criteria")
        sys.exit(0)

    # Write output
    output_path = write_output(df, config)

    # Summary (ABAP: FORM display_summary)
    logger.info("========================================")
    logger.info("Pricing Extract Complete")
    logger.info("Records extracted: %d", len(df))
    logger.info("Output file: %s", output_path)
    logger.info("========================================")


if __name__ == "__main__":
    main()
