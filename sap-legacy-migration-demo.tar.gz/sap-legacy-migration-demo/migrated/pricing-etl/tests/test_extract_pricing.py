"""
Tests for pricing condition data extraction.

Migrated from: z_pricing_extract.abap
Verifies that the Python ETL produces equivalent results to the ABAP extraction.
"""

import datetime
import os
import sys
import tempfile

import pandas as pd
import pytest
import sqlalchemy

# Add parent directory to path so we can import the module
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from extract_pricing import extract_conditions, init_database, write_output


@pytest.fixture
def engine():
    """Create an in-memory SQLite database with test data."""
    eng = sqlalchemy.create_engine("sqlite:///:memory:")
    init_database(eng)
    return eng


@pytest.fixture
def config():
    """Default test configuration."""
    return {
        "filters": {
            "condition_types": ["PR00", "K004", "K005"],
            "key_date": "2024-06-15",
        },
        "output": {
            "path": os.path.join(tempfile.mkdtemp(), "test_output.csv"),
            "delimiter": "\t",
        },
    }


class TestExtractConditions:
    """Tests for the extract_conditions function (ABAP: FORM fetch_pricing_data)."""

    def test_extracts_base_prices(self, engine, config):
        """Verify PR00 (base price) conditions are extracted."""
        config["filters"]["condition_types"] = ["PR00"]
        df = extract_conditions(engine, config)

        assert len(df) > 0
        assert all(df["condition_type"] == "PR00")

    def test_date_effective_filtering(self, engine, config):
        """
        Verify date-effective logic matches ABAP:
          WHERE h~datab <= p_keydt AND h~datbi >= p_keydt

        The old price (valid 2023-01-01 to 2023-12-31) should NOT appear
        when key_date is 2024-06-15.
        """
        config["filters"]["condition_types"] = ["PR00"]
        config["filters"]["key_date"] = "2024-06-15"
        df = extract_conditions(engine, config)

        # FURN-001 old price (2023) should be excluded
        furn001_records = df[df["material_number"] == "FURN-001"]
        assert len(furn001_records) == 1
        assert float(furn001_records.iloc[0]["rate"]) == 599.99

    def test_excludes_expired_conditions(self, engine, config):
        """Key date after valid_to should exclude the record."""
        config["filters"]["condition_types"] = ["K005"]
        config["filters"]["key_date"] = "2024-07-01"  # After K005 valid_to (2024-06-30)
        df = extract_conditions(engine, config)

        # Customer discount expired on 2024-06-30
        assert len(df) == 0

    def test_includes_active_discount(self, engine, config):
        """Key date within validity period should include the record."""
        config["filters"]["condition_types"] = ["K005"]
        config["filters"]["key_date"] = "2024-04-15"  # Within K005 validity
        df = extract_conditions(engine, config)

        assert len(df) == 1
        assert df.iloc[0]["customer_number"] == "C001"

    def test_multiple_condition_types(self, engine, config):
        """Verify multiple condition types can be extracted simultaneously."""
        config["filters"]["condition_types"] = ["PR00", "K004"]
        config["filters"]["key_date"] = "2024-06-15"
        df = extract_conditions(engine, config)

        types_found = set(df["condition_type"].unique())
        assert "PR00" in types_found
        assert "K004" in types_found

    def test_empty_result_for_no_match(self, engine, config):
        """ABAP: IF gt_pricing IS INITIAL → no output."""
        config["filters"]["condition_types"] = ["ZZZZ"]  # Non-existent type
        df = extract_conditions(engine, config)

        assert len(df) == 0

    def test_material_description_joined(self, engine, config):
        """Verify material descriptions are joined from material table."""
        config["filters"]["condition_types"] = ["PR00"]
        df = extract_conditions(engine, config)

        furn001 = df[df["material_number"] == "FURN-001"]
        assert furn001.iloc[0]["material_description"] == "Oak Dining Table 6-Seater"


class TestWriteOutput:
    """Tests for the write_output function (ABAP: FORM write_output_file)."""

    def test_writes_tab_delimited_file(self, engine, config):
        """Verify output matches ABAP: CONCATENATE ... SEPARATED BY tab."""
        df = extract_conditions(engine, config)
        output_path = write_output(df, config)

        assert os.path.exists(output_path)

        # Read back and verify
        result = pd.read_csv(output_path, sep="\t")
        assert len(result) == len(df)
        assert "condition_number" in result.columns
        assert "rate" in result.columns

    def test_creates_output_directory(self, config):
        """Verify output directory is created if it doesn't exist."""
        config["output"]["path"] = os.path.join(
            tempfile.mkdtemp(), "subdir", "output.csv"
        )
        df = pd.DataFrame({"col1": [1, 2], "col2": ["a", "b"]})
        output_path = write_output(df, config)

        assert os.path.exists(output_path)
