-- Flyway Migration V1: Create delivery note tables
-- Migrated from: SAP tables LIKP, LIPS, KNA1, ADRC

-- DELIVERY_HEADER table (from LIKP)
CREATE TABLE delivery_header (
    delivery_number  VARCHAR(10) PRIMARY KEY,  -- LIKP-VBELN
    created_date     DATE,                     -- LIKP-ERDAT
    delivery_date    DATE,                     -- LIKP-LFDAT
    customer_number  VARCHAR(10),              -- LIKP-KUNNR
    shipping_point   VARCHAR(4),               -- LIKP-VSTEL
    route            VARCHAR(6),               -- LIKP-ROUTE
    total_weight     DECIMAL(15,3),            -- LIKP-BTGEW
    weight_unit      VARCHAR(3),               -- LIKP-GEWEI
    number_of_packages INTEGER                 -- LIKP-ANZPK
);

-- DELIVERY_ITEM table (from LIPS + MAKT)
CREATE TABLE delivery_item (
    delivery_number  VARCHAR(10) NOT NULL,     -- LIPS-VBELN
    item_number      VARCHAR(6)  NOT NULL,     -- LIPS-POSNR
    material_number  VARCHAR(18),              -- LIPS-MATNR
    description      VARCHAR(40),              -- MAKT-MAKTX (joined)
    quantity         DECIMAL(13,3),            -- LIPS-LFIMG
    unit             VARCHAR(3),               -- LIPS-VRKME
    gross_weight     DECIMAL(15,3),            -- LIPS-BRGEW
    net_weight       DECIMAL(15,3),            -- LIPS-NTGEW
    weight_unit      VARCHAR(3),               -- LIPS-GEWEI
    PRIMARY KEY (delivery_number, item_number),
    FOREIGN KEY (delivery_number) REFERENCES delivery_header(delivery_number)
);

-- CUSTOMER_ADDRESS table (from KNA1 + ADRC)
CREATE TABLE customer_address (
    customer_number  VARCHAR(10) PRIMARY KEY,
    name1            VARCHAR(40),
    name2            VARCHAR(40),
    street           VARCHAR(60),
    city             VARCHAR(40),
    region           VARCHAR(3),
    postal_code      VARCHAR(10),
    country          VARCHAR(3)
);

-- Sample data: Acme Corporation delivery
INSERT INTO customer_address (customer_number, name1, name2, street, city, region, postal_code, country)
VALUES
    ('C001', 'Riverside Home Staging', NULL, '123 Main St', 'Manchester', 'CT', '06040', 'US'),
    ('C002', 'Metro Office Interiors', 'Attn: Receiving Dept', '456 Broadway', 'New York', 'NY', '10013', 'US');

INSERT INTO delivery_header (delivery_number, created_date, delivery_date, customer_number, shipping_point, route, total_weight, weight_unit, number_of_packages)
VALUES
    ('8000000001', '2024-06-15', '2024-06-18', 'C001', 'SH01', 'RT001', 285.500, 'KG', 4),
    ('8000000002', '2024-06-16', '2024-06-19', 'C002', 'SH01', 'RT002', 45.200, 'KG', 2);

INSERT INTO delivery_item (delivery_number, item_number, material_number, description, quantity, unit, gross_weight, net_weight, weight_unit)
VALUES
    ('8000000001', '10', 'FURN-001', 'Oak Dining Table 6-Seater', 2.000, 'EA', 120.000, 110.000, 'KG'),
    ('8000000001', '20', 'FURN-002', 'Leather Recliner Sofa', 1.000, 'EA', 85.500, 78.000, 'KG'),
    ('8000000001', '30', 'FURN-004', 'Walnut Bookshelf 5-Tier', 2.000, 'EA', 60.000, 55.000, 'KG'),
    ('8000000001', '40', 'ACCS-001', 'Decorative Throw Pillow Set', 4.000, 'SET', 20.000, 18.000, 'KG'),
    ('8000000002', '10', 'FURN-003', 'Queen Memory Foam Mattress', 1.000, 'EA', 30.200, 28.000, 'KG'),
    ('8000000002', '20', 'ACCS-002', 'Table Runner - Linen', 3.000, 'EA', 15.000, 14.000, 'KG');
