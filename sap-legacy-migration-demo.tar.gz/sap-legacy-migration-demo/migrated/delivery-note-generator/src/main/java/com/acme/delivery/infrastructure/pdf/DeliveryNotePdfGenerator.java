package com.bobs.delivery.infrastructure.pdf;

import com.bobs.delivery.application.data.AddressData;
import com.bobs.delivery.application.data.DeliveryItemData;
import com.bobs.delivery.application.data.DeliveryNoteData;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;

/**
 * PDF generator for delivery notes using Apache PDFBox.
 *
 * Migrated from: FORM print_delivery_note in z_delivery_note_form.abap
 *
 * SAPscript WRITE_FORM elements → PDFBox methods:
 *   HEADER         → writeHeader()
 *   SHIP_TO_ADDRESS → writeAddress()
 *   DELIVERY_INFO  → writeDeliveryInfo()
 *   ITEM_HEADER    → writeItemTableHeader()
 *   ITEM_LINE      → writeItemLine() (in loop)
 *   TOTALS         → writeTotals()
 *   FOOTER         → writeFooter()
 */
@Component
public class DeliveryNotePdfGenerator {

    private static final float MARGIN = 50;
    private static final float PAGE_WIDTH = PDRectangle.A4.getWidth();
    private static final float PAGE_HEIGHT = PDRectangle.A4.getHeight();
    private static final float LINE_HEIGHT = 14;
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public byte[] generatePdf(DeliveryNoteData data) {
        try (PDDocument document = new PDDocument();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            PDPageContentStream content = new PDPageContentStream(document, page);
            float yPos = PAGE_HEIGHT - MARGIN;

            // HEADER element
            yPos = writeHeader(content, yPos);

            // SHIP_TO_ADDRESS element
            yPos = writeAddress(content, data.getShipToAddress(), yPos);

            // DELIVERY_INFO element
            yPos = writeDeliveryInfo(content, data, yPos);

            // ITEM_HEADER + ITEM_LINE elements
            yPos = writeItemTableHeader(content, yPos);

            for (DeliveryItemData item : data.getItems()) {
                // Handle page break (ABAP: IF lv_item_count MOD 25 = 0)
                if (yPos < MARGIN + 100) {
                    writeFooter(content, yPos);
                    content.close();

                    page = new PDPage(PDRectangle.A4);
                    document.addPage(page);
                    content = new PDPageContentStream(document, page);
                    yPos = PAGE_HEIGHT - MARGIN;
                    yPos = writeItemTableHeader(content, yPos);
                }

                yPos = writeItemLine(content, item, yPos);
            }

            // TOTALS element
            yPos = writeTotals(content, data, yPos);

            // FOOTER element
            writeFooter(content, yPos);

            content.close();
            document.save(out);
            return out.toByteArray();

        } catch (IOException e) {
            throw new RuntimeException("Failed to generate delivery note PDF", e);
        }
    }

    private float writeHeader(PDPageContentStream content, float yPos) throws IOException {
        content.beginText();
        content.setFont(PDType1Font.HELVETICA_BOLD, 18);
        content.newLineAtOffset(MARGIN, yPos);
        content.showText("Acme Corporation");
        content.endText();
        yPos -= LINE_HEIGHT * 1.5f;

        content.beginText();
        content.setFont(PDType1Font.HELVETICA_BOLD, 14);
        content.newLineAtOffset(MARGIN, yPos);
        content.showText("DELIVERY NOTE");
        content.endText();
        yPos -= LINE_HEIGHT * 2;

        return yPos;
    }

    private float writeAddress(PDPageContentStream content, AddressData address, float yPos) throws IOException {
        content.beginText();
        content.setFont(PDType1Font.HELVETICA_BOLD, 10);
        content.newLineAtOffset(MARGIN, yPos);
        content.showText("Ship To:");
        content.endText();
        yPos -= LINE_HEIGHT;

        content.setFont(PDType1Font.HELVETICA, 10);

        if (address != null) {
            String[] lines = {
                    safeStr(address.getName1()),
                    safeStr(address.getName2()),
                    safeStr(address.getStreet()),
                    safeStr(address.getCity()) + ", " + safeStr(address.getRegion()) + " " + safeStr(address.getPostalCode()),
                    safeStr(address.getCountry())
            };
            for (String line : lines) {
                if (!line.isBlank()) {
                    content.beginText();
                    content.setFont(PDType1Font.HELVETICA, 10);
                    content.newLineAtOffset(MARGIN, yPos);
                    content.showText(line);
                    content.endText();
                    yPos -= LINE_HEIGHT;
                }
            }
        }

        yPos -= LINE_HEIGHT;
        return yPos;
    }

    private float writeDeliveryInfo(PDPageContentStream content, DeliveryNoteData data, float yPos) throws IOException {
        content.setFont(PDType1Font.HELVETICA, 10);

        String[][] info = {
                {"Delivery Number:", data.getDeliveryNumber()},
                {"Delivery Date:", data.getDeliveryDate() != null ? data.getDeliveryDate().format(DATE_FORMAT) : ""},
                {"Shipping Point:", safeStr(data.getShippingPoint())},
                {"Route:", safeStr(data.getRoute())},
        };

        for (String[] pair : info) {
            content.beginText();
            content.setFont(PDType1Font.HELVETICA_BOLD, 10);
            content.newLineAtOffset(PAGE_WIDTH - 250, yPos);
            content.showText(pair[0]);
            content.endText();

            content.beginText();
            content.setFont(PDType1Font.HELVETICA, 10);
            content.newLineAtOffset(PAGE_WIDTH - 130, yPos);
            content.showText(pair[1]);
            content.endText();

            yPos -= LINE_HEIGHT;
        }

        yPos -= LINE_HEIGHT;
        return yPos;
    }

    private float writeItemTableHeader(PDPageContentStream content, float yPos) throws IOException {
        // Draw header line
        content.setLineWidth(0.5f);
        content.moveTo(MARGIN, yPos);
        content.lineTo(PAGE_WIDTH - MARGIN, yPos);
        content.stroke();
        yPos -= LINE_HEIGHT;

        content.beginText();
        content.setFont(PDType1Font.HELVETICA_BOLD, 9);
        content.newLineAtOffset(MARGIN, yPos);
        content.showText("Item");
        content.endText();

        content.beginText();
        content.newLineAtOffset(MARGIN + 40, yPos);
        content.showText("Material");
        content.endText();

        content.beginText();
        content.newLineAtOffset(MARGIN + 120, yPos);
        content.showText("Description");
        content.endText();

        content.beginText();
        content.newLineAtOffset(PAGE_WIDTH - 230, yPos);
        content.showText("Qty");
        content.endText();

        content.beginText();
        content.newLineAtOffset(PAGE_WIDTH - 180, yPos);
        content.showText("Unit");
        content.endText();

        content.beginText();
        content.newLineAtOffset(PAGE_WIDTH - 130, yPos);
        content.showText("Gross Wt");
        content.endText();

        yPos -= 4;
        content.moveTo(MARGIN, yPos);
        content.lineTo(PAGE_WIDTH - MARGIN, yPos);
        content.stroke();
        yPos -= LINE_HEIGHT;

        return yPos;
    }

    private float writeItemLine(PDPageContentStream content, DeliveryItemData item, float yPos) throws IOException {
        content.setFont(PDType1Font.HELVETICA, 9);

        content.beginText();
        content.newLineAtOffset(MARGIN, yPos);
        content.showText(safeStr(item.getItemNumber()));
        content.endText();

        content.beginText();
        content.newLineAtOffset(MARGIN + 40, yPos);
        content.showText(safeStr(item.getMaterialNumber()));
        content.endText();

        content.beginText();
        content.newLineAtOffset(MARGIN + 120, yPos);
        content.showText(truncate(safeStr(item.getDescription()), 30));
        content.endText();

        content.beginText();
        content.newLineAtOffset(PAGE_WIDTH - 230, yPos);
        content.showText(item.getQuantity() != null ? item.getQuantity().toPlainString() : "0");
        content.endText();

        content.beginText();
        content.newLineAtOffset(PAGE_WIDTH - 180, yPos);
        content.showText(safeStr(item.getUnit()));
        content.endText();

        content.beginText();
        content.newLineAtOffset(PAGE_WIDTH - 130, yPos);
        content.showText(item.getGrossWeight() != null ? item.getGrossWeight().toPlainString() : "0");
        content.endText();

        yPos -= LINE_HEIGHT;
        return yPos;
    }

    private float writeTotals(PDPageContentStream content, DeliveryNoteData data, float yPos) throws IOException {
        yPos -= LINE_HEIGHT / 2;
        content.moveTo(MARGIN, yPos);
        content.lineTo(PAGE_WIDTH - MARGIN, yPos);
        content.stroke();
        yPos -= LINE_HEIGHT;

        content.setFont(PDType1Font.HELVETICA_BOLD, 10);

        content.beginText();
        content.newLineAtOffset(MARGIN, yPos);
        content.showText("Total Items: " + data.getTotalItems());
        content.endText();

        content.beginText();
        content.newLineAtOffset(PAGE_WIDTH - 230, yPos);
        BigDecimal weight = data.getCalculatedTotalWeight() != null
                ? data.getCalculatedTotalWeight() : BigDecimal.ZERO;
        content.showText("Total Weight: " + weight.toPlainString() + " " + safeStr(data.getWeightUnit()));
        content.endText();

        content.beginText();
        content.newLineAtOffset(MARGIN, yPos - LINE_HEIGHT);
        content.showText("Packages: " + data.getNumberOfPackages());
        content.endText();

        yPos -= LINE_HEIGHT * 3;
        return yPos;
    }

    private void writeFooter(PDPageContentStream content, float yPos) throws IOException {
        float footerY = MARGIN + 30;

        content.moveTo(MARGIN, footerY + 20);
        content.lineTo(MARGIN + 200, footerY + 20);
        content.stroke();

        content.beginText();
        content.setFont(PDType1Font.HELVETICA, 9);
        content.newLineAtOffset(MARGIN, footerY);
        content.showText("Received by (signature)");
        content.endText();

        content.moveTo(PAGE_WIDTH - 250, footerY + 20);
        content.lineTo(PAGE_WIDTH - MARGIN, footerY + 20);
        content.stroke();

        content.beginText();
        content.newLineAtOffset(PAGE_WIDTH - 250, footerY);
        content.showText("Date");
        content.endText();
    }

    private String safeStr(String s) {
        return s != null ? s : "";
    }

    private String truncate(String s, int maxLen) {
        return s.length() > maxLen ? s.substring(0, maxLen) + "..." : s;
    }
}
