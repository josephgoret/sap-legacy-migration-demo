package com.bobs.delivery.core;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Domain entity for delivery header.
 *
 * Migrated from: SAP table LIKP (Delivery Header)
 */
public class DeliveryHeader {

    private String deliveryNumber;   // LIKP-VBELN
    private LocalDate createdDate;   // LIKP-ERDAT
    private LocalDate deliveryDate;  // LIKP-LFDAT
    private String customerNumber;   // LIKP-KUNNR
    private String shippingPoint;    // LIKP-VSTEL
    private String route;            // LIKP-ROUTE
    private BigDecimal totalWeight;  // LIKP-BTGEW
    private String weightUnit;       // LIKP-GEWEI
    private int numberOfPackages;    // LIKP-ANZPK

    public String getDeliveryNumber() { return deliveryNumber; }
    public void setDeliveryNumber(String deliveryNumber) { this.deliveryNumber = deliveryNumber; }

    public LocalDate getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDate createdDate) { this.createdDate = createdDate; }

    public LocalDate getDeliveryDate() { return deliveryDate; }
    public void setDeliveryDate(LocalDate deliveryDate) { this.deliveryDate = deliveryDate; }

    public String getCustomerNumber() { return customerNumber; }
    public void setCustomerNumber(String customerNumber) { this.customerNumber = customerNumber; }

    public String getShippingPoint() { return shippingPoint; }
    public void setShippingPoint(String shippingPoint) { this.shippingPoint = shippingPoint; }

    public String getRoute() { return route; }
    public void setRoute(String route) { this.route = route; }

    public BigDecimal getTotalWeight() { return totalWeight; }
    public void setTotalWeight(BigDecimal totalWeight) { this.totalWeight = totalWeight; }

    public String getWeightUnit() { return weightUnit; }
    public void setWeightUnit(String weightUnit) { this.weightUnit = weightUnit; }

    public int getNumberOfPackages() { return numberOfPackages; }
    public void setNumberOfPackages(int numberOfPackages) { this.numberOfPackages = numberOfPackages; }
}
