package com.bobs.delivery.application;

import com.bobs.delivery.application.data.AddressData;
import com.bobs.delivery.application.data.DeliveryItemData;
import com.bobs.delivery.application.data.DeliveryNoteData;
import com.bobs.delivery.core.DeliveryHeader;
import com.bobs.delivery.core.DeliveryItem;
import com.bobs.delivery.core.DeliveryRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service layer for delivery note data retrieval.
 *
 * Migrated from: FORMs read_delivery_header, read_delivery_items,
 * and read_ship_to_address in z_delivery_note_form.abap
 */
@Service
public class DeliveryNoteService {

    private final DeliveryRepository repository;

    public DeliveryNoteService(DeliveryRepository repository) {
        this.repository = repository;
    }

    /**
     * Retrieves all data needed to generate a delivery note PDF.
     *
     * ABAP equivalent: PERFORM read_delivery_header + read_delivery_items + read_ship_to_address
     */
    public DeliveryNoteData getDeliveryNoteData(String deliveryNumber) {
        DeliveryHeader header = repository.findHeaderByDeliveryNumber(deliveryNumber);
        if (header == null) {
            return null;
        }

        List<DeliveryItem> items = repository.findItemsByDeliveryNumber(deliveryNumber);
        AddressData address = repository.findShipToAddress(header.getCustomerNumber());

        DeliveryNoteData data = new DeliveryNoteData();
        data.setDeliveryNumber(header.getDeliveryNumber());
        data.setCreatedDate(header.getCreatedDate());
        data.setDeliveryDate(header.getDeliveryDate());
        data.setShippingPoint(header.getShippingPoint());
        data.setRoute(header.getRoute());
        data.setTotalWeight(header.getTotalWeight());
        data.setWeightUnit(header.getWeightUnit());
        data.setNumberOfPackages(header.getNumberOfPackages());
        data.setShipToAddress(address);

        List<DeliveryItemData> itemDataList = items.stream()
                .map(this::mapItemToData)
                .collect(Collectors.toList());
        data.setItems(itemDataList);

        // Calculate totals (ABAP: lv_total_weight, lv_total_items in FORM print_delivery_note)
        BigDecimal totalWeight = items.stream()
                .map(DeliveryItem::getGrossWeight)
                .filter(w -> w != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        data.setCalculatedTotalWeight(totalWeight);
        data.setTotalItems(items.size());

        return data;
    }

    private DeliveryItemData mapItemToData(DeliveryItem item) {
        DeliveryItemData data = new DeliveryItemData();
        data.setItemNumber(item.getItemNumber());
        data.setMaterialNumber(item.getMaterialNumber());
        data.setDescription(item.getDescription());
        data.setQuantity(item.getQuantity());
        data.setUnit(item.getUnit());
        data.setGrossWeight(item.getGrossWeight());
        data.setNetWeight(item.getNetWeight());
        data.setWeightUnit(item.getWeightUnit());
        return data;
    }
}
