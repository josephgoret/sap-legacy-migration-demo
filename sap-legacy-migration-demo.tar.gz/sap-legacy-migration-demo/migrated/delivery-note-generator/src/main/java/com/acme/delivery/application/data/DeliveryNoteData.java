package com.bobs.delivery.application.data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * DTO holding all data needed for delivery note PDF generation.
 *
 * Migrated from: gs_header, gt_items, gs_address in z_delivery_note_form.abap
 */
public class DeliveryNoteData {

    private String deliveryNumber;
    private LocalDate createdDate;
    private LocalDate deliveryDate;
    private String shippingPoint;
    private String route;
    private BigDecimal totalWeight;
    private String weightUnit;
    private int numberOfPackages;
    private AddressData shipToAddress;
    private List<DeliveryItemData> items;
    private BigDecimal calculatedTotalWeight;
    private int totalItems;

    public String getDeliveryNumber() { return deliveryNumber; }
    public void setDeliveryNumber(String deliveryNumber) { this.deliveryNumber = deliveryNumber; }

    public LocalDate getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDate createdDate) { this.createdDate = createdDate; }

    public LocalDate getDeliveryDate() { return deliveryDate; }
    public void setDeliveryDate(LocalDate deliveryDate) { this.deliveryDate = deliveryDate; }

    public String getShippingPoint() { return shippingPoint; }
    public void setShippingPoint(String shippingPoint) { this.shippingPoint = shippingPoint; }

    public String getRoute() { return route; }
    public void setRoute(String route) { this.route = route; }

    public BigDecimal getTotalWeight() { return totalWeight; }
    public void setTotalWeight(BigDecimal totalWeight) { this.totalWeight = totalWeight; }

    public String getWeightUnit() { return weightUnit; }
    public void setWeightUnit(String weightUnit) { this.weightUnit = weightUnit; }

    public int getNumberOfPackages() { return numberOfPackages; }
    public void setNumberOfPackages(int numberOfPackages) { this.numberOfPackages = numberOfPackages; }

    public AddressData getShipToAddress() { return shipToAddress; }
    public void setShipToAddress(AddressData shipToAddress) { this.shipToAddress = shipToAddress; }

    public List<DeliveryItemData> getItems() { return items; }
    public void setItems(List<DeliveryItemData> items) { this.items = items; }

    public BigDecimal getCalculatedTotalWeight() { return calculatedTotalWeight; }
    public void setCalculatedTotalWeight(BigDecimal calculatedTotalWeight) { this.calculatedTotalWeight = calculatedTotalWeight; }

    public int getTotalItems() { return totalItems; }
    public void setTotalItems(int totalItems) { this.totalItems = totalItems; }
}
