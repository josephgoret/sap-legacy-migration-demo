package com.bobs.delivery.core;

import com.bobs.delivery.application.data.AddressData;

import java.util.List;

/**
 * Repository interface for delivery data.
 *
 * Migrated from: ABAP SELECT statements in z_delivery_note_form.abap
 */
public interface DeliveryRepository {

    DeliveryHeader findHeaderByDeliveryNumber(String deliveryNumber);
    List<DeliveryItem> findItemsByDeliveryNumber(String deliveryNumber);
    AddressData findShipToAddress(String customerNumber);
}
