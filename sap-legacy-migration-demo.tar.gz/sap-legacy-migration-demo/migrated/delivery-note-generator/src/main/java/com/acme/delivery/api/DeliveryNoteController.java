package com.bobs.delivery.api;

import com.bobs.delivery.application.DeliveryNoteService;
import com.bobs.delivery.application.data.DeliveryNoteData;
import com.bobs.delivery.infrastructure.pdf.DeliveryNotePdfGenerator;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

/**
 * REST controller for delivery note PDF generation.
 *
 * Migrated from: z_delivery_note_form.abap
 * - PARAMETERS p_vbeln → @PathVariable deliveryNumber
 * - SAPscript OPEN_FORM/WRITE_FORM/CLOSE_FORM → PDFBox PDF generation
 */
@RestController
@RequestMapping("/api/delivery-notes")
public class DeliveryNoteController {

    private final DeliveryNoteService service;
    private final DeliveryNotePdfGenerator pdfGenerator;

    public DeliveryNoteController(DeliveryNoteService service,
                                   DeliveryNotePdfGenerator pdfGenerator) {
        this.service = service;
        this.pdfGenerator = pdfGenerator;
    }

    /**
     * GET /api/delivery-notes/{deliveryNumber}/pdf
     *
     * Replaces the SAPscript form print program for delivery notes.
     */
    @GetMapping("/{deliveryNumber}/pdf")
    public ResponseEntity<byte[]> generateDeliveryNotePdf(
            @PathVariable String deliveryNumber) {

        DeliveryNoteData data = service.getDeliveryNoteData(deliveryNumber);

        if (data == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Delivery " + deliveryNumber + " not found");
        }

        byte[] pdfBytes = pdfGenerator.generatePdf(data);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment",
                "delivery-note-" + deliveryNumber + ".pdf");

        return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
    }
}
