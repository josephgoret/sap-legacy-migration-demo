package com.bobs.delivery.infrastructure.mybatis;

import com.bobs.delivery.application.data.AddressData;
import com.bobs.delivery.core.DeliveryHeader;
import com.bobs.delivery.core.DeliveryItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DeliveryMapper {

    DeliveryHeader findHeaderByDeliveryNumber(@Param("deliveryNumber") String deliveryNumber);
    List<DeliveryItem> findItemsByDeliveryNumber(@Param("deliveryNumber") String deliveryNumber);
    AddressData findShipToAddress(@Param("customerNumber") String customerNumber);
}
