package com.bobs.delivery.infrastructure.repository;

import com.bobs.delivery.application.data.AddressData;
import com.bobs.delivery.core.DeliveryHeader;
import com.bobs.delivery.core.DeliveryItem;
import com.bobs.delivery.core.DeliveryRepository;
import com.bobs.delivery.infrastructure.mybatis.DeliveryMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class MyBatisDeliveryRepository implements DeliveryRepository {

    private final DeliveryMapper mapper;

    public MyBatisDeliveryRepository(DeliveryMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public DeliveryHeader findHeaderByDeliveryNumber(String deliveryNumber) {
        return mapper.findHeaderByDeliveryNumber(deliveryNumber);
    }

    @Override
    public List<DeliveryItem> findItemsByDeliveryNumber(String deliveryNumber) {
        return mapper.findItemsByDeliveryNumber(deliveryNumber);
    }

    @Override
    public AddressData findShipToAddress(String customerNumber) {
        return mapper.findShipToAddress(customerNumber);
    }
}
