package com.bobs.delivery.core;

import java.math.BigDecimal;

/**
 * Domain entity for delivery line item.
 *
 * Migrated from: SAP table LIPS (Delivery Items)
 */
public class DeliveryItem {

    private String deliveryNumber;   // LIPS-VBELN
    private String itemNumber;       // LIPS-POSNR
    private String materialNumber;   // LIPS-MATNR
    private String description;      // MAKT-MAKTX (joined)
    private BigDecimal quantity;     // LIPS-LFIMG
    private String unit;             // LIPS-VRKME
    private BigDecimal grossWeight;  // LIPS-BRGEW
    private BigDecimal netWeight;    // LIPS-NTGEW
    private String weightUnit;       // LIPS-GEWEI

    public String getDeliveryNumber() { return deliveryNumber; }
    public void setDeliveryNumber(String deliveryNumber) { this.deliveryNumber = deliveryNumber; }

    public String getItemNumber() { return itemNumber; }
    public void setItemNumber(String itemNumber) { this.itemNumber = itemNumber; }

    public String getMaterialNumber() { return materialNumber; }
    public void setMaterialNumber(String materialNumber) { this.materialNumber = materialNumber; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public BigDecimal getGrossWeight() { return grossWeight; }
    public void setGrossWeight(BigDecimal grossWeight) { this.grossWeight = grossWeight; }

    public BigDecimal getNetWeight() { return netWeight; }
    public void setNetWeight(BigDecimal netWeight) { this.netWeight = netWeight; }

    public String getWeightUnit() { return weightUnit; }
    public void setWeightUnit(String weightUnit) { this.weightUnit = weightUnit; }
}
