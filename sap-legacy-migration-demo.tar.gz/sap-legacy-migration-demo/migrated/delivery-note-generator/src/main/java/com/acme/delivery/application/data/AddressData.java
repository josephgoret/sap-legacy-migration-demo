package com.bobs.delivery.application.data;

/**
 * DTO for ship-to address.
 *
 * Migrated from: ty_s_address in z_delivery_note_form.abap
 */
public class AddressData {

    private String name1;
    private String name2;
    private String street;
    private String city;
    private String region;
    private String postalCode;
    private String country;

    public String getName1() { return name1; }
    public void setName1(String name1) { this.name1 = name1; }

    public String getName2() { return name2; }
    public void setName2(String name2) { this.name2 = name2; }

    public String getStreet() { return street; }
    public void setStreet(String street) { this.street = street; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public String getPostalCode() { return postalCode; }
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
}
