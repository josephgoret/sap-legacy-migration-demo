package com.bobs.delivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Acme Corporation — Delivery Note Generator
 *
 * Migrated from: source-abap/z_delivery_note_form.abap
 * Pattern: SAPscript Form → Java PDF Generator (Apache PDFBox)
 */
@SpringBootApplication
public class DeliveryNoteApplication {

    public static void main(String[] args) {
        SpringApplication.run(DeliveryNoteApplication.class, args);
    }
}
