package com.bobs.delivery.application;

import com.bobs.delivery.application.data.AddressData;
import com.bobs.delivery.application.data.DeliveryNoteData;
import com.bobs.delivery.core.DeliveryHeader;
import com.bobs.delivery.core.DeliveryItem;
import com.bobs.delivery.core.DeliveryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Business logic tests for DeliveryNoteService.
 *
 * Verifies data retrieval and total calculations match ABAP behavior.
 */
class DeliveryNoteServiceTest {

    private DeliveryNoteService service;
    private DeliveryRepository repository;

    @BeforeEach
    void setUp() {
        repository = mock(DeliveryRepository.class);
        service = new DeliveryNoteService(repository);
    }

    @Test
    void shouldReturnNullForMissingDelivery() {
        // ABAP: IF sy-subrc <> 0 → MESSAGE 'not found'
        when(repository.findHeaderByDeliveryNumber("9999")).thenReturn(null);

        assertNull(service.getDeliveryNoteData("9999"));
    }

    @Test
    void shouldCalculateTotalWeight() {
        // ABAP: lv_total_weight = lv_total_weight + gs_item-brgew
        DeliveryHeader header = buildHeader();
        DeliveryItem item1 = buildItem("10", "FURN-001", new BigDecimal("120.000"));
        DeliveryItem item2 = buildItem("20", "FURN-002", new BigDecimal("85.500"));

        when(repository.findHeaderByDeliveryNumber("8000000001")).thenReturn(header);
        when(repository.findItemsByDeliveryNumber("8000000001")).thenReturn(Arrays.asList(item1, item2));
        when(repository.findShipToAddress("C001")).thenReturn(new AddressData());

        DeliveryNoteData data = service.getDeliveryNoteData("8000000001");

        assertNotNull(data);
        assertEquals(2, data.getTotalItems());
        assertEquals(new BigDecimal("205.500"), data.getCalculatedTotalWeight());
    }

    @Test
    void shouldMapAllHeaderFields() {
        DeliveryHeader header = buildHeader();
        when(repository.findHeaderByDeliveryNumber("8000000001")).thenReturn(header);
        when(repository.findItemsByDeliveryNumber("8000000001")).thenReturn(Arrays.asList());
        when(repository.findShipToAddress("C001")).thenReturn(new AddressData());

        DeliveryNoteData data = service.getDeliveryNoteData("8000000001");

        assertEquals("8000000001", data.getDeliveryNumber());
        assertEquals(LocalDate.of(2024, 6, 18), data.getDeliveryDate());
        assertEquals("SH01", data.getShippingPoint());
        assertEquals("RT001", data.getRoute());
    }

    private DeliveryHeader buildHeader() {
        DeliveryHeader header = new DeliveryHeader();
        header.setDeliveryNumber("8000000001");
        header.setCreatedDate(LocalDate.of(2024, 6, 15));
        header.setDeliveryDate(LocalDate.of(2024, 6, 18));
        header.setCustomerNumber("C001");
        header.setShippingPoint("SH01");
        header.setRoute("RT001");
        header.setTotalWeight(new BigDecimal("285.500"));
        header.setWeightUnit("KG");
        header.setNumberOfPackages(4);
        return header;
    }

    private DeliveryItem buildItem(String itemNumber, String materialNumber, BigDecimal grossWeight) {
        DeliveryItem item = new DeliveryItem();
        item.setDeliveryNumber("8000000001");
        item.setItemNumber(itemNumber);
        item.setMaterialNumber(materialNumber);
        item.setDescription("Test Item");
        item.setQuantity(new BigDecimal("1.000"));
        item.setUnit("EA");
        item.setGrossWeight(grossWeight);
        item.setNetWeight(grossWeight.subtract(new BigDecimal("10.000")));
        item.setWeightUnit("KG");
        return item;
    }
}
