package com.bobs.delivery.api;

import com.bobs.delivery.application.DeliveryNoteService;
import com.bobs.delivery.application.data.AddressData;
import com.bobs.delivery.application.data.DeliveryItemData;
import com.bobs.delivery.application.data.DeliveryNoteData;
import com.bobs.delivery.infrastructure.pdf.DeliveryNotePdfGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * REST endpoint tests for DeliveryNoteController.
 *
 * Verifies PDF generation endpoint returns correct content type and data.
 */
@WebMvcTest(DeliveryNoteController.class)
class DeliveryNoteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DeliveryNoteService service;

    @MockBean
    private DeliveryNotePdfGenerator pdfGenerator;

    @Test
    void shouldReturnPdfForValidDelivery() throws Exception {
        DeliveryNoteData data = buildSampleData();
        when(service.getDeliveryNoteData("8000000001")).thenReturn(data);
        when(pdfGenerator.generatePdf(any())).thenReturn(new byte[]{0x25, 0x50, 0x44, 0x46}); // %PDF

        mockMvc.perform(get("/api/delivery-notes/8000000001/pdf"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF));
    }

    @Test
    void shouldReturn404ForMissingDelivery() throws Exception {
        // ABAP: MESSAGE |Delivery { pv_vbeln } not found| TYPE 'E'
        when(service.getDeliveryNoteData("9999999999")).thenReturn(null);

        mockMvc.perform(get("/api/delivery-notes/9999999999/pdf"))
                .andExpect(status().isNotFound());
    }

    private DeliveryNoteData buildSampleData() {
        AddressData address = new AddressData();
        address.setName1("Riverside Home Staging");
        address.setStreet("123 Main St");
        address.setCity("Manchester");
        address.setRegion("CT");
        address.setPostalCode("06040");
        address.setCountry("US");

        DeliveryItemData item = new DeliveryItemData();
        item.setItemNumber("10");
        item.setMaterialNumber("FURN-001");
        item.setDescription("Oak Dining Table 6-Seater");
        item.setQuantity(new BigDecimal("2.000"));
        item.setUnit("EA");
        item.setGrossWeight(new BigDecimal("120.000"));
        item.setNetWeight(new BigDecimal("110.000"));
        item.setWeightUnit("KG");

        DeliveryNoteData data = new DeliveryNoteData();
        data.setDeliveryNumber("8000000001");
        data.setCreatedDate(LocalDate.of(2024, 6, 15));
        data.setDeliveryDate(LocalDate.of(2024, 6, 18));
        data.setShippingPoint("SH01");
        data.setRoute("RT001");
        data.setTotalWeight(new BigDecimal("285.500"));
        data.setWeightUnit("KG");
        data.setNumberOfPackages(4);
        data.setShipToAddress(address);
        data.setItems(Arrays.asList(item));
        data.setCalculatedTotalWeight(new BigDecimal("120.000"));
        data.setTotalItems(1);

        return data;
    }
}
