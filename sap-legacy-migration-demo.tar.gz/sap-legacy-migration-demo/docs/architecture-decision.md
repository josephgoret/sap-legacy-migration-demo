# Architecture Decision Record: Target Platform for SAP Migration

## Status

Accepted

## Context

Acme Corporation is migrating custom ABAP objects out of SAP ECC. We need a target
platform and architecture that:

1. Is well-understood by the available developer talent pool
2. Maps cleanly to ABAP's procedural/OO patterns
3. Supports the same enterprise patterns (transactions, batch processing, reporting)
4. Has mature tooling for database access, testing, and deployment
5. Can be learned and applied consistently by Devin across hundreds of migrations

## Decision

### Primary Target: Spring Boot 2.7.x (Java 11)

**Why Spring Boot:**

- **Enterprise standard**: The most widely adopted Java framework for enterprise services.
  Acme existing non-SAP systems already use Java, so this aligns with their technology strategy.
- **ABAP mapping affinity**: ABAP's procedural style maps naturally to Java's service-layer
  pattern. ABAP function modules → Java service methods. ABAP structures → Java DTOs/entities.
- **Mature ecosystem**: Spring Boot provides out-of-the-box support for REST APIs, database
  access, validation, testing, and configuration — all patterns needed in migrated services.
- **Devin proficiency**: Devin generates high-quality Spring Boot code reliably, which is
  critical when migrating hundreds of objects.

**Why Java 11 (not 17+):**

- Acme existing infrastructure runs Java 11 in production
- Avoids introducing new language features that the operations team isn't familiar with
- Spring Boot 2.7.x has excellent Java 11 support

### Secondary Target: Python 3.9+ (for ETL/data extraction only)

Data extraction programs are migrated to Python because:
- pandas and SQLAlchemy are the natural tools for data transformation and extraction
- Acme data engineering team already uses Python
- ETL scripts don't need the full service framework that Spring Boot provides

### Persistence: MyBatis (not JPA/Hibernate)

**Why MyBatis over JPA:**

- **SQL visibility**: ABAP developers think in SQL (SELECT ... INTO ... FROM ...). MyBatis
  keeps SQL visible and explicit in XML mapper files, making it easier to verify that the
  migrated queries match the original ABAP SELECT statements.
- **Migration transparency**: During code review, consultants can directly compare the ABAP
  SELECT statement with the MyBatis SQL. With JPA, the actual SQL is hidden behind annotations
  and runtime query generation.
- **Complex query support**: SAP reports often have complex joins across multiple tables
  (MARA/MARC/MARD/MAKT). MyBatis handles these naturally without the impedance mismatch
  that JPA introduces for complex read queries.
- **No ORM magic**: Reduces the surface area for subtle behavioral differences between
  the original ABAP logic and the migrated Java logic.

### Schema Migration: Flyway

- **Version-controlled schema**: Each migrated service gets a Flyway migration that creates
  tables equivalent to the SAP tables the ABAP code was reading from.
- **Reproducible**: Any developer can spin up a fresh database with `./gradlew flywayMigrate`.
- **Test isolation**: Combined with SQLite, each test run starts with a clean schema.

### Dev/Test Database: SQLite

- **Zero infrastructure**: No need to install PostgreSQL or MySQL for development/testing.
- **Fast tests**: In-memory SQLite makes test suites run in seconds.
- **Production flexibility**: The MyBatis SQL is written to be portable. Switching to
  PostgreSQL or MySQL for production requires only a configuration change and minor SQL
  dialect adjustments.

## The 4-Layer Architecture

Every migrated Spring Boot service follows this package structure:

```
com.bobs.{service-name}/
├── api/                    # Layer 1: REST Controllers
│   ├── *Controller.java        # HTTP endpoints, request/response handling
│   └── *Request.java           # Request DTOs (if complex input)
│
├── application/            # Layer 2: Application Services
│   ├── *Service.java           # Business logic orchestration
│   └── data/                   # Data transfer objects
│       └── *Data.java          # DTOs for service responses
│
├── core/                   # Layer 3: Domain Model
│   ├── *.java                  # Domain entities (POJOs)
│   └── *Repository.java        # Repository interfaces (abstractions)
│
└── infrastructure/         # Layer 4: Infrastructure
    ├── mybatis/
    │   └── *Mapper.java        # MyBatis mapper interfaces
    └── repository/
        └── MyBatis*Repository.java  # Repository implementations
```

### Layer Rules

| Layer | Depends On | Purpose |
|-------|-----------|---------|
| `api` | `application`, `core` | Receives HTTP requests, delegates to services, returns responses |
| `application` | `core` | Orchestrates business logic, applies transformations |
| `core` | nothing | Pure domain model — entities and repository contracts |
| `infrastructure` | `core` | Implements repository contracts with MyBatis |

### Why This Pattern

1. **Clean separation**: Business logic (application layer) is independent of HTTP handling
   (api layer) and database access (infrastructure layer).
2. **Testability**: Each layer can be tested independently. Service tests mock the repository
   interface; controller tests mock the service.
3. **ABAP mapping**: The layers map naturally to ABAP program structure:
   - ABAP selection screen → api layer (query parameters)
   - ABAP processing logic → application layer (service methods)
   - ABAP data structures → core layer (entities)
   - ABAP database access → infrastructure layer (MyBatis queries)
4. **Consistency**: Every migrated service follows the exact same structure, making it easy
   for Devin to apply the pattern and for consultants to review the output.

## File & Resource Conventions

```
src/main/resources/
├── application.properties          # Spring Boot configuration
├── mapper/
│   └── *Mapper.xml                 # MyBatis SQL mappings
└── db/migration/
    └── V1__create_*.sql            # Flyway schema migrations
```

### Naming Conventions

| ABAP Concept | Java Convention | Example |
|-------------|----------------|---------|
| Function module name | Controller class + method | `Z_CREATE_PO` → `PurchaseOrderController.createOrder()` |
| IMPORTING parameter | Request body field | `IV_VENDOR` → `CreateOrderRequest.vendorId` |
| EXPORTING parameter | Response body field | `EV_PO_NUMBER` → `CreateOrderResponse.poNumber` |
| TABLES parameter | List field | `IT_ITEMS` → `List<OrderItemRequest>` |
| EXCEPTION | HTTP status + error body | `VENDOR_NOT_FOUND` → `404 Not Found` |
| Internal table type | Java entity class | `TY_S_MATERIAL` → `Material.java` |
| ALV field catalog | JSON response field | `MATNR` → `materialNumber` |
| Selection screen param | Query parameter | `S_WERKS` → `@RequestParam plant` |

## Alternatives Considered

### .NET / C#

- Viable alternative, but Acme team has more Java experience
- Would work equally well with this layered architecture

### Node.js / TypeScript

- Less natural mapping from ABAP's strongly-typed, procedural style
- Weaker enterprise framework ecosystem for this use case

### Microservices vs. Monolith

- Each migrated ABAP object becomes its own service by default
- Services can be consolidated later based on domain boundaries
- Starting with separate services makes migration incremental and independently testable

## Consequences

- All migrated services are independently deployable and testable
- SAP consultants can review migrated SQL by comparing MyBatis XML with original ABAP SELECTs
- New team members can understand the pattern quickly due to consistent structure
- SQLite limitation: some SAP-specific SQL patterns may need adjustment for production databases
