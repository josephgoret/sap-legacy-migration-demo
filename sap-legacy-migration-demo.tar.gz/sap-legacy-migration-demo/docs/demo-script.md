# SAP Legacy Migration Demo — Presenter Script

## Target Audience
Sales engineers presenting Devin's SAP migration capabilities to enterprise prospects.

## Prerequisites
- Java 11+ installed
- Python 3.9+ installed
- Terminal access to run builds and tests
- This repository cloned locally

---

## Opening (2 minutes)

### The Problem
> "Every large enterprise running SAP has accumulated hundreds of custom ABAP objects over 10-20 years. These customizations — reports, interfaces, data extractions, forms — represent millions of dollars of business logic that's trapped in a language with a shrinking talent pool."

**Key stats to mention:**
- A typical mid-market SAP customer has **230-830 custom objects** (Z-programs, function modules, includes)
- ABAP consultants cost **$200-300/hour** and are increasingly hard to find
- Traditional migration: **6-18 months**, tens of millions of dollars
- Most objects follow **5 repeatable patterns** that can be mechanically translated

### Acme Corporation Context
> "For this demo, we're looking at Acme Corporation — a furniture retailer with a typical SAP ECC system. They have custom inventory reports, purchase order interfaces, customer master syncs, pricing extractions, and delivery note forms. All written in ABAP, all needing to migrate to modern services."

---

## Scenario 1: Inventory Report Migration (5 minutes)

### Show the Source ABAP
Open `source-abap/z_inventory_report.abap`

**Talking points:**
> "This is a typical custom ALV report. About 200 lines of ABAP. It has a selection screen for filtering, joins across four SAP tables — MARA, MARC, MARD, MAKT — calculates stock values, determines reorder status, and displays everything in an ALV grid with color-coding."

Point out key ABAP constructs:
- `SELECT-OPTIONS` and `PARAMETERS` → will become query parameters
- `SELECT ... INTO INTERNAL TABLE` → will become a MyBatis SQL query
- `LOOP AT ... ASSIGNING <FIELD-SYMBOL>` → will become a Java stream/loop
- `REUSE_ALV_GRID_DISPLAY` → will become a JSON REST response

### Show the Playbook
Open `playbooks/alv-report-to-rest-api.md`

> "This is how Devin knows what to do. The playbook defines the pattern: take an ALV report, map the selection screen to query parameters, map the SELECT to a MyBatis query, map the ALV output to a JSON DTO. Step by step instructions that Devin follows."

### Show the Migrated Service
Open `migrated/inventory-service/`

> "And here's what Devin produced. A complete Spring Boot service with the 4-layer architecture: API controller, application service, domain entities, and infrastructure persistence. Let me walk through the key files..."

Show these files in order:
1. `api/InventoryReportController.java` — "The selection screen parameters became @RequestParam annotations"
2. `application/InventoryQueryService.java` — "The stock calculation logic, extracted and testable"
3. `infrastructure/mybatis/MaterialMapper.java` + `mapper/MaterialMapper.xml` — "The ABAP SELECT became a MyBatis query"
4. `db/migration/V1__create_inventory_tables.sql` — "Schema migrations, version-controlled"

### Run the Tests
```bash
cd migrated/inventory-service && ./gradlew test
```

> "Every test has comments showing the ABAP equivalence. This test verifies that stock=3, reorderPoint=10 returns CRITICAL — the exact same logic as the ABAP IF/ELSEIF chain."

**Key talking point:**
> "This pattern repeats across hundreds of reports. Each one is an isolated slice — same input structure, same output structure, independently testable. Devin can run these migrations in parallel, 24/7."

---

## Scenario 2: RFC to REST API (3 minutes)

### Quick Walkthrough
Open `source-abap/z_purchase_order_rfc.abap` → `migrated/purchase-order-api/`

> "This is an RFC function module — SAP's version of an API endpoint. It takes import parameters, validates data, creates a purchase order, and returns results. The ABAP EXCEPTIONS become HTTP status codes."

**Show the mapping:**
- `IMPORTING iv_vendor` → `CreateOrderRequest.vendorId`
- `RAISE vendor_not_found` → `ResponseStatusException(HttpStatus.NOT_FOUND)`
- `TABLES it_items` → `List<OrderItemRequest>`
- `COMMIT WORK AND WAIT` → `@Transactional`

### Run Tests
```bash
cd migrated/purchase-order-api && ./gradlew test
```

> "Each RFC interface is an isolated slice. The IMPORTING/EXPORTING/TABLES/EXCEPTIONS contract maps directly to a REST API contract. Independently testable, independently deployable."

---

## Scenario 3: IDoc to Event API (3 minutes)

### Show the Pattern
Open `source-abap/z_customer_idoc.abap` → `migrated/customer-sync-service/`

> "IDocs are SAP's message format — think of them as SAP's version of events. This processor handles customer master data from a DEBMAS IDoc. The key insight: IDoc processing is inherently idempotent. Sending the same IDoc twice should update, not duplicate."

**Key talking points:**
- IDoc segments → JSON request body
- Status 51 (success) → HTTP 200/201
- Status 53 (error) → HTTP 400
- Duplicate detection → Upsert pattern

### Run Tests
```bash
cd migrated/customer-sync-service && ./gradlew test
```

> "The idempotent upsert test is critical — it verifies that sending the same customer data twice results in an UPDATE, not a duplicate INSERT. This matches the IDoc reprocessing behavior that SAP admins rely on."

---

## Scenario 4: Data Extraction ETL (3 minutes)

### Show Cross-Language Migration
Open `source-abap/z_pricing_extract.abap` → `migrated/pricing-etl/`

> "Not everything migrates to Java. Data extraction programs are better served by Python ETL scripts. This demonstrates Devin's ability to work across target languages."

**Show the mapping:**
- ABAP `SELECT FROM konh/konp` → SQL query via SQLAlchemy
- ABAP `OPEN DATASET ... FOR OUTPUT` → pandas `to_csv()`
- ABAP date filtering (`DATAB <= p_keydt AND DATBI >= p_keydt`) → SQL WHERE clause
- ABAP selection screen → YAML configuration + CLI args

### Run Tests
```bash
cd migrated/pricing-etl && pip install -r requirements.txt && pytest tests/ -v
```

> "The date-effective filtering test is the business-critical one. It verifies that expired pricing conditions are excluded — the same logic as the ABAP WHERE clause on DATAB and DATBI."

---

## Scenario 5: Form to PDF (2 minutes)

### Show Business Logic Extraction
Open `source-abap/z_delivery_note_form.abap` → `migrated/delivery-note-generator/`

> "SAPscript forms are notoriously hard to migrate because they mix business logic with rendering. Devin's approach: separate the two. The DeliveryNoteService extracts the data, the DeliveryNotePdfGenerator handles rendering with Apache PDFBox."

**Key insight:**
> "The business logic — reading delivery data, calculating totals, formatting addresses — is now independently testable. The rendering is a separate concern that can be swapped out (PDFBox today, a reporting engine tomorrow)."

### Run Tests
```bash
cd migrated/delivery-note-generator && ./gradlew test
```

---

## Closing (2 minutes)

### The 80/20 Split
> "What you've seen is the 80% — the mechanical translation work. Devin handles pattern recognition, code generation, test creation, and validation. The remaining 20% requires SAP domain expertise:"

- **Authorization checks** (SU24/SU22 mappings don't translate mechanically)
- **SAP-specific business rules** embedded in configuration (SPRO/IMG)
- **Integration testing** against real SAP systems
- **Performance optimization** for high-volume scenarios
- **Edge cases** in custom logic that need human judgment

### Economics
> "Traditional approach: 500 custom objects × 40 hours/object × $250/hour = **$5M over 12-18 months**"
>
> "Devin-assisted approach: 80% handled by Devin in parallel, consultants focus on the 20%. **60-70% cost reduction, 3-4x faster timeline.**"

### Honest Limitations
Be upfront about these:
1. **ABAP is niche** — Devin's training data has less ABAP than mainstream languages
2. **No local SAP runtime** — can't execute ABAP to verify behavior automatically
3. **Configuration vs. code** — SPRO/IMG settings don't appear in code scans
4. **Complex ABAP** — dynamic programming, kernel calls, and ABAP OO patterns need more human review
5. **Data migration** — this demo covers code migration only, not master data or transactional data

### Call to Action
> "The question isn't whether to migrate — it's whether you want to pay $250/hour for a human to do mechanical translation work, or let Devin handle the 80% so your consultants can focus on the 20% that actually requires their expertise."

---

## Appendix: Quick Commands Reference

```bash
# Build and test all Java services
for svc in inventory-service purchase-order-api customer-sync-service delivery-note-generator; do
  echo "=== Testing $svc ===" && cd migrated/$svc && ./gradlew test && cd ../..
done

# Test Python ETL
cd migrated/pricing-etl && pytest tests/ -v

# Run a specific service
cd migrated/inventory-service && ./gradlew bootRun
# Then: curl http://localhost:8080/api/inventory/report?plant=1000
```
