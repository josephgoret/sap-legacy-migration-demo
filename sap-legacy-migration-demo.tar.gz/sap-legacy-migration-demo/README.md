# SAP Legacy Migration Demo — Acme Corporation

> A self-contained demo showing how Devin migrates ABAP SAP customizations to modern Java/Python services.

## The Problem

Acme Corporation runs SAP ECC with **hundreds of custom ABAP objects** accumulated over 15+ years:
custom reports (Z-programs), RFC/BAPI interfaces, IDoc processors, data extractions, and SAPscript forms.
The ABAP talent pool is shrinking, consultants charge $200–$300/hr, and every custom object is a migration
blocker on the path to S/4HANA or a cloud ERP.

## What This Demo Shows

Devin can **translate the 80% of mechanical migration labor** — reading ABAP source, understanding SAP table
structures, and producing equivalent modern services — while SAP domain consultants focus on the 20% that
requires deep functional expertise (business process redesign, configuration, integration testing against a
live SAP system).

## Demo Structure

```
sap-legacy-migration-demo/
├── source-abap/              # 5 realistic ABAP programs (common SAP customization patterns)
├── playbooks/                # 5 Devin playbooks (migration instructions per pattern)
├── migrated/                 # 5 fully working migrated services (Java/Python)
│   ├── inventory-service/        # Spring Boot REST API (from ALV report)
│   ├── purchase-order-api/       # Spring Boot REST API (from RFC)
│   ├── customer-sync-service/    # Spring Boot REST API (from IDoc)
│   ├── pricing-etl/              # Python ETL script (from data extract)
│   └── delivery-note-generator/  # Spring Boot + PDFBox (from SAPscript form)
├── tests/equivalence/        # Equivalence test fixtures & mapping docs
├── docs/                     # Assessment, architecture decisions, demo script
└── .github/workflows/        # CI pipeline
```

## The 5 Migration Scenarios

| # | Source ABAP | Pattern | Target | Migrated Service |
|---|-------------|---------|--------|------------------|
| 1 | [z_inventory_report.abap](source-abap/z_inventory_report.abap) | ALV Report | Spring Boot REST API | [inventory-service](migrated/inventory-service/) |
| 2 | [z_purchase_order_rfc.abap](source-abap/z_purchase_order_rfc.abap) | RFC Function Module | Spring Boot REST API | [purchase-order-api](migrated/purchase-order-api/) |
| 3 | [z_customer_idoc.abap](source-abap/z_customer_idoc.abap) | IDoc Processor | Spring Boot Event API | [customer-sync-service](migrated/customer-sync-service/) |
| 4 | [z_pricing_extract.abap](source-abap/z_pricing_extract.abap) | Data Extraction | Python ETL | [pricing-etl](migrated/pricing-etl/) |
| 5 | [z_delivery_note_form.abap](source-abap/z_delivery_note_form.abap) | SAPscript Form | Java PDF Generator | [delivery-note-generator](migrated/delivery-note-generator/) |

## Target Architecture

All Java services follow a **4-layer Clean Architecture**:

```
api/            → REST controllers, request/response DTOs
application/    → Service layer, business logic orchestration
core/           → Domain entities, repository interfaces
infrastructure/ → MyBatis mappers, repository implementations
```

**Stack:** Spring Boot 2.7.x · MyBatis · Flyway · SQLite (dev/test) · JUnit 5

See [docs/architecture-decision.md](docs/architecture-decision.md) for the full rationale.

## How to Run the Demo

### Prerequisites

- Java 11+
- Python 3.9+
- Gradle (wrapper included in each service)

### Build & Test All Java Services

```bash
# Inventory Service
cd migrated/inventory-service && ./gradlew build

# Purchase Order API
cd migrated/purchase-order-api && ./gradlew build

# Customer Sync Service
cd migrated/customer-sync-service && ./gradlew build

# Delivery Note Generator
cd migrated/delivery-note-generator && ./gradlew build
```

### Run Python ETL Tests

```bash
cd migrated/pricing-etl
pip install -r requirements.txt
pytest tests/
```

### Run a Service Locally

```bash
cd migrated/inventory-service
./gradlew bootRun
# API available at http://localhost:8080/api/inventory/report?plant=1000&materialType=FURN
```

## Documentation

- [Migration Assessment](docs/migration-assessment.md) — Full analysis of Devin's SAP migration capabilities
- [Architecture Decision](docs/architecture-decision.md) — Why Spring Boot + 4-layer architecture
- [Demo Script](docs/demo-script.md) — Presenter-ready walkthrough for sales engineers
- [Equivalence Testing](tests/equivalence/README.md) — How we validate migration correctness

## Key Takeaway

> Devin handles the **80% translation labor** (reading ABAP, mapping tables, generating services and tests).
> SAP consultants handle the **20% requiring domain expertise** (business process validation, integration
> testing, SAP configuration). The result: parallel execution at a fraction of traditional consultant cost.
