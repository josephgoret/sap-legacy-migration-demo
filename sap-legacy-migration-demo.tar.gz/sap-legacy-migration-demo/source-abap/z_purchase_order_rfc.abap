*&---------------------------------------------------------------------*
*& Function Module Z_BOBS_CREATE_PURCHASE_ORDER
*& Acme Corporation — RFC-Enabled Purchase Order Creation
*&---------------------------------------------------------------------*
*& Description:
*&   Creates a purchase order for furniture procurement. Called by
*&   external procurement systems via RFC. Validates vendor, materials,
*&   and plant data before inserting PO header (EKKO) and items (EKPO).
*&
*& Tables Used:
*&   EKKO - Purchasing Document Header
*&   EKPO - Purchasing Document Item
*&   LFA1 - Vendor Master
*&   MARA - Material Master
*&   T001W - Plants/Branches
*&
*& RFC Destination: BOBS_PROCUREMENT
*&---------------------------------------------------------------------*
FUNCTION z_bobs_create_purchase_order.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_VENDOR)      TYPE LFA1-LIFNR        " Vendor Number
*"     VALUE(IV_PURCH_ORG)   TYPE EKKO-EKORG        " Purchasing Org
*"     VALUE(IV_PURCH_GRP)   TYPE EKKO-EKGRP        " Purchasing Group
*"     VALUE(IV_COMP_CODE)   TYPE EKKO-BUKRS        " Company Code
*"     VALUE(IV_DOC_TYPE)    TYPE EKKO-BSART        " Document Type (NB=Standard)
*"  EXPORTING
*"     VALUE(EV_PO_NUMBER)   TYPE EKKO-EBELN        " Created PO Number
*"     VALUE(EV_MESSAGE)     TYPE BAPIRET2-MESSAGE   " Return Message
*"  TABLES
*"     IT_ITEMS              STRUCTURE ZBOBS_PO_ITEM  " PO Line Items
*"  EXCEPTIONS
*"     VENDOR_NOT_FOUND
*"     MATERIAL_NOT_FOUND
*"     PLANT_INVALID
*"     CREATION_FAILED
*"----------------------------------------------------------------------

  " Local data declarations
  DATA: lv_vendor_exists TYPE c,
        lv_material_exists TYPE c,
        lv_plant_valid TYPE c,
        ls_ekko TYPE ekko,
        ls_ekpo TYPE ekpo,
        lv_po_number TYPE ekko-ebeln,
        lv_item_count TYPE i.

  " ================================================================
  " Step 1: Validate Vendor — maps to PurchaseOrderService.validateVendor()
  " ================================================================
  SELECT SINGLE 'X'
    INTO lv_vendor_exists
    FROM lfa1
    WHERE lifnr = iv_vendor.

  IF sy-subrc <> 0.
    ev_message = |Vendor { iv_vendor } does not exist|.
    RAISE vendor_not_found.
  ENDIF.

  " ================================================================
  " Step 2: Validate all line items — maps to validation annotations
  " ================================================================
  LOOP AT it_items.

    " Check material exists in material master
    SELECT SINGLE 'X'
      INTO lv_material_exists
      FROM mara
      WHERE matnr = it_items-matnr.

    IF sy-subrc <> 0.
      ev_message = |Material { it_items-matnr } does not exist|.
      RAISE material_not_found.
    ENDIF.

    " Check plant is valid
    SELECT SINGLE 'X'
      INTO lv_plant_valid
      FROM t001w
      WHERE werks = it_items-werks.

    IF sy-subrc <> 0.
      ev_message = |Plant { it_items-werks } is not valid|.
      RAISE plant_invalid.
    ENDIF.

    " Validate quantity is positive
    IF it_items-menge <= 0.
      ev_message = |Item { it_items-ebelp }: quantity must be positive|.
      RAISE creation_failed.
    ENDIF.

    ADD 1 TO lv_item_count.

  ENDLOOP.

  " At least one item is required
  IF lv_item_count = 0.
    ev_message = 'At least one line item is required'.
    RAISE creation_failed.
  ENDIF.

  " ================================================================
  " Step 3: Generate PO Number — maps to sequence/UUID generation
  " ================================================================
  CALL FUNCTION 'NUMBER_GET_NEXT'
    EXPORTING
      nr_range_nr = '01'
      object      = 'EINKBELEG'
    IMPORTING
      number      = lv_po_number
    EXCEPTIONS
      OTHERS      = 1.

  IF sy-subrc <> 0.
    ev_message = 'Failed to generate PO number'.
    RAISE creation_failed.
  ENDIF.

  " ================================================================
  " Step 4: Insert PO Header (EKKO) — maps to MyBatis insert
  " ================================================================
  ls_ekko-ebeln = lv_po_number.
  ls_ekko-bukrs = iv_comp_code.
  ls_ekko-bsart = iv_doc_type.
  ls_ekko-lifnr = iv_vendor.
  ls_ekko-ekorg = iv_purch_org.
  ls_ekko-ekgrp = iv_purch_grp.
  ls_ekko-aedat = sy-datum.
  ls_ekko-ernam = sy-uname.

  INSERT ekko FROM ls_ekko.

  IF sy-subrc <> 0.
    ev_message = 'Failed to create PO header'.
    ROLLBACK WORK.
    RAISE creation_failed.
  ENDIF.

  " ================================================================
  " Step 5: Insert PO Items (EKPO) — maps to batch MyBatis insert
  " ================================================================
  LOOP AT it_items.

    ls_ekpo-ebeln = lv_po_number.
    ls_ekpo-ebelp = it_items-ebelp.       " Item number (10, 20, 30...)
    ls_ekpo-matnr = it_items-matnr.       " Material number
    ls_ekpo-txz01 = it_items-txz01.       " Short text
    ls_ekpo-menge = it_items-menge.       " Order quantity
    ls_ekpo-meins = it_items-meins.       " Unit of measure
    ls_ekpo-netpr = it_items-netpr.       " Net price
    ls_ekpo-werks = it_items-werks.       " Plant
    ls_ekpo-lgort = it_items-lgort.       " Storage location
    ls_ekpo-matkl = it_items-matkl.       " Material group
    ls_ekpo-aedat = sy-datum.

    INSERT ekpo FROM ls_ekpo.

    IF sy-subrc <> 0.
      ev_message = |Failed to create PO item { it_items-ebelp }|.
      ROLLBACK WORK.
      RAISE creation_failed.
    ENDIF.

  ENDLOOP.

  " ================================================================
  " Step 6: Commit and return success
  " ================================================================
  COMMIT WORK AND WAIT.

  ev_po_number = lv_po_number.
  ev_message = |Purchase order { lv_po_number } created successfully|.

ENDFUNCTION.

*----------------------------------------------------------------------*
* Structure definition for PO items (used in IT_ITEMS table parameter)
* Maps to CreateOrderItemRequest DTO in Java
*----------------------------------------------------------------------*
* ZBOBS_PO_ITEM:
*   EBELP  TYPE EKPO-EBELP    " Item Number (10, 20, 30...)
*   MATNR  TYPE EKPO-MATNR    " Material Number
*   TXZ01  TYPE EKPO-TXZ01    " Short Text (e.g., "Oak Dining Table")
*   MENGE  TYPE EKPO-MENGE    " Order Quantity
*   MEINS  TYPE EKPO-MEINS    " Unit of Measure (EA, PC)
*   NETPR  TYPE EKPO-NETPR    " Net Price per Unit
*   WERKS  TYPE EKPO-WERKS    " Plant
*   LGORT  TYPE EKPO-LGORT    " Storage Location
*   MATKL  TYPE EKPO-MATKL    " Material Group (FURN, ACCS)
