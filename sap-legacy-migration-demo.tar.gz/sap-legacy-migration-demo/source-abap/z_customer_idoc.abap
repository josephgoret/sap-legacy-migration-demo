*&---------------------------------------------------------------------*
*& Function Module Z_BOBS_PROCESS_CUSTOMER_IDOC
*& Acme Corporation — Customer Master IDoc Processor
*&---------------------------------------------------------------------*
*& Description:
*&   Processes inbound DEBMAS (Customer Master) IDocs from external CRM.
*&   Parses IDoc segments, maps to internal structures, and creates or
*&   updates customer master records. Handles duplicate detection and
*&   IDoc status management.
*&
*& IDoc Type: DEBMAS07
*& Segments:
*&   E1KNA1M - Customer General Data (name, address, phone)
*&   E1KNB1M - Customer Company Code Data (payment terms, credit limit)
*&
*& Tables Used:
*&   KNA1 - Customer Master (General)
*&   KNB1 - Customer Master (Company Code)
*&   EDIDS - IDoc Status Records
*&---------------------------------------------------------------------*
FUNCTION z_bobs_process_customer_idoc.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_IDOC_NUMBER)  TYPE EDIDC-DOCNUM
*"  TABLES
*"     IT_IDOC_DATA           STRUCTURE EDIDD      " IDoc Data Records
*"     IT_IDOC_STATUS         STRUCTURE EDIDS       " IDoc Status Records
*"  EXCEPTIONS
*"     IDOC_PROCESSING_ERROR
*"----------------------------------------------------------------------

  " Local data declarations
  DATA: ls_kna1       TYPE kna1,           " Customer general data
        ls_knb1       TYPE knb1,           " Customer company code data
        ls_e1kna1m    TYPE e1kna1m,        " IDoc segment: general data
        ls_e1knb1m    TYPE e1knb1m,        " IDoc segment: company code
        ls_status     TYPE edids,          " IDoc status record
        lv_customer   TYPE kna1-kunnr,     " Customer number
        lv_exists     TYPE c,              " Duplicate check flag
        lv_operation  TYPE c LENGTH 6.     " CREATE or UPDATE

  " ================================================================
  " Step 1: Parse IDoc segments — maps to JSON deserialization
  " Extract customer general data from E1KNA1M segment
  " ================================================================
  LOOP AT it_idoc_data WHERE segnam = 'E1KNA1M'.
    ls_e1kna1m = it_idoc_data-sdata.

    " Map IDoc fields to internal customer structure
    " This mapping is equivalent to JSON → Entity mapping in Java
    lv_customer     = ls_e1kna1m-kunnr.      " Customer number
    ls_kna1-kunnr   = ls_e1kna1m-kunnr.      " Customer number
    ls_kna1-name1   = ls_e1kna1m-name1.      " Name line 1
    ls_kna1-name2   = ls_e1kna1m-name2.      " Name line 2
    ls_kna1-stras   = ls_e1kna1m-stras.      " Street address
    ls_kna1-ort01   = ls_e1kna1m-ort01.      " City
    ls_kna1-regio   = ls_e1kna1m-regio.      " State/Region
    ls_kna1-pstlz   = ls_e1kna1m-pstlz.     " Postal code
    ls_kna1-land1   = ls_e1kna1m-land1.      " Country
    ls_kna1-telf1   = ls_e1kna1m-telf1.      " Phone number
    ls_kna1-telfx   = ls_e1kna1m-telfx.      " Fax number
    ls_kna1-smtp_addr = ls_e1kna1m-smtp_addr." Email address
    ls_kna1-ktokd   = ls_e1kna1m-ktokd.      " Account group
    ls_kna1-spras   = ls_e1kna1m-spras.      " Language

    EXIT. " Only one E1KNA1M segment per IDoc
  ENDLOOP.

  " Validate that customer number was provided
  IF lv_customer IS INITIAL.
    ls_status-docnum = iv_idoc_number.
    ls_status-status = '53'.  " IDoc status: Application error
    ls_status-statxt = 'Customer number missing in E1KNA1M segment'.
    APPEND ls_status TO it_idoc_status.
    RAISE idoc_processing_error.
  ENDIF.

  " ================================================================
  " Step 2: Parse company code segment (E1KNB1M)
  " Maps to nested JSON object in request body
  " ================================================================
  LOOP AT it_idoc_data WHERE segnam = 'E1KNB1M'.
    ls_e1knb1m = it_idoc_data-sdata.

    ls_knb1-kunnr = lv_customer.
    ls_knb1-bukrs = ls_e1knb1m-bukrs.      " Company code
    ls_knb1-zterm = ls_e1knb1m-zterm.      " Payment terms
    ls_knb1-klimk = ls_e1knb1m-klimk.      " Credit limit
    ls_knb1-akont = ls_e1knb1m-akont.      " Reconciliation account
    ls_knb1-zwels = ls_e1knb1m-zwels.      " Payment methods

    EXIT. " Process first company code segment
  ENDLOOP.

  " ================================================================
  " Step 3: Duplicate Detection — maps to idempotent upsert logic
  " Check if customer already exists in master data
  " ================================================================
  SELECT SINGLE 'X'
    INTO lv_exists
    FROM kna1
    WHERE kunnr = lv_customer.

  IF sy-subrc = 0.
    lv_operation = 'UPDATE'.
  ELSE.
    lv_operation = 'CREATE'.
  ENDIF.

  " ================================================================
  " Step 4: Create or Update customer master — maps to repository save()
  " ================================================================
  IF lv_operation = 'CREATE'.

    " Set creation metadata
    ls_kna1-erdat = sy-datum.    " Created date
    ls_kna1-ernam = sy-uname.   " Created by

    INSERT kna1 FROM ls_kna1.
    IF sy-subrc <> 0.
      PERFORM set_error_status USING iv_idoc_number
                                     'Failed to create customer general data'
                                     it_idoc_status[].
      RAISE idoc_processing_error.
    ENDIF.

    " Insert company code data if provided
    IF ls_knb1-bukrs IS NOT INITIAL.
      ls_knb1-erdat = sy-datum.
      INSERT knb1 FROM ls_knb1.
      IF sy-subrc <> 0.
        ROLLBACK WORK.
        PERFORM set_error_status USING iv_idoc_number
                                       'Failed to create company code data'
                                       it_idoc_status[].
        RAISE idoc_processing_error.
      ENDIF.
    ENDIF.

  ELSE. " UPDATE

    " Set update metadata
    ls_kna1-aedat = sy-datum.    " Changed date
    ls_kna1-aenam = sy-uname.   " Changed by

    UPDATE kna1 FROM ls_kna1.
    IF sy-subrc <> 0.
      PERFORM set_error_status USING iv_idoc_number
                                     'Failed to update customer general data'
                                     it_idoc_status[].
      RAISE idoc_processing_error.
    ENDIF.

    " Update or insert company code data
    IF ls_knb1-bukrs IS NOT INITIAL.
      MODIFY knb1 FROM ls_knb1.
      IF sy-subrc <> 0.
        ROLLBACK WORK.
        PERFORM set_error_status USING iv_idoc_number
                                       'Failed to update company code data'
                                       it_idoc_status[].
        RAISE idoc_processing_error.
      ENDIF.
    ENDIF.

  ENDIF.

  " ================================================================
  " Step 5: Commit and set success status — maps to HTTP 200/201
  " IDoc Status 51 = Success, 53 = Error
  " ================================================================
  COMMIT WORK AND WAIT.

  ls_status-docnum = iv_idoc_number.
  ls_status-status = '51'.  " IDoc status: Application document posted
  ls_status-statxt = |Customer { lv_customer } { lv_operation }d successfully|.
  APPEND ls_status TO it_idoc_status.

ENDFUNCTION.

*&---------------------------------------------------------------------*
*& Form SET_ERROR_STATUS
*& Helper to record IDoc error status
*&---------------------------------------------------------------------*
FORM set_error_status USING pv_docnum TYPE edidc-docnum
                            pv_message TYPE edids-statxt
                            pt_status TYPE edids_t.

  DATA: ls_status TYPE edids.
  ls_status-docnum = pv_docnum.
  ls_status-status = '53'.  " Application error
  ls_status-statxt = pv_message.
  APPEND ls_status TO pt_status.

ENDFORM.
