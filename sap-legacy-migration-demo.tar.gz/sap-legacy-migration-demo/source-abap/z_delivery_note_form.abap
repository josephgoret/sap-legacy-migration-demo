*&---------------------------------------------------------------------*
*& Report Z_DELIVERY_NOTE_FORM
*& Acme Corporation — Delivery Note Print Program (SAPscript)
*&---------------------------------------------------------------------*
*& Description:
*&   Print program for delivery note forms. Reads delivery header (LIKP)
*&   and items (LIPS), formats address blocks, item details, weights,
*&   and totals, then outputs via SAPscript form ZBOBS_DELIVERY_NOTE.
*&
*& Tables Used:
*&   LIKP - Delivery Header
*&   LIPS - Delivery Items
*&   KNA1 - Customer Master (ship-to address)
*&   MAKT - Material Descriptions
*&   ADRC - Address Data
*&
*& Form: ZBOBS_DELIVERY_NOTE
*& Transaction: VL02N (print output)
*&---------------------------------------------------------------------*
REPORT z_delivery_note_form.

*----------------------------------------------------------------------*
* Type Definitions
*----------------------------------------------------------------------*
TYPES: BEGIN OF ty_s_delivery_header,
         vbeln   TYPE likp-vbeln,       " Delivery number
         erdat   TYPE likp-erdat,       " Created date
         lfdat   TYPE likp-lfdat,       " Delivery date
         kunnr   TYPE likp-kunnr,       " Ship-to customer
         vstel   TYPE likp-vstel,       " Shipping point
         route   TYPE likp-route,       " Route
         btgew   TYPE likp-btgew,       " Total weight
         gewei   TYPE likp-gewei,       " Weight unit
         anzpk   TYPE likp-anzpk,       " Number of packages
       END OF ty_s_delivery_header.

TYPES: BEGIN OF ty_s_delivery_item,
         vbeln   TYPE lips-vbeln,       " Delivery number
         posnr   TYPE lips-posnr,       " Item number
         matnr   TYPE lips-matnr,       " Material number
         maktx   TYPE makt-maktx,       " Material description
         lfimg   TYPE lips-lfimg,       " Delivery quantity
         vrkme   TYPE lips-vrkme,       " Sales unit
         brgew   TYPE lips-brgew,       " Gross weight per item
         ntgew   TYPE lips-ntgew,       " Net weight per item
         gewei   TYPE lips-gewei,       " Weight unit
       END OF ty_s_delivery_item.

TYPES: BEGIN OF ty_s_address,
         name1   TYPE kna1-name1,       " Name line 1
         name2   TYPE kna1-name2,       " Name line 2
         stras   TYPE adrc-str_suppl1,  " Street
         ort01   TYPE adrc-city1,       " City
         regio   TYPE adrc-region,      " State
         pstlz   TYPE adrc-post_code1,  " Postal code
         land1   TYPE adrc-country,     " Country
       END OF ty_s_address.

DATA: gs_header  TYPE ty_s_delivery_header,
      gt_items   TYPE STANDARD TABLE OF ty_s_delivery_item,
      gs_item    TYPE ty_s_delivery_item,
      gs_address TYPE ty_s_address.

*----------------------------------------------------------------------*
* Selection Screen
*----------------------------------------------------------------------*
PARAMETERS: p_vbeln TYPE likp-vbeln OBLIGATORY.  " Delivery Number

*----------------------------------------------------------------------*
* Start of Processing
*----------------------------------------------------------------------*
START-OF-SELECTION.

  " Step 1: Read delivery header data
  PERFORM read_delivery_header USING p_vbeln.

  " Step 2: Read delivery line items
  PERFORM read_delivery_items USING p_vbeln.

  " Step 3: Read ship-to address
  PERFORM read_ship_to_address USING gs_header-kunnr.

  " Step 4: Open SAPscript form and print delivery note
  PERFORM print_delivery_note.

*&---------------------------------------------------------------------*
*& Form READ_DELIVERY_HEADER
*& Maps to DeliveryNoteService.getDeliveryHeader()
*&---------------------------------------------------------------------*
FORM read_delivery_header USING pv_vbeln TYPE likp-vbeln.

  SELECT SINGLE vbeln erdat lfdat kunnr vstel route btgew gewei anzpk
    INTO CORRESPONDING FIELDS OF gs_header
    FROM likp
    WHERE vbeln = pv_vbeln.

  IF sy-subrc <> 0.
    MESSAGE |Delivery { pv_vbeln } not found| TYPE 'E'.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*& Form READ_DELIVERY_ITEMS
*& Maps to DeliveryNoteService.getDeliveryItems()
*&---------------------------------------------------------------------*
FORM read_delivery_items USING pv_vbeln TYPE likp-vbeln.

  SELECT l~vbeln l~posnr l~matnr t~maktx
         l~lfimg l~vrkme l~brgew l~ntgew l~gewei
    INTO CORRESPONDING FIELDS OF TABLE gt_items
    FROM lips AS l
    LEFT OUTER JOIN makt AS t ON t~matnr = l~matnr
                              AND t~spras = sy-langu
    WHERE l~vbeln = pv_vbeln
    ORDER BY l~posnr.

  IF sy-subrc <> 0.
    MESSAGE |No items found for delivery { pv_vbeln }| TYPE 'W'.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*& Form READ_SHIP_TO_ADDRESS
*& Maps to DeliveryNoteService.getShipToAddress()
*&---------------------------------------------------------------------*
FORM read_ship_to_address USING pv_kunnr TYPE kna1-kunnr.

  SELECT SINGLE k~name1 k~name2 a~str_suppl1
                a~city1 a~region a~post_code1 a~country
    INTO CORRESPONDING FIELDS OF gs_address
    FROM kna1 AS k
    INNER JOIN adrc AS a ON a~addrnumber = k~adrnr
    WHERE k~kunnr = pv_kunnr.

  IF sy-subrc <> 0.
    MESSAGE |Ship-to address not found for customer { pv_kunnr }| TYPE 'W'.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*& Form PRINT_DELIVERY_NOTE
*& Maps to DeliveryNotePdfService.generatePdf()
*& Opens SAPscript form and writes content blocks
*&---------------------------------------------------------------------*
FORM print_delivery_note.

  DATA: lv_total_weight TYPE p DECIMALS 3,
        lv_total_items  TYPE i,
        lv_item_count   TYPE i.

  " Open SAPscript form
  CALL FUNCTION 'OPEN_FORM'
    EXPORTING
      device   = 'PRINTER'
      form     = 'ZBOBS_DELIVERY_NOTE'
      language = sy-langu
    EXCEPTIONS
      OTHERS   = 1.

  IF sy-subrc <> 0.
    MESSAGE 'Error opening delivery note form' TYPE 'E'.
    RETURN.
  ENDIF.

  " --- Header Section: Company and delivery info ---
  CALL FUNCTION 'WRITE_FORM'
    EXPORTING element = 'HEADER'
    EXCEPTIONS OTHERS = 1.

  " --- Ship-To Address Block ---
  " Maps to address section in PDF template
  CALL FUNCTION 'WRITE_FORM'
    EXPORTING element = 'SHIP_TO_ADDRESS'
    EXCEPTIONS OTHERS = 1.

  " --- Delivery Details ---
  CALL FUNCTION 'WRITE_FORM'
    EXPORTING element = 'DELIVERY_INFO'
    EXCEPTIONS OTHERS = 1.

  " --- Item Table Header ---
  CALL FUNCTION 'WRITE_FORM'
    EXPORTING element = 'ITEM_HEADER'
    EXCEPTIONS OTHERS = 1.

  " --- Item Lines ---
  " Loop through delivery items and write each line
  " Maps to PDF table row generation
  LOOP AT gt_items INTO gs_item.

    lv_item_count = lv_item_count + 1.
    lv_total_weight = lv_total_weight + gs_item-brgew.

    " Write item line to form
    CALL FUNCTION 'WRITE_FORM'
      EXPORTING element = 'ITEM_LINE'
      EXCEPTIONS OTHERS = 1.

    " Handle page break every 25 items
    IF lv_item_count MOD 25 = 0.
      CALL FUNCTION 'WRITE_FORM'
        EXPORTING
          element = 'PAGE_BREAK'
          type    = 'TOP'
        EXCEPTIONS OTHERS = 1.
    ENDIF.

  ENDLOOP.

  lv_total_items = lines( gt_items ).

  " --- Totals Section ---
  " Maps to PDF footer/totals block
  CALL FUNCTION 'WRITE_FORM'
    EXPORTING element = 'TOTALS'
    EXCEPTIONS OTHERS = 1.

  " --- Footer with signature line ---
  CALL FUNCTION 'WRITE_FORM'
    EXPORTING element = 'FOOTER'
    EXCEPTIONS OTHERS = 1.

  " Close the form
  CALL FUNCTION 'CLOSE_FORM'
    EXCEPTIONS OTHERS = 1.

  WRITE: / |Delivery note printed for { gs_header-vbeln }|.
  WRITE: / |Items: { lv_total_items } | &
           |Total weight: { lv_total_weight } { gs_header-gewei }|.

ENDFORM.
