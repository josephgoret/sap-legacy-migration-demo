*&---------------------------------------------------------------------*
*& Report Z_PRICING_EXTRACT
*& Acme Corporation — Pricing Condition Data Extraction
*&---------------------------------------------------------------------*
*& Description:
*&   Extracts pricing condition records for furniture products.
*&   Reads from SAP pricing tables (KONH/KONP), joins with material
*&   and customer data, applies date-effective filtering, and writes
*&   output to a flat file on the application server.
*&
*& Tables Used:
*&   KONH - Conditions (Header)
*&   KONP - Conditions (Items)
*&   MARA - Material Master
*&   MAKT - Material Descriptions
*&   KNA1 - Customer Master
*&
*& Condition Types:
*&   PR00 - Base Price
*&   K004 - Material Discount
*&   K005 - Customer/Material Discount
*&   MWST - Tax
*&
*& Output: Tab-delimited flat file on application server
*&---------------------------------------------------------------------*
REPORT z_pricing_extract.

*----------------------------------------------------------------------*
* Type Definitions
*----------------------------------------------------------------------*
TYPES: BEGIN OF ty_s_pricing,
         knumh   TYPE konh-knumh,     " Condition record number
         kschl   TYPE konh-kschl,     " Condition type
         matnr   TYPE mara-matnr,     " Material number
         maktx   TYPE makt-maktx,     " Material description
         kunnr   TYPE kna1-kunnr,     " Customer number
         name1   TYPE kna1-name1,     " Customer name
         kbetr   TYPE konp-kbetr,     " Condition rate (amount)
         konwa   TYPE konp-konwa,     " Condition currency
         kpein   TYPE konp-kpein,     " Condition pricing unit
         kmein   TYPE konp-kmein,     " Condition unit of measure
         datab   TYPE konh-datab,     " Valid-from date
         datbi   TYPE konh-datbi,     " Valid-to date
         kosrt   TYPE konh-kosrt,     " Search term
       END OF ty_s_pricing.

DATA: gt_pricing TYPE STANDARD TABLE OF ty_s_pricing,
      gs_pricing TYPE ty_s_pricing.

*----------------------------------------------------------------------*
* Selection Screen — Maps to ETL configuration parameters
*----------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b01 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS: s_kschl FOR gs_pricing-kschl DEFAULT 'PR00',  " Condition Type
                  s_matnr FOR gs_pricing-matnr,                  " Material
                  s_kunnr FOR gs_pricing-kunnr.                  " Customer
  PARAMETERS:     p_keydt  TYPE sy-datum DEFAULT sy-datum,       " Key Date (effective)
                  p_file   TYPE rlgrap-filename                  " Output file path
                    DEFAULT '/usr/sap/trans/data/pricing_extract.txt'.
SELECTION-SCREEN END OF BLOCK b01.

*----------------------------------------------------------------------*
* Data Declarations
*----------------------------------------------------------------------*
DATA: gv_count    TYPE i,
      gv_errors   TYPE i,
      gv_filename TYPE string.

*----------------------------------------------------------------------*
* Initialization
*----------------------------------------------------------------------*
INITIALIZATION.
  TEXT-001 = 'Extraction Parameters'.

*----------------------------------------------------------------------*
* Start of Processing
*----------------------------------------------------------------------*
START-OF-SELECTION.

  " Fetch pricing condition data with date-effective filtering
  " This query maps to the SQL in extract_pricing.py
  PERFORM fetch_pricing_data.

  " Check if data was found
  IF gt_pricing IS INITIAL.
    WRITE: / 'No pricing data found for selection criteria'.
    RETURN.
  ENDIF.

  " Write output to flat file
  PERFORM write_output_file.

  " Display extraction summary
  PERFORM display_summary.

*&---------------------------------------------------------------------*
*& Form FETCH_PRICING_DATA
*& Maps to extract_pricing.py → extract_conditions() function
*&---------------------------------------------------------------------*
FORM fetch_pricing_data.

  " Main extraction query — joins condition header/item with master data
  " The date-effective logic (DATAB <= key_date <= DATBI) ensures we only
  " extract currently valid pricing conditions
  SELECT h~knumh
         h~kschl
         h~matnr
         t~maktx
         h~kunnr
         c~name1
         p~kbetr
         p~konwa
         p~kpein
         p~kmein
         h~datab
         h~datbi
         h~kosrt
    INTO CORRESPONDING FIELDS OF TABLE gt_pricing
    FROM konh AS h
    INNER JOIN konp AS p ON p~knumh = h~knumh
    LEFT OUTER JOIN mara AS m ON m~matnr = h~matnr
    LEFT OUTER JOIN makt AS t ON t~matnr = h~matnr
                              AND t~spras = sy-langu
    LEFT OUTER JOIN kna1 AS c ON c~kunnr = h~kunnr
    WHERE h~kschl IN s_kschl
      AND h~matnr IN s_matnr
      AND h~kunnr IN s_kunnr
      AND h~datab <= p_keydt          " Valid-from <= key date
      AND h~datbi >= p_keydt.         " Valid-to >= key date

  " Sort by condition type, material, customer for consistent output
  SORT gt_pricing BY kschl matnr kunnr.

ENDFORM.

*&---------------------------------------------------------------------*
*& Form WRITE_OUTPUT_FILE
*& Maps to extract_pricing.py → write_output() function
*& Writes tab-delimited file to application server
*&---------------------------------------------------------------------*
FORM write_output_file.

  DATA: lv_line TYPE string.

  gv_filename = p_file.

  " Open file on application server for writing
  OPEN DATASET gv_filename FOR OUTPUT IN TEXT MODE ENCODING DEFAULT.
  IF sy-subrc <> 0.
    WRITE: / |Error opening file: { gv_filename }|.
    gv_errors = gv_errors + 1.
    RETURN.
  ENDIF.

  " Write header line
  CONCATENATE 'KNUMH' 'KSCHL' 'MATNR' 'MAKTX' 'KUNNR' 'NAME1'
              'KBETR' 'KONWA' 'KPEIN' 'KMEIN' 'DATAB' 'DATBI'
    INTO lv_line SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
  TRANSFER lv_line TO gv_filename.

  " Write data lines
  LOOP AT gt_pricing INTO gs_pricing.

    CONCATENATE gs_pricing-knumh gs_pricing-kschl
                gs_pricing-matnr gs_pricing-maktx
                gs_pricing-kunnr gs_pricing-name1
                gs_pricing-kbetr gs_pricing-konwa
                gs_pricing-kpein gs_pricing-kmein
                gs_pricing-datab gs_pricing-datbi
      INTO lv_line SEPARATED BY cl_abap_char_utilities=>horizontal_tab.

    TRANSFER lv_line TO gv_filename.
    gv_count = gv_count + 1.

  ENDLOOP.

  " Close the output file
  CLOSE DATASET gv_filename.

ENDFORM.

*&---------------------------------------------------------------------*
*& Form DISPLAY_SUMMARY
*& Extraction results summary — maps to ETL logging
*&---------------------------------------------------------------------*
FORM display_summary.

  WRITE: / '========================================'.
  WRITE: / 'Pricing Extract Complete'.
  WRITE: / '========================================'.
  WRITE: / 'Records extracted:', gv_count.
  WRITE: / 'Errors encountered:', gv_errors.
  WRITE: / 'Output file:', gv_filename.
  WRITE: / 'Key date:', p_keydt.
  WRITE: / '========================================'.

ENDFORM.
