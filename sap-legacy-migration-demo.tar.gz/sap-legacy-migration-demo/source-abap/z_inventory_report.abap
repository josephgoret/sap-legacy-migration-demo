*&---------------------------------------------------------------------*
*& Report Z_INVENTORY_REPORT
*& Acme Corporation — Custom Inventory Stock Report
*&---------------------------------------------------------------------*
*& Description:
*&   ALV report displaying current inventory levels across plants and
*&   storage locations. Color-codes low-stock items (below reorder point).
*&   Used by warehouse managers to monitor furniture stock levels.
*&
*& Tables Used:
*&   MARA - Material Master (General)
*&   MARC - Material Master (Plant Data)
*&   MARD - Material Master (Storage Location Data)
*&   MAKT - Material Descriptions
*&
*& Transaction: ZIR01
*&---------------------------------------------------------------------*
REPORT z_inventory_report.

*----------------------------------------------------------------------*
* Type Definitions
*----------------------------------------------------------------------*
TYPES: BEGIN OF ty_s_inventory,
         matnr     TYPE mara-matnr,       " Material Number
         maktx     TYPE makt-maktx,       " Material Description
         mtart     TYPE mara-mtart,       " Material Type
         werks     TYPE marc-werks,       " Plant
         lgort     TYPE mard-lgort,       " Storage Location
         labst     TYPE mard-labst,       " Unrestricted Stock
         minbe     TYPE marc-minbe,       " Reorder Point
         mabst     TYPE marc-mabst,       " Maximum Stock Level
         peinh     TYPE marc-peinh,       " Price Unit
         stprs     TYPE mbew-stprs,       " Standard Price
         stock_val TYPE p DECIMALS 2,     " Calculated Stock Value
         status    TYPE char10,           " Stock Status (OK/LOW/CRITICAL)
         color     TYPE lvc_t_scol,       " ALV Color
       END OF ty_s_inventory.

DATA: gt_inventory TYPE STANDARD TABLE OF ty_s_inventory,
      gs_inventory TYPE ty_s_inventory.

*----------------------------------------------------------------------*
* Selection Screen — Maps to REST API query parameters
*----------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b01 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS: s_werks FOR gs_inventory-werks,           " Plant
                  s_mtart FOR gs_inventory-mtart.           " Material Type
  PARAMETERS:     p_dtfrom TYPE sy-datum DEFAULT sy-datum,  " Date From
                  p_dtto   TYPE sy-datum DEFAULT sy-datum.  " Date To
SELECTION-SCREEN END OF BLOCK b01.

*----------------------------------------------------------------------*
* Data Declaration for ALV
*----------------------------------------------------------------------*
DATA: gt_fieldcat TYPE slis_t_fieldcat_alv,
      gs_fieldcat TYPE slis_fieldcat_alv,
      gs_layout   TYPE slis_layout_alv,
      gt_sort     TYPE slis_t_sortinfo_alv.

*----------------------------------------------------------------------*
* Initialization
*----------------------------------------------------------------------*
INITIALIZATION.
  TEXT-001 = 'Selection Criteria'.

*----------------------------------------------------------------------*
* Start of Processing — Main data retrieval
*----------------------------------------------------------------------*
START-OF-SELECTION.

  " Fetch inventory data by joining material master tables
  " This SELECT maps to the MyBatis query in MaterialMapper.xml
  SELECT m~matnr
         t~maktx
         m~mtart
         c~werks
         d~lgort
         d~labst
         c~minbe
         c~mabst
         c~peinh
         b~stprs
    INTO CORRESPONDING FIELDS OF TABLE gt_inventory
    FROM mara AS m
    INNER JOIN makt AS t ON t~matnr = m~matnr
                        AND t~spras = sy-langu
    INNER JOIN marc AS c ON c~matnr = m~matnr
    INNER JOIN mard AS d ON d~matnr = m~matnr
                        AND d~werks = c~werks
    LEFT OUTER JOIN mbew AS b ON b~matnr = m~matnr
                              AND b~bwkey = c~werks
    WHERE m~mtart IN s_mtart
      AND c~werks IN s_werks
      AND m~ersda BETWEEN p_dtfrom AND p_dtto.

  IF sy-subrc <> 0.
    MESSAGE 'No inventory data found for selection criteria' TYPE 'S'
            DISPLAY LIKE 'W'.
    RETURN.
  ENDIF.

  " Process inventory data — calculate stock values and determine status
  PERFORM calculate_stock_values.

  " Build and display ALV report
  PERFORM build_fieldcatalog.
  PERFORM set_layout.
  PERFORM display_alv.

*&---------------------------------------------------------------------*
*& Form CALCULATE_STOCK_VALUES
*& Maps to InventoryQueryService.calculateStockMetrics()
*&---------------------------------------------------------------------*
FORM calculate_stock_values.

  FIELD-SYMBOLS: <fs_inv> TYPE ty_s_inventory.

  LOOP AT gt_inventory ASSIGNING <fs_inv>.

    " Calculate stock value = quantity * (standard price / price unit)
    IF <fs_inv>-peinh > 0.
      <fs_inv>-stock_val = <fs_inv>-labst *
                           ( <fs_inv>-stprs / <fs_inv>-peinh ).
    ENDIF.

    " Determine stock status based on reorder point
    " CRITICAL: stock is zero or below 50% of reorder point
    " LOW: stock is below reorder point
    " OK: stock is at or above reorder point
    IF <fs_inv>-labst <= 0.
      <fs_inv>-status = 'CRITICAL'.
    ELSEIF <fs_inv>-minbe > 0 AND <fs_inv>-labst < <fs_inv>-minbe.
      IF <fs_inv>-labst < ( <fs_inv>-minbe / 2 ).
        <fs_inv>-status = 'CRITICAL'.
      ELSE.
        <fs_inv>-status = 'LOW'.
      ENDIF.
    ELSE.
      <fs_inv>-status = 'OK'.
    ENDIF.

    " Set ALV row color based on stock status
    " Red (C610) for CRITICAL, Yellow (C310) for LOW, Green (C510) for OK
    DATA: ls_color TYPE lvc_s_scol.
    CLEAR ls_color.
    ls_color-fname = 'STATUS'.
    CASE <fs_inv>-status.
      WHEN 'CRITICAL'.
        ls_color-color-col = 6.  " Red
        ls_color-color-int = 1.
      WHEN 'LOW'.
        ls_color-color-col = 3.  " Yellow
        ls_color-color-int = 1.
      WHEN 'OK'.
        ls_color-color-col = 5.  " Green
        ls_color-color-int = 1.
    ENDCASE.
    APPEND ls_color TO <fs_inv>-color.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*& Form BUILD_FIELDCATALOG
*& Defines ALV column layout — maps to JSON response DTO fields
*&---------------------------------------------------------------------*
FORM build_fieldcatalog.

  DEFINE add_field.
    CLEAR gs_fieldcat.
    gs_fieldcat-fieldname = &1.
    gs_fieldcat-seltext_l = &2.
    gs_fieldcat-outputlen = &3.
    APPEND gs_fieldcat TO gt_fieldcat.
  END-OF-DEFINITION.

  add_field: 'MATNR'     'Material Number'       18,
             'MAKTX'     'Description'            40,
             'MTART'     'Material Type'          10,
             'WERKS'     'Plant'                   6,
             'LGORT'     'Storage Location'        6,
             'LABST'     'Unrestricted Stock'     15,
             'MINBE'     'Reorder Point'          15,
             'MABST'     'Maximum Stock'          15,
             'STPRS'     'Standard Price'         15,
             'STOCK_VAL' 'Stock Value'            18,
             'STATUS'    'Status'                 10.

ENDFORM.

*&---------------------------------------------------------------------*
*& Form SET_LAYOUT
*& ALV display configuration
*&---------------------------------------------------------------------*
FORM set_layout.
  gs_layout-colwidth_optimize = 'X'.
  gs_layout-zebra             = 'X'.
  gs_layout-coltab_fieldname  = 'COLOR'.
ENDFORM.

*&---------------------------------------------------------------------*
*& Form DISPLAY_ALV
*& Renders the ALV grid — equivalent to returning JSON in REST API
*&---------------------------------------------------------------------*
FORM display_alv.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      is_layout          = gs_layout
      it_fieldcat        = gt_fieldcat
      it_sort            = gt_sort
      i_default          = 'X'
      i_save             = 'A'
    TABLES
      t_outtab           = gt_inventory
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.

  IF sy-subrc <> 0.
    MESSAGE 'Error displaying ALV report' TYPE 'E'.
  ENDIF.

ENDFORM.
